<?php
/**
 * Uninstall handler intentionally keeps the plugin index and manager metadata.
 * The plugin never removes product data on uninstall.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
