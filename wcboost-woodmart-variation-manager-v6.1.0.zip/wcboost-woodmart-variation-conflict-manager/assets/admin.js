(function($){
  'use strict';

  var VCM = {
    busy: false,

    post: function(action, data){
      data = data || {};
      data.action = action;
      data.nonce = VCM_DATA.nonce;
      return $.post(VCM_DATA.ajaxUrl, data);
    },

    toast: function(message, type){
      var cls = type === 'error' ? 'vcm-toast-error' : 'vcm-toast-success';
      var el = $('<div class="vcm-toast '+cls+'"></div>').text(message).appendTo('body');
      setTimeout(function(){ el.addClass('is-visible'); }, 10);
      setTimeout(function(){ el.removeClass('is-visible'); setTimeout(function(){ el.remove(); }, 250); }, 3500);
    },

    errorMessage: function(xhr, fallback){
      if(xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message){ return xhr.responseJSON.data.message; }
      return fallback || 'The server returned an error.';
    },

    updateStats: function(stats){
      if(!stats) return;
      $('.vcm-card').each(function(){
        var label = $(this).find('.vcm-card-label').text().toLowerCase();
        var value = null;
        if(label.indexOf('scanned') !== -1) value = stats.scanned;
        if(label.indexOf('real duplicates') !== -1) value = stats.conflicts;
        if(label.indexOf('quarantine') !== -1) value = stats.quarantine;
        if(label.indexOf('final approved') !== -1) value = stats.approved;
        if(value !== null) $(this).find('.vcm-card-value').text(value || 0);
      });
    },

    runScan: function(){
      if(VCM.busy) return;
      VCM.busy = true;
      var $btn = $('#vcm-run-scan').prop('disabled', true).addClass('is-loading');
      $('#vcm-scan-status').text('Starting scan…');
      VCM.post('vcm_start_scan').done(function(r){
        if(!r.success) throw new Error((r.data && r.data.message) || 'Scan could not start.');
        VCM.scanBatch(1);
      }).fail(function(xhr){
        VCM.busy=false; $btn.prop('disabled',false).removeClass('is-loading'); VCM.toast(VCM.errorMessage(xhr,'Scan failed.'),'error');
      });
    },

    scanBatch: function(page){
      VCM.post('vcm_scan_batch',{page:page,batch:VCM_DATA.batchSize}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Scan failed.');
        var state=r.data.state||{}, total=parseInt(state.total||0,10), done=parseInt(state.processed||0,10);
        $('#vcm-scan-status').text(total ? ('Scanning · '+done+' / '+total) : ('Scanning · '+done));
        VCM.updateStats(r.data.stats||{});
        if(!r.data.done){ setTimeout(function(){ VCM.scanBatch(r.data.nextPage); },80); return; }
        VCM.busy=false; $('#vcm-run-scan').prop('disabled',false).removeClass('is-loading'); $('#vcm-scan-status').text('Scan complete'); VCM.toast('Renderer scan complete.');
        setTimeout(function(){ window.location.reload(); },450);
      }).fail(function(xhr){
        VCM.busy=false; $('#vcm-run-scan').prop('disabled',false).removeClass('is-loading'); VCM.toast(VCM.errorMessage(xhr,'Scan failed.'),'error');
      });
    },

    quarantine: function(btn){
      var $btn=$(btn); $btn.prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_toggle_attribute',{product_id:$btn.data('product-id'),attribute:$btn.data('attribute'),quarantine:1}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Quarantine failed.');
        VCM.toast('Quarantine rule saved.'); setTimeout(function(){ window.location.reload(); },450);
      }).fail(function(xhr){ VCM.toast(VCM.errorMessage(xhr,'Quarantine failed.'),'error'); }).always(function(){ $btn.prop('disabled',false).removeClass('is-loading'); });
    },

    approve: function(btn){
      var $btn=$(btn); if(!window.confirm('Confirm final approval for this product? The approved WoodMart rule will remain active through the persistent layer.')) return;
      $btn.prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_approve',{product_id:$btn.data('product-id')}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Final approval blocked.');
        VCM.toast('Final approval confirmed.'); setTimeout(function(){ window.location.reload(); },450);
      }).fail(function(xhr){ VCM.toast(VCM.errorMessage(xhr,'Final approval blocked.'),'error'); }).always(function(){ $btn.prop('disabled',false).removeClass('is-loading'); });
    },

    restore: function(btn){
      var $btn=$(btn); if(!window.confirm('Restore this product to the original manager state?')) return;
      $btn.prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_restore',{product_id:$btn.data('product-id')}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Restore failed.');
        VCM.toast('Original manager state restored.'); setTimeout(function(){ window.location.reload(); },450);
      }).fail(function(xhr){ VCM.toast(VCM.errorMessage(xhr,'Restore failed.'),'error'); }).always(function(){ $btn.prop('disabled',false).removeClass('is-loading'); });
    },

    recheck: function(btn){
      var $btn=$(btn); $btn.prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_recheck',{product_id:$btn.data('product-id')}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Recheck failed.');
        var p=r.data.product||{}, n=p.conflicts?Object.keys(p.conflicts).length:0;
        VCM.toast(n ? ('Real duplicate still detected: '+n+' attribute(s).') : 'No real duplicate currently detected.', n?'error':'success');
      }).fail(function(xhr){ VCM.toast(VCM.errorMessage(xhr,'Recheck failed.'),'error'); }).always(function(){ $btn.prop('disabled',false).removeClass('is-loading'); });
    },

    quarantineAll: function(){
      if(VCM.busy) return;
      if(!window.confirm('Scan the catalog and quarantine all current real WoodMart + WCBoost conflicts?')) return;
      VCM.busy=true; var $btn=$('#vcm-quarantine-all').prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_start_scan').done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Scan could not start.');
        function scan(page){
          VCM.post('vcm_scan_batch',{page:page,batch:VCM_DATA.batchSize}).done(function(r2){
            if(!r2.success) throw new Error((r2.data&&r2.data.message)||'Scan failed.');
            var state=r2.data.state||{}, total=parseInt(state.total||0,10), done=parseInt(state.processed||0,10);
            $('#vcm-scan-status').text(total?('Scanning · '+done+' / '+total):('Scanning · '+done));
            VCM.updateStats(r2.data.stats||{});
            if(!r2.data.done){ setTimeout(function(){scan(r2.data.nextPage);},80); return; }
            var offset=0, changed=0;
            function step(){
              VCM.post('vcm_quarantine_all',{offset:offset,batch:10}).done(function(r3){
                if(!r3.success) throw new Error((r3.data&&r3.data.message)||'Bulk quarantine failed.');
                changed += parseInt(r3.data.changed||0,10); VCM.updateStats(r3.data.stats||{});
                if(!r3.data.done){ offset=parseInt(r3.data.nextOffset||0,10); $('#vcm-scan-status').text('Quarantining · '+changed); setTimeout(step,80); return; }
                VCM.busy=false; $btn.prop('disabled',false).removeClass('is-loading'); VCM.toast(changed+' product(s) moved to quarantine.'); setTimeout(function(){window.location.reload();},450);
              }).fail(function(xhr){ VCM.busy=false; $btn.prop('disabled',false).removeClass('is-loading'); VCM.toast(VCM.errorMessage(xhr,'Bulk quarantine failed.'),'error'); });
            }
            step();
          }).fail(function(xhr){ VCM.busy=false; $btn.prop('disabled',false).removeClass('is-loading'); VCM.toast(VCM.errorMessage(xhr,'Scan failed.'),'error'); });
        }
        scan(1);
      }).fail(function(xhr){ VCM.busy=false; $btn.prop('disabled',false).removeClass('is-loading'); VCM.toast(VCM.errorMessage(xhr,'Could not start scan.'),'error'); });
    },

    bulkConflict: function(){
      var ids=[]; $('.vcm-row-check:checked').each(function(){ids.push(parseInt($(this).val(),10));});
      if(!ids.length){VCM.toast('Select at least one product.','error');return;}
      var mode=$('#vcm-bulk-mode').val();
      if(!window.confirm(mode==='restore'?'Restore selected products to original manager state?':'Quarantine selected products?')) return;
      $('#vcm-apply-bulk').prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_bulk_manage',{ids:ids,mode:mode}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Bulk action failed.');
        VCM.toast((r.data.changed||0)+' product(s) updated.'); setTimeout(function(){window.location.reload();},500);
      }).fail(function(xhr){ VCM.toast(VCM.errorMessage(xhr,'Bulk action failed.'),'error'); }).always(function(){ $('#vcm-apply-bulk').prop('disabled',false).removeClass('is-loading'); });
    },


    scanCatalog: function(){
      if(VCM.busy) return;
      VCM.busy=true;
      var $btn=$('#vcm-ai-rescan').prop('disabled',true).addClass('is-loading');
      var target=$('#vcm-ai-scan-target').val()||'';
      var only=$('#vcm-ai-scan-incomplete').is(':checked')?1:0;
      var $wrap=$('#vcm-ai-scan-results').empty();
      $('#vcm-ai-scan-progress').text('Starting scan…');
      var page=1, total=0, processed=0, found=0;
      function esc(v){return VCM.esc(v==null?'':v);}
      function labels(obj){var a=[];$.each(obj||{},function(k,v){a.push('<span class="vcm-scan-lang">'+esc(k.toUpperCase())+'</span>');});return a.join('');}
      function missing(obj){var a=[];$.each(obj||{},function(k,v){a.push('<span class="vcm-scan-missing">'+esc((v||k)+' ('+k.toUpperCase()+')')+'</span>');});return a.join('');}
      function issues(arr){return (arr||[]).map(function(v){return '<span class="vcm-scan-issue">'+esc(v)+'</span>';}).join('');}
      function card(r){
        var statusClass=r.status==='missing_translation'?'is-missing':(r.status==='content_issue'?'is-warning':'is-ok');
        var present=labels(r.languages_present), missingHtml=missing(r.missing_languages);
        var translations=[]; $.each(r.translations||{},function(code,t){translations.push('<span class="vcm-translation-chip '+(t.issues&&t.issues.length?'has-issues':'')+'"><strong>'+esc(code.toUpperCase())+'</strong> #'+esc(t.id)+' '+(t.issues&&t.issues.length?'<small>content issue</small>':'<small>OK</small>')+'</span>');});
        return '<article class="vcm-scan-card">'+
          '<div class="vcm-scan-thumb"><img src="'+esc(r.image||'')+'" alt=""></div>'+
          '<div class="vcm-scan-main"><div class="vcm-scan-title-row"><div><strong>'+esc(r.title||'Untitled')+'</strong><span>#'+esc(r.id)+' · '+esc((r.language||'').toUpperCase())+'</span></div><span class="vcm-scan-status '+statusClass+'">'+esc(r.status.replace('_',' '))+'</span></div>'+
          '<div class="vcm-scan-specs"><span>SKU <b>'+esc(r.sku||'—')+'</b></span><span>Price <b>'+esc(r.price||'—')+'</b></span><span>Type <b>'+esc(r.type||'—')+'</b></span><span>Stock <b>'+esc(r.stock_status||'—')+'</b></span></div>'+
          '<div class="vcm-scan-line"><span class="vcm-scan-label">Present</span><div>'+present+'</div></div>'+
          '<div class="vcm-scan-line"><span class="vcm-scan-label">Missing</span><div>'+ (missingHtml||'<span class="vcm-scan-good">None</span>') +'</div></div>'+ 
          '<div class="vcm-scan-line"><span class="vcm-scan-label">Problems</span><div>'+ (issues(r.issue_labels)||'<span class="vcm-scan-good">No issues</span>') +'</div></div>'+ 
          '<div class="vcm-scan-translations">'+translations.join('')+'</div>'+ 
          '<div class="vcm-scan-actions"><a class="button" href="'+esc(r.edit_url||'#')+'" target="_blank" rel="noopener">Edit source</a><a class="button" href="'+esc(r.view_url||'#')+'" target="_blank" rel="noopener">View</a></div></div></article>';
      }
      function step(){
        VCM.post('vcm_ai_catalog_scan',{page:page,batch:20,target_language:target,only_incomplete:only}).done(function(resp){
          if(!resp.success) throw new Error((resp.data&&resp.data.message)||'Catalog scan failed.');
          var d=resp.data||{}; total=parseInt(d.total||0,10); processed=parseInt(d.processed||0,10); var rows=d.rows||[]; found+=rows.length;
          $('#vcm-ai-scan-results').append(rows.map(card).join(''));
          $('#vcm-ai-scan-progress').text('Scanned '+processed+' / '+total+' · '+found+' problem product(s)');
          if(!d.done){page=parseInt(d.next_page||0,10)||page+1;setTimeout(step,60);return;}
          VCM.busy=false;$btn.prop('disabled',false).removeClass('is-loading');
          if(!found){$wrap.html('<div class="vcm-scan-empty is-good"><span class="dashicons dashicons-yes"></span><strong>No incomplete products found.</strong><span>All scanned translation groups match the selected check.</span></div>');}
          $('#vcm-ai-scan-progress').text('Complete · '+found+' problem product(s)');
        }).fail(function(xhr){VCM.busy=false;$btn.prop('disabled',false).removeClass('is-loading');VCM.toast(VCM.errorMessage(xhr,'Catalog scan failed.'),'error');});
      }
      step();
    },


    missingScan: function(){
      if(VCM.busy) return;
      VCM.busy=true;
      var $btn=$('#vcm-missing-rescan').prop('disabled',true).addClass('is-loading');
      var source=$('select[name="source"]').val()||'';
      var target=$('select[name="target"]').val()||'';
      $('#vcm-missing-progress').text('Starting scan…');
      VCM.post('vcm_missing_scan_start',{source_language:source,target_language:target}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Scan could not start.');
        function step(page){
          VCM.post('vcm_missing_scan_batch',{page:page,batch:25}).done(function(r2){
            if(!r2.success) throw new Error((r2.data&&r2.data.message)||'Scan failed.');
            var st=r2.data.state||{};
            $('#vcm-missing-progress').text('Scanning · '+parseInt(st.processed||0,10)+(st.total_source?' / '+parseInt(st.total_source||0,10):'')+' · found '+parseInt(st.found||0,10));
            if(!r2.data.done){ setTimeout(function(){step(parseInt(r2.data.nextPage||0,10)||page+1);},90); return; }
            VCM.busy=false; $btn.prop('disabled',false).removeClass('is-loading'); $('#vcm-missing-progress').text('Complete · '+parseInt(st.found||0,10)+' missing-language group(s)');
            VCM.toast('Language scan complete.');
            var url=new URL(window.location.href); url.searchParams.set('page','vcm-variation-conflicts-missing'); url.searchParams.set('source',source); url.searchParams.set('target',target); url.searchParams.delete('paged'); window.location.href=url.toString();
          }).fail(function(xhr){VCM.busy=false;$btn.prop('disabled',false).removeClass('is-loading');VCM.toast(VCM.errorMessage(xhr,'Scan failed.'),'error');});
        }
        step(1);
      }).fail(function(xhr){VCM.busy=false;$btn.prop('disabled',false).removeClass('is-loading');VCM.toast(VCM.errorMessage(xhr,'Could not start scan.'),'error');});
    },

    aiTranslate: function(btn, reload){
      var $btn=$(btn), pid=$btn.data('product-id'), target=$btn.data('target-language');
      $btn.prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_ai_translate',{product_id:pid,target_language:target,mode:'smart'}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Translation failed.');
        var result=r.data.result||{}; VCM.toast('Translated successfully'+(result.from_memory?' · Translation Memory used':'')+'.');
        if(reload!==false){setTimeout(function(){window.location.reload();},500);}
      }).fail(function(xhr){ VCM.toast(VCM.errorMessage(xhr,'Translation failed.'),'error'); }).always(function(){ $btn.prop('disabled',false).removeClass('is-loading'); });
    },

    aiRewrite: function(btn){
      var $btn=$(btn); $btn.prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_ai_rewrite',{product_id:$btn.data('product-id')}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Rewrite failed.');
        VCM.toast('Description rewritten. Snapshot created.'); setTimeout(function(){window.location.reload();},500);
      }).fail(function(xhr){ VCM.toast(VCM.errorMessage(xhr,'Rewrite failed.'),'error'); }).always(function(){ $btn.prop('disabled',false).removeClass('is-loading'); });
    },

    aiSeo: function(btn){
      var $btn=$(btn); $btn.prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_ai_seo',{product_id:$btn.data('product-id')}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'SEO generation failed.');
        VCM.toast('SEO metadata generated. Snapshot created.'); setTimeout(function(){window.location.reload();},500);
      }).fail(function(xhr){ VCM.toast(VCM.errorMessage(xhr,'SEO generation failed.'),'error'); }).always(function(){ $btn.prop('disabled',false).removeClass('is-loading'); });
    },

    aiPreview: function(btn){
      var $btn=$(btn), pid=$btn.data('product-id'), target=$btn.data('target-language');
      $btn.prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_ai_preview',{product_id:pid,target_language:target}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Preview failed.');
        var x=(r.data&&r.data.result)||{}, t=x.translated||{};
        var html='<div class="vcm-preview-banner is-ready"><strong>AI translation preview</strong><span>No content has been written. Snapshot is created only when you apply the translation.</span></div>';
        html+='<div class="vcm-ai-preview-grid">';
        ['title','short_description','description','slug','seo_title','seo_description','focus_keywords'].forEach(function(k){html+='<div><strong>'+k.replace('_',' ')+'</strong><div>'+VCM.esc(t[k]||'')+'</div></div>';});
        html+='</div><div class="vcm-preview-actions"><button type="button" class="button button-primary vcm-preview-apply" data-product-id="'+VCM.esc(pid)+'" data-target-language="'+VCM.esc(target)+'">Apply translation</button></div>';
        VCM.openModal('Translation Preview','Product #'+pid+' → '+String(target).toUpperCase(),html);
      }).fail(function(xhr){VCM.toast(VCM.errorMessage(xhr,'Preview failed. Check WooCommerce > Variation Manager > AI Settings > Test Gemini connection.'),'error');}).always(function(){ $btn.prop('disabled',false).removeClass('is-loading'); });
    },

    clean: function(btn){
      var $btn=$(btn); if(!window.confirm('Clean this product content with Gemini? A rollback snapshot will be created first.')) return;
      $btn.prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_ai_clean',{product_id:$btn.data('product-id')}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Clean failed.');
        VCM.toast('Product content cleaned. Snapshot created.'); setTimeout(function(){window.location.reload();},500);
      }).fail(function(xhr){VCM.toast(VCM.errorMessage(xhr,'Clean failed.'),'error');}).always(function(){ $btn.prop('disabled',false).removeClass('is-loading'); });
    },

    translateAll: function(){
      if(VCM.busy) return;
      var source=$('select[name=\"source\"]').val()||'de';
      var target=$('select[name=\"target\"]').val()||'';
      var search=$('input[name=\"s\"]').val()||'';
      if(!source||!target||source===target){ VCM.toast('Choose different source and target languages.','error'); return; }
      if(!window.confirm('Generate and apply original target-language copy for every found product with a linked target page? This will update title, URL slug, short description, full description, SEO metadata and focus keywords. Snapshots are created before each change.')) return;
      VCM.busy=true;
      var $btn=$('#vcm-ai-translate-all').prop('disabled',true).addClass('is-loading');
      $('#vcm-ai-progress').text('Starting…');
      var state={page:1,total:0,done:0,success:0,skipped:0,errors:0};
      function step(){
        VCM.post('vcm_ai_translate_batch',{source_language:source,target_language:target,search:search,page:state.page,batch:2,mode:'smart'}).done(function(r){
          if(!r.success) throw new Error((r.data&&r.data.message)||'Bulk translation failed.');
          var d=r.data||{}; state.total=parseInt(d.total||state.total,10); state.done += parseInt(d.processed||0,10); state.success += parseInt(d.success||0,10); state.skipped += parseInt(d.skipped||0,10); state.errors += (d.errors||[]).length;
          $('#vcm-ai-progress').text('Generating · '+state.done+' / '+state.total+' · successful '+state.success+(state.errors?' · errors '+state.errors:''));
          if(!d.done){ state.page=1; setTimeout(step,120); return; }
          VCM.busy=false; $btn.prop('disabled',false).removeClass('is-loading'); $('#vcm-ai-progress').text('Complete · '+state.success+' updated · '+state.skipped+' skipped'+(state.errors?' · '+state.errors+' errors':''));
          VCM.toast(state.success+' product(s) generated and translated.'+(state.errors?' '+state.errors+' error(s) logged.':''), state.errors?'error':'success');
          setTimeout(function(){window.location.reload();},700);
        }).fail(function(xhr){ VCM.busy=false; $btn.prop('disabled',false).removeClass('is-loading'); VCM.toast(VCM.errorMessage(xhr,'Bulk translation failed.'),'error'); });
      }
      step();
    },

    bulkAI: function(){
      var ids=[]; $('.vcm-ai-row-check:checked').each(function(){ids.push(parseInt($(this).val(),10));});
      if(!ids.length){VCM.toast('Select at least one product.','error');return;}
      var action=$('#vcm-ai-bulk-action').val(), $run=$('#vcm-ai-bulk-run');
      $run.prop('disabled',true).addClass('is-loading'); var index=0, target=$('.vcm-ai-translate').first().data('target-language')||'';
      function next(){
        if(index>=ids.length){$run.prop('disabled',false).removeClass('is-loading');$('#vcm-ai-progress').text('Done.');VCM.toast('Bulk AI action complete.');setTimeout(function(){window.location.reload();},550);return;}
        var pid=ids[index++], payload={product_id:pid};
        if(action==='translate'){payload.target_language=target; VCM.post('vcm_ai_translate',payload).done(function(){$('#vcm-ai-progress').text(index+' / '+ids.length);next();}).fail(function(xhr){VCM.toast(VCM.errorMessage(xhr,'Translation failed for product #'+pid),'error');$('#vcm-ai-progress').text(index+' / '+ids.length+' · continuing');next();});return;}
        var endpoint=action==='rewrite'?'vcm_ai_rewrite':(action==='clean'?'vcm_ai_clean':'vcm_ai_seo');
        VCM.post(endpoint,payload).done(function(){ $('#vcm-ai-progress').text(index+' / '+ids.length); next(); }).fail(function(xhr){VCM.toast(VCM.errorMessage(xhr,'AI action failed for product #'+pid),'error'); $('#vcm-ai-progress').text(index+' / '+ids.length+' · continuing'); next();});
      }
      $('#vcm-ai-progress').text('Starting…'); next();
    },

    rollback: function(btn){
      var $btn=$(btn); if(!window.confirm('Restore the exact content saved in this snapshot?')) return;
      $btn.prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_ai_rollback',{snapshot_id:$btn.data('snapshot-id')}).done(function(r){
        if(!r.success) throw new Error((r.data&&r.data.message)||'Rollback failed.');
        VCM.toast('Snapshot restored.'); setTimeout(function(){window.location.reload();},500);
      }).fail(function(xhr){VCM.toast(VCM.errorMessage(xhr,'Rollback failed.'),'error');}).always(function(){ $btn.prop('disabled',false).removeClass('is-loading'); });
    },

    openModal: function(title,subtitle,body){var $m=$('#vcm-ai-modal');if(!$m.length){$m=$('<div id="vcm-ai-modal" class="vcm-modal" aria-hidden="true"><div class="vcm-modal-backdrop"></div><div class="vcm-modal-dialog" role="dialog" aria-modal="true"><div class="vcm-modal-head"><div><h2></h2><p></p></div><button type="button" class="button-link vcm-modal-close">×</button></div><div class="vcm-modal-body"></div></div></div>');$('body').append($m);}$m.find('h2').text(title||'Preview');$m.find('.vcm-modal-head p').text(subtitle||'');$m.find('.vcm-modal-body').html(body||'');$m.attr('aria-hidden','false').addClass('is-open');},
    closeModal: function(){$('#vcm-ai-modal').attr('aria-hidden','true').removeClass('is-open');},
    esc: function(v){return $('<div>').text(v==null?'':String(v)).html();},

    testAI: function(btn){
      var $btn=$(btn); $btn.prop('disabled',true).addClass('is-loading');
      VCM.post('vcm_ai_test').done(function(r){if(!r.success) throw new Error((r.data&&r.data.message)||'Connection test failed.');var tier=(r.data.active_tier||'auto').toUpperCase();VCM.toast('Gemini works · '+tier+' project · '+(r.data.model||'model'));}).fail(function(xhr){VCM.toast(VCM.errorMessage(xhr,'Gemini connection failed.'),'error');}).always(function(){ $btn.prop('disabled',false).removeClass('is-loading'); });
    }
  };

  $(document).on('click','#vcm-run-scan',function(e){e.preventDefault();VCM.runScan();});
  $(document).on('click','#vcm-apply-bulk',function(e){e.preventDefault();VCM.bulkConflict();});
  $(document).on('click','#vcm-quarantine-all',function(e){e.preventDefault();VCM.quarantineAll();});
  $(document).on('change','#vcm-check-all',function(){$('.vcm-row-check').prop('checked',this.checked);});
  $(document).on('click','.vcm-toggle-details',function(){var $b=$(this),$r=$b.closest('tr'),$d=$r.next('.vcm-details-row'),open=$d.is(':visible');$d.stop(true,true).slideToggle(150);$b.attr('aria-expanded',open?'false':'true').text(open?'Details':'Hide details');});
  $(document).on('click','.vcm-quarantine',function(e){e.preventDefault();VCM.quarantine(this);});
  $(document).on('click','.vcm-approve',function(e){e.preventDefault();VCM.approve(this);});
  $(document).on('click','.vcm-restore',function(e){e.preventDefault();VCM.restore(this);});
  $(document).on('click','.vcm-recheck',function(e){e.preventDefault();VCM.recheck(this);});
  $(document).on('change','#vcm-ai-check-all',function(){$('.vcm-ai-row-check').prop('checked',this.checked);});
  $(document).on('click','.vcm-ai-translate',function(e){e.preventDefault();VCM.aiTranslate(this,true);});
  $(document).on('click','.vcm-ai-preview',function(e){e.preventDefault();VCM.aiPreview(this);});
  $(document).on('click','.vcm-ai-clean',function(e){e.preventDefault();VCM.clean(this);});
  $(document).on('click','.vcm-preview-apply',function(e){e.preventDefault();var b=this;VCM.closeModal();setTimeout(function(){VCM.aiTranslate(b,true);},50);});
  $(document).on('click','.vcm-ai-rewrite',function(e){e.preventDefault();VCM.aiRewrite(this);});
  $(document).on('click','.vcm-ai-seo',function(e){e.preventDefault();VCM.aiSeo(this);});
  $(document).on('click','#vcm-ai-bulk-run',function(e){e.preventDefault();VCM.bulkAI();});
  $(document).on('click','#vcm-ai-translate-all',function(e){e.preventDefault();VCM.translateAll();});
  $(document).on('click','.vcm-ai-rollback',function(e){e.preventDefault();VCM.rollback(this);});
  $(document).on('click','.vcm-modal-close,.vcm-modal-backdrop',function(){VCM.closeModal();});
  $(document).on('keydown',function(e){if(e.key==='Escape')VCM.closeModal();});
  $(document).on('click','#vcm-ai-test',function(e){e.preventDefault();VCM.testAI(this);});
  $(document).on('click','#vcm-ai-rescan',function(e){e.preventDefault();VCM.scanCatalog();});
  $(document).on('click','#vcm-missing-rescan',function(e){e.preventDefault();VCM.missingScan();});
  $(document).on('click','#vcm-health-refresh',function(e){e.preventDefault();window.location.reload();});
  $(document).on('click','.vcm-ai-translate-current',function(e){
    e.preventDefault(); var $b=$(this), target=$b.closest('.vcm-product-ai-box').find('.vcm-ai-target').val(); $b.data('target-language',target); VCM.aiTranslate($b,true);
  });
})(jQuery);
