<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AI content engine for WooCommerce products.
 * Uses the site's own Gemini API key and never ships a shared key.
 */
final class VCM_AI {
	const SETTINGS_OPTION = 'vcm_ai_settings';
	const GLOSSARY_OPTION = 'vcm_ai_glossary';
	const DB_VERSION      = '1.0.0';
	const PROMPT_VERSION  = '2.0';

	private static $last_error = '';
	private static $last_model = '';
	private static $last_tier = '';
	public static function last_used_credential() { return self::$last_tier; }

	public static function last_error() {
		return self::$last_error;
	}

	public static function defaults() {
		return array(
			'provider_mode' => 'ai_studio', // auto|ai_studio|vertex_express
			'api_key'       => '', // legacy single-key setting
			'free_api_key'  => '',
			'paid_api_key'  => '',
			'vertex_api_key' => '',
			'usage_mode'    => 'free', // auto|free|paid
			'model'         => 'gemini-3.5-flash-lite',
			'fallback_model' => 'gemini-3.1-flash-lite',
			'vertex_model' => 'gemini-3.5-flash',
			'vertex_fallback_model' => 'gemini-3.1-flash-lite',
			'tone'          => 'Natural / Native E-commerce',
			'default_targets' => 'en,fr,it',
			'preserve_html' => 1,
			'api_version_mode' => 'v1beta', // v1beta is the documented GenerateContent REST endpoint; v1 remains optional
			'auth_mode' => 'auto', // auto|header|query
		);
	}

	public static function settings() {
		$value = get_option( self::SETTINGS_OPTION, array() );
		$value = is_array( $value ) ? $value : array();
		$out = wp_parse_args( $value, self::defaults() );
		// Migrate the previous single-key setting to the free key slot once.
		if ( empty( $out['free_api_key'] ) && ! empty( $out['api_key'] ) ) {
			$out['free_api_key'] = (string) $out['api_key'];
		}
		if ( ! in_array( $out['usage_mode'], array( 'auto', 'free', 'paid' ), true ) ) {
			$out['usage_mode'] = 'auto';
		}
		if ( ! in_array( $out['provider_mode'], array( 'auto', 'ai_studio', 'vertex_express' ), true ) ) {
			$out['provider_mode'] = 'auto';
		}
		$normalized_model = preg_replace( '#^models/#', '', (string) $out['model'] );
		$normalized_fallback = preg_replace( '#^models/#', '', (string) $out['fallback_model'] );
		// 2.5 and old preview IDs may be unavailable to new projects. Use the current stable translation-oriented models.
		$legacy = array( 'gemini-2.0-flash', 'gemini-2.0-flash-lite', 'gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-3.1-flash-lite-preview', 'gemini-3-flash-preview' );
		$changed = false;
		if ( in_array( $normalized_model, $legacy, true ) || '' === $normalized_model ) {
			$out['model'] = 'gemini-3.1-flash-lite';
			$changed = true;
		}
		if ( in_array( $normalized_fallback, $legacy, true ) || '' === $normalized_fallback ) {
			$out['fallback_model'] = 'gemini-3.5-flash-lite';
			$changed = true;
		}
		if ( $changed ) {
			update_option( self::SETTINGS_OPTION, $out, false );
		}
		return $out;
	}

	public static function update_settings( $settings ) {
		$current = self::settings();
		$free_key  = isset( $settings['free_api_key'] ) ? trim( (string) $settings['free_api_key'] ) : ( $current['free_api_key'] ?? $current['api_key'] );
		$paid_key  = isset( $settings['paid_api_key'] ) ? trim( (string) $settings['paid_api_key'] ) : ( $current['paid_api_key'] ?? '' );
		$clean   = array(
			'provider_mode'  => isset( $settings['provider_mode'] ) && in_array( $settings['provider_mode'], array( 'auto', 'ai_studio', 'vertex_express' ), true ) ? $settings['provider_mode'] : ( $current['provider_mode'] ?? 'auto' ),
			'api_key'         => $free_key, // keep backward compatibility
			'free_api_key'    => $free_key,
			'paid_api_key'    => $paid_key,
			'vertex_api_key'  => isset( $settings['vertex_api_key'] ) ? trim( (string) $settings['vertex_api_key'] ) : ( $current['vertex_api_key'] ?? '' ),
			'usage_mode'      => isset( $settings['usage_mode'] ) && in_array( $settings['usage_mode'], array( 'auto', 'free', 'paid' ), true ) ? $settings['usage_mode'] : 'auto',
			'model'           => isset( $settings['model'] ) ? sanitize_text_field( $settings['model'] ) : $current['model'],
			'fallback_model'  => isset( $settings['fallback_model'] ) ? sanitize_text_field( $settings['fallback_model'] ) : $current['fallback_model'],
			'vertex_model'  => isset( $settings['vertex_model'] ) ? sanitize_text_field( $settings['vertex_model'] ) : ( $current['vertex_model'] ?? 'gemini-3.5-flash' ),
			'vertex_fallback_model'  => isset( $settings['vertex_fallback_model'] ) ? sanitize_text_field( $settings['vertex_fallback_model'] ) : ( $current['vertex_fallback_model'] ?? 'gemini-3.1-flash-lite' ),
			'tone'            => isset( $settings['tone'] ) ? sanitize_text_field( $settings['tone'] ) : $current['tone'],
			'default_targets' => isset( $settings['default_targets'] ) ? sanitize_text_field( $settings['default_targets'] ) : $current['default_targets'],
			'preserve_html'   => ! empty( $settings['preserve_html'] ) ? 1 : 0,
			'api_version_mode' => isset( $settings['api_version_mode'] ) && in_array( $settings['api_version_mode'], array( 'auto', 'v1', 'v1beta' ), true ) ? $settings['api_version_mode'] : ( $current['api_version_mode'] ?? 'auto' ),
			'auth_mode' => isset( $settings['auth_mode'] ) && in_array( $settings['auth_mode'], array( 'auto', 'header', 'query' ), true ) ? $settings['auth_mode'] : ( $current['auth_mode'] ?? 'auto' ),
		);
		update_option( self::SETTINGS_OPTION, $clean, false );
		foreach ( array( $clean['free_api_key'], $clean['paid_api_key'] ) as $key ) {
			if ( '' !== $key ) {
				delete_transient( 'vcm_ai_models_' . md5( $key ) );
			}
		}
		return $clean;
	}

	public static function create_or_upgrade_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		$logs = self::logs_table();
		$sql  = "CREATE TABLE {$logs} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			product_id bigint(20) unsigned NOT NULL DEFAULT 0,
			target_product_id bigint(20) unsigned NOT NULL DEFAULT 0,
			action varchar(40) NOT NULL DEFAULT '',
			source_language varchar(20) NOT NULL DEFAULT '',
			target_language varchar(20) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'success',
			message text NULL,
			created_at datetime NULL,
			PRIMARY KEY (id),
			KEY product_id (product_id),
			KEY target_product_id (target_product_id),
			KEY action (action),
			KEY status (status),
			KEY created_at (created_at)
		) {$charset};";
		dbDelta( $sql );

		$snapshots = self::snapshots_table();
		$sql       = "CREATE TABLE {$snapshots} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			source_product_id bigint(20) unsigned NOT NULL DEFAULT 0,
			target_product_id bigint(20) unsigned NOT NULL DEFAULT 0,
			action varchar(40) NOT NULL DEFAULT '',
			target_language varchar(20) NOT NULL DEFAULT '',
			fields_json longtext NULL,
			status varchar(20) NOT NULL DEFAULT 'active',
			created_at datetime NULL,
			PRIMARY KEY (id),
			KEY source_product_id (source_product_id),
			KEY target_product_id (target_product_id),
			KEY action (action),
			KEY status (status),
			KEY created_at (created_at)
		) {$charset};";
		dbDelta( $sql );

		$memory = self::memory_table();
		$sql    = "CREATE TABLE {$memory} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			memory_hash char(64) NOT NULL,
			source_language varchar(20) NOT NULL DEFAULT '',
			target_language varchar(20) NOT NULL DEFAULT '',
			payload longtext NULL,
			created_at datetime NULL,
			PRIMARY KEY (id),
			UNIQUE KEY memory_hash (memory_hash),
			KEY source_language (source_language),
			KEY target_language (target_language)
		) {$charset};";
		dbDelta( $sql );
	}

	public static function logs_table() {
		global $wpdb;
		return $wpdb->prefix . 'vcm_ai_logs';
	}

	public static function snapshots_table() {
		global $wpdb;
		return $wpdb->prefix . 'vcm_ai_snapshots';
	}

	public static function memory_table() {
		global $wpdb;
		return $wpdb->prefix . 'vcm_ai_memory';
	}

	public static function language_labels() {
		return array(
			'de' => 'German', 'en' => 'English', 'fr' => 'French', 'it' => 'Italian',
			'es' => 'Spanish', 'nl' => 'Dutch', 'tr' => 'Turkish', 'fa' => 'Persian',
			'ar' => 'Arabic', 'pt' => 'Portuguese', 'pl' => 'Polish', 'ru' => 'Russian',
		);
	}

	public static function active_languages() {
		$labels = self::language_labels();
		$out    = array();

		if ( function_exists( 'apply_filters' ) ) {
			$wpml = apply_filters( 'wpml_active_languages', null, array( 'skip_missing' => 0, 'orderby' => 'code' ) );
			if ( is_array( $wpml ) && ! empty( $wpml ) ) {
				foreach ( $wpml as $code => $item ) {
					$code = sanitize_key( $code );
					if ( ! $code ) {
						continue;
					}
					$out[ $code ] = isset( $item['native_name'] ) ? $item['native_name'] : ( isset( $item['translated_name'] ) ? $item['translated_name'] : strtoupper( $code ) );
				}
			}
		}

		if ( empty( $out ) && function_exists( 'pll_languages_list' ) ) {
			$codes = pll_languages_list( array( 'fields' => 'slug' ) );
			foreach ( (array) $codes as $code ) {
				$code       = sanitize_key( $code );
				$out[ $code ] = isset( $labels[ $code ] ) ? $labels[ $code ] : strtoupper( $code );
			}
		}

		if ( empty( $out ) ) {
			$out = $labels;
		}
		return $out;
	}

	public static function product_language( $product_id ) {
		$product_id = absint( $product_id );
		if ( ! $product_id ) {
			return '';
		}
		if ( function_exists( 'apply_filters' ) ) {
			$wpml = apply_filters( 'wpml_post_language_details', null, $product_id );
			if ( is_array( $wpml ) && ! empty( $wpml['language_code'] ) ) {
				return strtolower( sanitize_key( $wpml['language_code'] ) );
			}
		}
		if ( function_exists( 'pll_get_post_language' ) ) {
			$lang = pll_get_post_language( $product_id, 'slug' );
			if ( $lang ) {
				return strtolower( sanitize_key( $lang ) );
			}
		}
		return self::detect_language( $product_id );
	}

	public static function detect_language( $product_id ) {
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : false;
		if ( ! $product ) {
			return '';
		}
		$text = wp_strip_all_tags( $product->get_name() . ' ' . $product->get_short_description() . ' ' . $product->get_description() );
		if ( '' === trim( $text ) ) {
			return '';
		}

		$lower = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
		if ( preg_match( '/[\x{0600}-\x{06FF}]/u', $text ) ) {
			$fa_words = preg_match_all( '/\b(?:است|این|برای|با|در|که|را|محصول|رنگ|قیمت|توضیحات)\b/u', $lower, $m );
			$ar_words = preg_match_all( '/\b(?:هذا|هذه|من|في|على|مع|المنتج|سعر|لون)\b/u', $lower, $m );
			return $fa_words >= $ar_words ? 'fa' : 'ar';
		}

		$sets = array(
			'de' => array( 'und', 'der', 'die', 'das', 'ist', 'für', 'mit', 'von', 'auf', 'produkt', 'nicht', 'und' ),
			'en' => array( 'the', 'and', 'is', 'for', 'with', 'from', 'product', 'this', 'that', 'your', 'not' ),
			'fr' => array( 'le', 'la', 'les', 'des', 'et', 'est', 'pour', 'avec', 'produit', 'dans', 'une' ),
			'it' => array( 'il', 'lo', 'la', 'gli', 'le', 'e', 'per', 'con', 'prodotto', 'una', 'sono' ),
			'es' => array( 'el', 'la', 'los', 'las', 'y', 'es', 'para', 'con', 'producto', 'una', 'que' ),
			'nl' => array( 'de', 'het', 'een', 'en', 'is', 'voor', 'met', 'product', 'van', 'niet' ),
			'tr' => array( 've', 'bir', 'ile', 'için', 'ürün', 'olan', 'bu', 'ş', 'değil' ),
			'pt' => array( 'o', 'a', 'os', 'as', 'e', 'é', 'para', 'com', 'produto', 'uma' ),
			'pl' => array( 'i', 'jest', 'dla', 'z', 'na', 'produkt', 'to', 'nie', 'oraz', 'który' ),
			'ru' => array( 'и', 'это', 'для', 'с', 'товар', 'цена', 'как', 'не', 'что', 'на' ),
		);
		$scores = array();
		foreach ( $sets as $lang => $words ) {
			$scores[ $lang ] = 0;
			foreach ( $words as $word ) {
				$scores[ $lang ] += preg_match_all( '/(?<![\p{L}])' . preg_quote( $word, '/' ) . '(?![\p{L}])/u', $lower, $m );
			}
		}
		arsort( $scores );
		$best = key( $scores );
		return ( $best && $scores[ $best ] > 0 ) ? $best : '';
	}

	public static function query_products( $source_language, $search, $page, $per_page ) {
		global $wpdb;
		$source_language = sanitize_key( $source_language );
		$search          = sanitize_text_field( $search );
		$page            = max( 1, absint( $page ) );
		$per_page        = min( 5000, max( 5, absint( $per_page ) ) );

		if ( self::has_wpml() ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			$where = "p.post_type='product' AND p.post_status IN ('publish','private','draft') AND t.element_type='post_product'";
			$args = array();
			if ( $source_language ) { $where .= ' AND t.language_code=%s'; $args[] = $source_language; }
			if ( '' !== $search ) {
				$where .= ' AND (p.post_title LIKE %s OR p.post_content LIKE %s OR p.post_excerpt LIKE %s)';
				$args[] = $like; $args[] = $like; $args[] = $like;
			}
			$count_sql = "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p INNER JOIN {$wpdb->prefix}icl_translations t ON t.element_id=p.ID WHERE {$where}";
			$count = absint( $wpdb->get_var( empty( $args ) ? $count_sql : $wpdb->prepare( $count_sql, $args ) ) );
			$args2 = $args;
			$args2[] = $per_page;
			$args2[] = ( $page - 1 ) * $per_page;
			$rows_sql = "SELECT DISTINCT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->prefix}icl_translations t ON t.element_id=p.ID WHERE {$where} ORDER BY p.ID DESC LIMIT %d OFFSET %d";
			$ids = $wpdb->get_col( $wpdb->prepare( $rows_sql, $args2 ) );
			return array( 'ids' => array_map( 'absint', $ids ), 'total' => $count );
		}

		if ( function_exists( 'pll_get_post_language' ) ) {
			$language_tax = 'language';
			$where = "p.post_type='product' AND p.post_status IN ('publish','private','draft') AND tt.taxonomy=%s";
			$args = array( $language_tax );
			if ( $source_language ) { $where .= ' AND t.slug=%s'; $args[] = $source_language; }
			if ( '' !== $search ) {
				$like = '%' . $wpdb->esc_like( $search ) . '%';
				$where .= ' AND (p.post_title LIKE %s OR p.post_content LIKE %s OR p.post_excerpt LIKE %s)';
				$args[] = $like; $args[] = $like; $args[] = $like;
			}
			$count_sql = "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id=p.ID INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id INNER JOIN {$wpdb->terms} t ON t.term_id=tt.term_id WHERE {$where}";
			$total = absint( $wpdb->get_var( $wpdb->prepare( $count_sql, $args ) ) );
			$args2 = $args; $args2[] = $per_page; $args2[] = ( $page - 1 ) * $per_page;
			$rows_sql = "SELECT DISTINCT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id=p.ID INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id INNER JOIN {$wpdb->terms} t ON t.term_id=tt.term_id WHERE {$where} ORDER BY p.ID DESC LIMIT %d OFFSET %d";
			$ids = $wpdb->get_col( $wpdb->prepare( $rows_sql, $args2 ) );
			return array( 'ids' => array_map( 'absint', $ids ), 'total' => $total );
		}

		$args = array(
			'post_type' => 'product', 'post_status' => array( 'publish', 'private', 'draft' ),
			'posts_per_page' => min( 5000, max( 500, $per_page * max( 1, $page ) ) ),
			'paged' => 1, 'fields' => 'ids', 'no_found_rows' => true, 'suppress_filters' => true,
		);
		if ( $search ) {
			$args['s'] = $search;
		}
		$candidates = get_posts( $args );
		$filtered = array();
		foreach ( $candidates as $id ) {
			$lang = self::detect_language( $id );
			if ( ! $source_language || $source_language === $lang ) {
				$filtered[] = absint( $id );
			}
		}
		$total = count( $filtered );
		return array( 'ids' => array_slice( $filtered, ( $page - 1 ) * $per_page, $per_page ), 'total' => $total );
	}


	public static function missing_language_batch( $source_language, $target_language, $page, $per_page ) {
		$source_language = sanitize_key( $source_language );
		$target_language = sanitize_key( $target_language );
		$page = max( 1, absint( $page ) );
		$per_page = min( 30, max( 5, absint( $per_page ) ) );
		$active = self::active_languages();
		$result = self::query_products( $source_language, '', $page, $per_page );
		$rows = array();
		$seen = array();
		foreach ( (array) $result['ids'] as $id ) {
			$id = absint( $id );
			if ( ! $id ) { continue; }
			$group = self::catalog_scan_product( $id, $active, $target_language );
			if ( empty( $group ) ) { continue; }
			$canonical = absint( $group['canonical_id'] ?? $id );
			if ( isset( $seen[ $canonical ] ) ) { continue; }
			$current = sanitize_key( $group['language'] ?? '' );
			if ( $source_language && $current !== $source_language ) { continue; }
			$missing = (array) ( $group['missing_languages'] ?? array() );
			if ( $target_language ) {
				if ( empty( $missing[ $target_language ] ) ) { continue; }
			} elseif ( empty( $missing ) ) {
				continue;
			}
			$seen[ $canonical ] = true;
			$rows[] = array(
				'id' => $id,
				'canonical_id' => $canonical,
				'title' => $group['title'],
				'sku' => $group['sku'],
				'type' => $group['type'],
				'price' => $group['price'],
				'image' => $group['image'],
				'language' => $current,
				'languages_present' => $group['languages_present'],
				'missing_languages' => $missing,
				'translations' => $group['translations'],
				'issues' => $group['issues'],
				'issue_labels' => $group['issue_labels'],
				'edit_url' => $group['edit_url'],
				'view_url' => $group['view_url'],
			);
		}
		return array(
			'rows' => $rows,
			'total_source' => absint( $result['total'] ),
			'processed' => count( (array) $result['ids'] ),
			'page' => $page,
			'next_page' => ( ( $page * $per_page ) < absint( $result['total'] ) ) ? $page + 1 : 0,
			'done' => ( ( $page * $per_page ) >= absint( $result['total'] ) ),
		);
	}

	public static function catalog_scan_batch( $page, $per_page, $target_language = '', $only_incomplete = true ) {
		$page = max( 1, absint( $page ) );
		$per_page = min( 25, max( 5, absint( $per_page ) ) );
		$target_language = sanitize_key( $target_language );
		$ids = get_posts( array(
			'post_type' => 'product',
			'post_status' => array( 'publish', 'private', 'draft' ),
			'posts_per_page' => $per_page,
			'paged' => $page,
			'fields' => 'ids',
			'no_found_rows' => false,
			'suppress_filters' => true,
		) );
		$count = new WP_Query( array(
			'post_type' => 'product',
			'post_status' => array( 'publish', 'private', 'draft' ),
			'posts_per_page' => 1,
			'fields' => 'ids',
			'no_found_rows' => false,
			'suppress_filters' => true,
		) );
		$total = (int) $count->found_posts;
		$rows = array();
		$seen_groups = array();
		$active = self::active_languages();
		foreach ( $ids as $id ) {
			$row = self::catalog_scan_product( $id, $active, $target_language );
			if ( ! $row ) { continue; }
			$group_key = isset( $row['group_key'] ) ? $row['group_key'] : (string) $id;
			$canonical_id = isset( $row['canonical_id'] ) ? absint( $row['canonical_id'] ) : absint( $id );
			if ( absint( $id ) !== $canonical_id || isset( $seen_groups[ $group_key ] ) ) { continue; }
			$seen_groups[ $group_key ] = true;
			if ( ! empty( $row['issues'] ) ) {
				$rows[] = $row;
			} elseif ( ! $only_incomplete ) {
				$rows[] = $row;
			}
		}
		$last_page = (int) ceil( $total / $per_page );
		$done = $page >= max( 1, $last_page );
		return array(
			'total' => $total,
			'processed' => min( $total, $page * $per_page ),
			'page' => $page,
			'next_page' => $done ? 0 : $page + 1,
			'done' => $done,
			'rows' => $rows,
		);
	}

	public static function catalog_scan_product( $product_id, $active_languages = null, $target_language = '' ) {
		$product_id = absint( $product_id );
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : false;
		if ( ! $product ) { return array(); }
		if ( null === $active_languages ) { $active_languages = self::active_languages(); }
		$translations = self::translation_group( $product_id );
		$current_lang = self::product_language( $product_id );
		$present = array();
		foreach ( $translations as $code => $tid ) {
			$code = sanitize_key( $code );
			if ( $code ) { $present[ $code ] = absint( $tid ); }
		}
		if ( $current_lang && empty( $present[ $current_lang ] ) ) { $present[ $current_lang ] = $product_id; }
		$missing = array();
		foreach ( $active_languages as $code => $label ) {
			if ( empty( $present[ sanitize_key( $code ) ] ) ) {
				$missing[ sanitize_key( $code ) ] = $label;
			}
		}
		if ( $target_language && empty( $present[ $target_language ] ) && ! isset( $missing[ $target_language ] ) ) {
			$missing[ $target_language ] = isset( $active_languages[ $target_language ] ) ? $active_languages[ $target_language ] : strtoupper( $target_language );
		}

		$issues = array();
		if ( ! $current_lang ) { $issues[] = 'language_unknown'; }
		if ( ! $product->get_name() ) { $issues[] = 'empty_title'; }
		if ( ! trim( wp_strip_all_tags( $product->get_short_description() ) ) ) { $issues[] = 'empty_short_description'; }
		if ( ! trim( wp_strip_all_tags( $product->get_description() ) ) ) { $issues[] = 'empty_description'; }
		if ( self::has_seo_plugin() ) {
			if ( ! self::get_seo_meta( $product_id, 'title' ) ) { $issues[] = 'missing_seo_title'; }
			if ( ! self::get_seo_meta( $product_id, 'description' ) ) { $issues[] = 'missing_seo_description'; }
		}
		if ( ! empty( $missing ) ) { $issues[] = 'missing_translation'; }

		$translation_rows = array();
		foreach ( $present as $code => $tid ) {
			$tid = absint( $tid );
			if ( ! $tid || ! function_exists( 'wc_get_product' ) ) { continue; }
			$tp = wc_get_product( $tid );
			if ( ! $tp ) { continue; }
			$tissues = array();
			if ( ! trim( wp_strip_all_tags( $tp->get_name() ) ) ) { $tissues[] = 'empty_title'; }
			if ( ! trim( wp_strip_all_tags( $tp->get_short_description() ) ) ) { $tissues[] = 'empty_short_description'; }
			if ( ! trim( wp_strip_all_tags( $tp->get_description() ) ) ) { $tissues[] = 'empty_description'; }
			if ( self::has_seo_plugin() ) {
				if ( ! self::get_seo_meta( $tid, 'title' ) ) { $tissues[] = 'missing_seo_title'; }
				if ( ! self::get_seo_meta( $tid, 'description' ) ) { $tissues[] = 'missing_seo_description'; }
			}
			if ( ! empty( $tissues ) ) {
				$issues[] = 'target_content_incomplete';
			}
			$translation_rows[ $code ] = array(
				'id' => $tid,
				'title' => $tp->get_name(),
				'issues' => $tissues,
				'image' => self::image_url( $tid ),
			);
		}

		$problem_labels = array(
			'missing_translation' => 'Missing language',
			'target_content_incomplete' => 'Target content incomplete',
			'empty_title' => 'Title missing',
			'empty_short_description' => 'Short description missing',
			'empty_description' => 'Description missing',
			'missing_seo_title' => 'SEO title missing',
			'missing_seo_description' => 'SEO description missing',
			'language_unknown' => 'Language unknown',
		);
		$labels = array();
		foreach ( array_unique( $issues ) as $issue ) {
			if ( isset( $problem_labels[ $issue ] ) ) { $labels[] = $problem_labels[ $issue ]; }
		}
		$price = '';
		if ( function_exists( 'wc_price' ) && '' !== (string) $product->get_price() ) { $price = wp_strip_all_tags( wc_price( $product->get_price() ) ); }
		$status = empty( $issues ) ? 'complete' : ( in_array( 'missing_translation', $issues, true ) ? 'missing_translation' : 'content_issue' );
		$all_ids = array_values( array_unique( array_filter( array_merge( array( $product_id ), array_values( $present ) ) ) ) );
		sort( $all_ids, SORT_NUMERIC );
		$group_key = implode( ',', $all_ids );
		$canonical_id = ! empty( $all_ids ) ? absint( $all_ids[0] ) : $product_id;
		return array(
			'id' => $product_id,
			'title' => $product->get_name(),
			'sku' => $product->get_sku(),
			'price' => $price,
			'stock_status' => $product->get_stock_status(),
			'type' => $product->get_type(),
			'image' => self::image_url( $product_id ),
			'edit_url' => get_edit_post_link( $product_id, '' ),
			'view_url' => get_permalink( $product_id ),
			'language' => $current_lang,
			'languages_present' => $present,
			'missing_languages' => $missing,
			'translations' => $translation_rows,
			'issues' => array_values( array_unique( $issues ) ),
			'issue_labels' => array_values( array_unique( $labels ) ),
			'status' => $status,
			'group_key' => $group_key,
			'canonical_id' => $canonical_id,
		);
	}

	private static function translation_group( $product_id ) {
		$product_id = absint( $product_id );
		if ( ! $product_id ) { return array(); }
		global $wpdb;
		$out = array();
		if ( self::has_wpml() ) {
			$trid = apply_filters( 'wpml_element_trid', null, $product_id, 'post_product' );
			if ( $trid ) {
				$table = $wpdb->prefix . 'icl_translations';
				$rows = $wpdb->get_results( $wpdb->prepare( "SELECT element_id, language_code FROM {$table} WHERE trid=%d AND element_type=%s", absint( $trid ), 'post_product' ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				foreach ( (array) $rows as $row ) {
					$code = sanitize_key( $row['language_code'] ?? '' );
					if ( $code && ! empty( $row['element_id'] ) ) { $out[ $code ] = absint( $row['element_id'] ); }
				}
			}
		}
		if ( empty( $out ) && function_exists( 'pll_get_post_translations' ) ) {
			$rows = pll_get_post_translations( $product_id );
			foreach ( (array) $rows as $code => $tid ) {
				$code = sanitize_key( $code );
				if ( $code && $tid ) { $out[ $code ] = absint( $tid ); }
			}
		}
		return $out;
	}


	private static function has_wpml() {
		return defined( 'ICL_SITEPRESS_VERSION' );
	}

	public static function translation_product_id( $product_id, $target_language ) {
		$product_id      = absint( $product_id );
		$target_language = sanitize_key( $target_language );
		if ( ! $product_id || ! $target_language ) {
			return 0;
		}
		if ( self::has_wpml() ) {
			$id = apply_filters( 'wpml_object_id', $product_id, 'product', true, $target_language );
			return absint( $id );
		}
		if ( function_exists( 'pll_get_post' ) ) {
			return absint( pll_get_post( $product_id, $target_language ) );
		}
		$source = self::product_language( $product_id );
		return $source === $target_language ? $product_id : 0;
	}

	public static function image_url( $product_id ) {
		$image_id = get_post_thumbnail_id( absint( $product_id ) );
		if ( $image_id ) {
			$url = wp_get_attachment_image_url( $image_id, 'woocommerce_thumbnail' );
			if ( $url ) { return $url; }
		}
		return function_exists( 'wc_placeholder_img_src' ) ? wc_placeholder_img_src( 'woocommerce_thumbnail' ) : '';
	}

	public static function product_fields( $product_id ) {
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : false;
		if ( ! $product ) {
			return false;
		}
		$categories = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'names' ) );
		$tags       = wp_get_post_terms( $product_id, 'product_tag', array( 'fields' => 'names' ) );
		return array(
			'title'            => (string) $product->get_name(),
			'short_description' => (string) $product->get_short_description(),
			'description'      => (string) $product->get_description(),
			'slug'             => (string) $product->get_slug(),
			'categories'       => is_wp_error( $categories ) ? array() : array_values( array_map( 'strval', (array) $categories ) ),
			'tags'             => is_wp_error( $tags ) ? array() : array_values( array_map( 'strval', (array) $tags ) ),
			'seo_title'        => self::get_seo_meta( $product_id, 'title' ),
			'seo_description'  => self::get_seo_meta( $product_id, 'description' ),
			'focus_keywords'   => self::get_focus_keywords( $product_id ),
		);
	}


	public static function detect_text_language( $text ) {
		$text = trim( wp_strip_all_tags( html_entity_decode( (string) $text, ENT_QUOTES, 'UTF-8' ) ) );
		if ( '' === $text ) { return ''; }
		$lower = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
		$letters = preg_replace( '/[^\p{L}]/u', '', $lower );
		if ( self::strlen( $letters ) < 8 ) { return ''; }
		if ( preg_match( '/[\x{0600}-\x{06FF}]/u', $text ) ) {
			$fa = preg_match_all( '/\b(?:است|این|برای|با|در|که|را|محصول|رنگ|قیمت|توضیحات|فروش|خرید)\b/u', $lower, $m );
			$ar = preg_match_all( '/\b(?:هذا|هذه|من|في|على|مع|المنتج|سعر|لون|وصف|شراء)\b/u', $lower, $m );
			return $fa >= $ar ? 'fa' : 'ar';
		}
		$sets = array(
			'de' => array( 'und','der','die','das','ist','für','mit','von','auf','produkt','nicht','eine','einer','einem','zum','zur','des','dem','den','auch','sowie','oder','geeignet','inklusive','hochwertig','farbe','größe','abmessung' ),
			'en' => array( 'the','and','is','for','with','from','product','this','that','your','not','a','an','of','to','in','on','or','also','suitable','including','size','colour','color','dimensions' ),
			'fr' => array( 'le','la','les','des','et','est','pour','avec','produit','dans','une','un','du','de','sur','ou','aussi','convient','taille','couleur','dimensions','description' ),
			'it' => array( 'il','lo','la','gli','le','e','per','con','prodotto','una','sono','di','del','della','nel','sul','oppure','anche','adatto','misura','colore','dimensioni' ),
			'es' => array( 'el','la','los','las','y','es','para','con','producto','una','que','de','del','en','sobre','también','adecuado','tamaño','color','dimensiones' ),
			'nl' => array( 'de','het','een','en','is','voor','met','product','van','niet','een','op','voor','ook','geschikt','maat','kleur','afmetingen' ),
			'tr' => array( 've','bir','ile','için','ürün','olan','bu','değil','bir','veya','ayrıca','uygun','boyut','renk','ölçü' ),
			'pt' => array( 'o','a','os','as','e','é','para','com','produto','uma','de','do','da','em','também','adequado','tamanho','cor','dimensões' ),
			'pl' => array( 'i','jest','dla','z','na','produkt','to','nie','oraz','który','jest','w','ze','również','odpowiedni','rozmiar','kolor','wymiary' ),
			'ru' => array( 'и','это','для','с','товар','цена','как','не','что','на','или','также','подходит','размер','цвет','описание' ),
		);
		$scores = array_fill_keys( array_keys( $sets ), 0 );
		foreach ( $sets as $lang => $words ) {
			foreach ( $words as $word ) {
				$scores[ $lang ] += preg_match_all( '/(?<![\p{L}])' . preg_quote( $word, '/' ) . '(?![\p{L}])/u', $lower, $m );
			}
		}
		arsort( $scores );
		$best = (string) key( $scores );
		$vals = array_values( $scores );
		$best_score = isset( $vals[0] ) ? (int) $vals[0] : 0;
		$second = isset( $vals[1] ) ? (int) $vals[1] : 0;
		if ( $best_score < 2 || ( $best_score === $second && $best_score < 4 ) ) { return ''; }
		return $best;
	}

	public static function translation_content_audit( $source_product_id, $target_language ) {
		$target_product_id = self::translation_product_id( $source_product_id, $target_language );
		if ( ! $target_product_id ) {
			return array( 'target_product_id' => 0, 'status' => 'missing_target', 'label' => 'Target page missing', 'fields' => array(), 'needs_count' => 0 );
		}
		$source = self::product_fields( $source_product_id );
		$target = self::product_fields( $target_product_id );
		if ( ! $source || ! $target ) {
			return array( 'target_product_id' => $target_product_id, 'status' => 'unknown', 'label' => 'Cannot inspect', 'fields' => array(), 'needs_count' => 0 );
		}
		$map = array(
			'title' => array( 'label' => 'Title', 'type' => 'text' ),
			'short_description' => array( 'label' => 'Short description', 'type' => 'text' ),
			'description' => array( 'label' => 'Description', 'type' => 'text' ),
			'slug' => array( 'label' => 'URL slug', 'type' => 'slug' ),
			'seo_title' => array( 'label' => 'SEO title', 'type' => 'text' ),
			'seo_description' => array( 'label' => 'SEO description', 'type' => 'text' ),
			'focus_keywords' => array( 'label' => 'Focus keywords', 'type' => 'text' ),
		);
		$fields = array();
		$needs = 0;
		foreach ( $map as $key => $meta ) {
			$sv = isset( $source[ $key ] ) ? trim( wp_strip_all_tags( (string) $source[ $key ] ) ) : '';
			$tv = isset( $target[ $key ] ) ? trim( wp_strip_all_tags( (string) $target[ $key ] ) ) : '';
			$status = 'ok';
			$language = '';
			if ( '' === $tv ) {
				$status = 'missing';
				$needs++;
			} elseif ( $sv !== '' && hash_equals( md5( $sv ), md5( $tv ) ) ) {
				$status = 'source_same';
				$needs++;
			} elseif ( 'slug' !== $meta['type'] ) {
				$language = self::detect_text_language( $tv );
				if ( $language && self::product_language( $source_product_id ) && $language === self::product_language( $source_product_id ) ) {
					$status = 'source_language';
					$needs++;
				} elseif ( $language && $target_language && $language !== $target_language && $key !== 'seo_title' && $key !== 'seo_description' ) {
					$status = 'other_language';
					$needs++;
				}
			}
			$fields[ $key ] = array( 'label' => $meta['label'], 'status' => $status, 'language' => $language, 'source_value' => $sv, 'target_value' => $tv );
		}
		$status = 0 === $needs ? 'translated' : 'needs_translation';
		return array( 'target_product_id' => $target_product_id, 'status' => $status, 'label' => 0 === $needs ? 'Target looks translated' : ( $needs . ' field(s) need attention' ), 'fields' => $fields, 'needs_count' => $needs );
	}

	public static function translation_status( $source_product_id, $target_language ) {
		$audit = self::translation_content_audit( $source_product_id, $target_language );
		if ( 'missing_target' === $audit['status'] ) {
			return array( 'status' => 'missing_target', 'target_product_id' => 0, 'label' => 'No linked target' );
		}
		return array( 'status' => $audit['status'], 'target_product_id' => absint( $audit['target_product_id'] ), 'label' => $audit['label'], 'needs_count' => absint( $audit['needs_count'] ), 'fields' => $audit['fields'] );
	}

	public static function translation_candidates( $source_language, $target_language, $page = 1, $per_page = 20, $search = '', $mode = 'needs' ) {
		$page = max( 1, absint( $page ) );
		$per_page = min( 50, max( 5, absint( $per_page ) ) );
		$base = self::query_products( $source_language, $search, 1, 5000 );
		$matches = array();
		foreach ( (array) $base['ids'] as $id ) {
			$target_id = self::translation_product_id( $id, $target_language );
			if ( ! $target_id ) { continue; }
			$status = self::translation_status( $id, $target_language );
			if ( 'needs' === $mode && ! in_array( $status['status'], array( 'needs_translation', 'outdated' ), true ) ) { continue; }
			$matches[] = absint( $id );
		}
		$total = count( $matches );
		return array( 'ids' => array_slice( $matches, ( $page - 1 ) * $per_page, $per_page ), 'total' => $total );
	}


	public static function query_health_products( $language, $search, $page, $per_page ) {
		$language = sanitize_key( $language );
		$search = sanitize_text_field( $search );
		$page = max( 1, absint( $page ) );
		$per_page = min( 50, max( 5, absint( $per_page ) ) );
		return self::query_products( $language, $search, $page, $per_page );
	}

	public static function variation_summary( $product_id ) {
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( absint( $product_id ) ) : false;
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return array( 'has_variations' => false, 'count' => 0, 'with_image' => 0, 'without_image' => 0 );
		}
		$count = 0;
		$with_image = 0;
		foreach ( (array) $product->get_children() as $variation_id ) {
			$variation_id = absint( $variation_id );
			if ( ! $variation_id ) { continue; }
			$count++;
			if ( get_post_thumbnail_id( $variation_id ) ) { $with_image++; }
		}
		return array(
			'has_variations' => $count > 0,
			'count' => $count,
			'with_image' => $with_image,
			'without_image' => max( 0, $count - $with_image ),
		);
	}

	public static function health_report( $product_id, $analyzer = null ) {
		$product_id = absint( $product_id );
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : false;
		if ( ! $product ) { return array(); }
		$fields = self::product_fields( $product_id );
		$content = array(
			'title' => '' !== trim( (string) $fields['title'] ),
			'short_description' => '' !== trim( wp_strip_all_tags( (string) $fields['short_description'] ) ),
			'description' => '' !== trim( wp_strip_all_tags( (string) $fields['description'] ) ),
			'sku' => '' !== trim( (string) $product->get_sku() ),
			'image' => (bool) $product->get_image_id(),
			'categories' => ! empty( $fields['categories'] ),
			'slug' => '' !== trim( (string) $fields['slug'] ),
			'seo_title' => '' !== trim( (string) $fields['seo_title'] ),
			'seo_description' => '' !== trim( (string) $fields['seo_description'] ),
		);
		$variations = array( 'count' => 0, 'missing_price' => 0, 'missing_sku' => 0, 'missing_image' => 0, 'disabled' => 0, 'duplicates' => 0, 'duplicate_keys' => array(), 'attributes' => $product->get_variation_attributes() );
		if ( $product->is_type( 'variable' ) ) {
			$children = $product->get_children();
			$variations['count'] = count( $children );
			$signatures = array();
			foreach ( $children as $variation_id ) {
				$v = wc_get_product( $variation_id );
				if ( ! $v ) { continue; }
				if ( '' === (string) $v->get_price() ) { $variations['missing_price']++; }
				if ( '' === trim( (string) $v->get_sku() ) ) { $variations['missing_sku']++; }
				if ( ! $v->get_image_id() ) { $variations['missing_image']++; }
				if ( 'publish' !== get_post_status( $variation_id ) ) { $variations['disabled']++; }
				$attrs = (array) $v->get_variation_attributes();
				ksort( $attrs );
				$sig = wp_json_encode( $attrs );
				if ( isset( $signatures[ $sig ] ) ) {
					$signatures[ $sig ]++;
				} else {
					$signatures[ $sig ] = 1;
				}
			}
			foreach ( $signatures as $sig => $count ) {
				if ( $count > 1 ) { $variations['duplicates'] += $count - 1; $variations['duplicate_keys'][] = array( 'signature' => $sig, 'count' => $count ); }
			}
		}
		$engines = array( 'woodmart' => array( 'active' => false, 'count' => 0, 'attributes' => array() ), 'wcboost' => array( 'active' => false, 'count' => 0, 'attributes' => array() ), 'conflicts' => array() );
		if ( $analyzer && $product->is_type( 'variable' ) ) {
			$engines['woodmart']['active'] = (bool) $analyzer->is_woodmart_active();
			$engines['wcboost']['active'] = (bool) $analyzer->is_wcboost_active();
			$probe = $analyzer->get_product_data( $product_id, false );
			if ( is_array( $probe ) ) {
				$engines['woodmart']['attributes'] = array_keys( (array) ( $probe['woodmart_attrs'] ?? array() ) );
				$engines['wcboost']['attributes'] = array_keys( (array) ( $probe['wcboost_attrs'] ?? array() ) );
				$engines['woodmart']['count'] = count( $engines['woodmart']['attributes'] );
				$engines['wcboost']['count'] = count( $engines['wcboost']['attributes'] );
				$engines['conflicts'] = array_keys( (array) ( $probe['conflicts'] ?? array() ) );
			}
		}
		$issues = array();
		foreach ( $content as $key => $ok ) { if ( ! $ok ) { $issues[] = $key; } }
		if ( $product->is_type( 'variable' ) ) {
			if ( $variations['missing_price'] ) { $issues[] = 'variation_price'; }
			if ( $variations['missing_sku'] ) { $issues[] = 'variation_sku'; }
			if ( $variations['missing_image'] ) { $issues[] = 'variation_image'; }
			if ( $variations['duplicates'] ) { $issues[] = 'duplicate_variations'; }
			if ( ! empty( $engines['conflicts'] ) ) { $issues[] = 'swatch_conflict'; }
		}
		return array(
			'id' => $product_id,
			'title' => $product->get_name(),
			'sku' => $product->get_sku(),
			'type' => $product->get_type(),
			'price' => (string) $product->get_price(),
			'image' => self::image_url( $product_id ),
			'language' => self::product_language( $product_id ),
			'edit_url' => get_edit_post_link( $product_id, '' ),
			'view_url' => get_permalink( $product_id ),
			'content' => $content,
			'variations' => $variations,
			'engines' => $engines,
			'issues' => $issues,
			'issue_count' => count( $issues ),
		);
	}

	private static function strlen( $text ) {
		return function_exists( 'mb_strlen' ) ? mb_strlen( (string) $text, 'UTF-8' ) : strlen( (string) $text );
	}

	public static function quality( $product_id ) {
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : false;
		if ( ! $product ) {
			return array( 'score' => 0, 'issues' => array( 'Product not found.' ) );
		}
		$score  = 0;
		$issues = array();
		$title  = trim( $product->get_name() );
		$short  = trim( wp_strip_all_tags( $product->get_short_description() ) );
		$desc   = trim( wp_strip_all_tags( $product->get_description() ) );
		if ( self::strlen( $title ) >= 10 ) { $score += 15; } else { $issues[] = 'Title is too short.'; }
		if ( self::strlen( $short ) >= 60 ) { $score += 15; } else { $issues[] = 'Short description is short or empty.'; }
		if ( self::strlen( $desc ) >= 180 ) { $score += 25; } else { $issues[] = 'Description is short or empty.'; }
		if ( $product->get_sku() ) { $score += 10; } else { $issues[] = 'SKU is missing.'; }
		if ( $product->get_image_id() ) { $score += 10; } else { $issues[] = 'Main image is missing.'; }
		if ( count( $product->get_category_ids() ) ) { $score += 10; } else { $issues[] = 'No product category.'; }
		if ( self::has_seo_plugin() ) {
			if ( self::get_seo_meta( $product_id, 'title' ) ) { $score += 7; } else { $issues[] = 'SEO title is missing.'; }
			if ( self::get_seo_meta( $product_id, 'description' ) ) { $score += 8; } else { $issues[] = 'SEO description is missing.'; }
		} else {
			$score += 15;
		}
		return array( 'score' => min( 100, $score ), 'issues' => $issues );
	}

	public static function translate_product( $source_product_id, $target_language, $options = array() ) {
		self::$last_error = '';
		$source_product_id = absint( $source_product_id );
		$target_language   = sanitize_key( $target_language );
		$source_language   = self::product_language( $source_product_id );
		$target_product_id = self::translation_product_id( $source_product_id, $target_language );

		if ( ! $source_product_id || ! $target_product_id ) {
			return self::fail( __( 'No linked target-language product was found. WPML/Polylang must provide the target product for a different language.', 'vcm' ) );
		}
		if ( $source_product_id === $target_product_id ) {
			return self::fail( __( 'Source and target product are the same product.', 'vcm' ) );
		}
		$source = self::product_fields( $source_product_id );
		$before = self::product_fields( $target_product_id );
		if ( ! $source || ! $before ) {
			return self::fail( __( 'Product content could not be read.', 'vcm' ) );
		}

		$hash_payload = array(
			'prompt_version' => self::PROMPT_VERSION,
			'source_lang'    => $source_language,
			'target_lang'    => $target_language,
			'source'         => $source,
			'glossary'       => self::glossary_for( $source_language, $target_language ),
			'tone'           => self::settings()['tone'],
		);
		$memory_hash = hash( 'sha256', wp_json_encode( $hash_payload ) );
		$translated  = self::memory_get( $memory_hash );
		$from_memory = true;
		if ( ! $translated ) {
			$from_memory = false;
			$prompt      = self::translation_prompt( $source_language, $target_language, $source );
			$translated  = self::generate_json( $prompt, self::content_schema() );
			if ( is_wp_error( $translated ) ) {
				self::log( $source_product_id, $target_product_id, 'translation', $source_language, $target_language, 'error', $translated->get_error_message() );
				return self::fail( $translated->get_error_message() );
			}
			self::memory_save( $memory_hash, $source_language, $target_language, $translated );
		}

		$apply_mode = isset( $options['mode'] ) ? sanitize_key( $options['mode'] ) : 'smart';
		$audit = self::translation_content_audit( $source_product_id, $target_language );
		$apply = $translated;
		if ( 'force' !== $apply_mode && ! empty( $audit['fields'] ) ) {
			$apply = array();
			foreach ( $audit['fields'] as $key => $info ) {
				if ( in_array( $info['status'], array( 'missing', 'source_same', 'source_language', 'other_language' ), true ) && array_key_exists( $key, $translated ) ) {
					$apply[ $key ] = $translated[ $key ];
				}
			}
		}
		if ( empty( $apply ) ) {
			return array( 'success' => true, 'skipped' => true, 'source_product_id' => $source_product_id, 'target_product_id' => $target_product_id, 'target_language' => $target_language, 'message' => 'Target fields already look translated.' );
		}
		$snapshot = self::create_snapshot( $source_product_id, $target_product_id, 'translation', $target_language, $before );
		if ( ! $snapshot ) {
			return self::fail( __( 'A rollback snapshot could not be created, so nothing was changed.', 'vcm' ) );
		}
		if ( ! self::apply_fields( $target_product_id, $apply ) ) {
			return self::fail( __( 'The translated content could not be saved. The target product was not changed completely.', 'vcm' ) );
		}
		update_post_meta( $target_product_id, '_vcm_ai_translation_hash_' . $target_language, $memory_hash );
		self::log( $source_product_id, $target_product_id, 'translation', $source_language, $target_language, 'success', $from_memory ? 'Translation reused from Translation Memory.' : 'Translated with Gemini.' );
		return array(
			'success' => true,
			'source_product_id' => $source_product_id,
			'target_product_id' => $target_product_id,
			'target_language' => $target_language,
			'snapshot_id' => $snapshot,
			'from_memory' => $from_memory,
			'applied_fields' => array_keys( $apply ),
			'mode' => $apply_mode,
		);
	}

	public static function preview_translation( $source_product_id, $target_language ) {
		$source_product_id = absint( $source_product_id );
		$target_language = sanitize_key( $target_language );
		$source_language = self::product_language( $source_product_id );
		$target_product_id = self::translation_product_id( $source_product_id, $target_language );
		if ( ! $source_product_id || ! $target_product_id ) {
			return self::fail( __( 'No linked target-language product was found.', 'vcm' ) );
		}
		$source = self::product_fields( $source_product_id );
		if ( ! $source ) {
			return self::fail( __( 'Product content could not be read.', 'vcm' ) );
		}
		$hash = self::translation_hash( $source_product_id, $target_language, $source );
		$translated = self::memory_get( $hash );
		$from_memory = true;
		if ( ! $translated ) {
			$from_memory = false;
			$translated = self::generate_json( self::translation_prompt( $source_language, $target_language, $source ), self::content_schema() );
			if ( is_wp_error( $translated ) ) {
				return self::fail( $translated->get_error_message() );
			}
			self::memory_save( $hash, $source_language, $target_language, $translated );
		}
		return array( 'success' => true, 'source_product_id' => $source_product_id, 'target_product_id' => $target_product_id, 'target_language' => $target_language, 'translated' => $translated, 'from_memory' => $from_memory, 'audit' => self::translation_content_audit( $source_product_id, $target_language ) );
	}

	private static function translation_hash( $source_product_id, $target_language, $source = null ) {
		$source_language = self::product_language( $source_product_id );
		if ( ! is_array( $source ) ) { $source = self::product_fields( $source_product_id ); }
		$hash_payload = array(
			'prompt_version' => self::PROMPT_VERSION,
			'source_lang'    => $source_language,
			'target_lang'    => sanitize_key( $target_language ),
			'source'         => $source,
			'glossary'       => self::glossary_for( $source_language, $target_language ),
			'tone'           => self::settings()['tone'],
		);
		return hash( 'sha256', wp_json_encode( $hash_payload ) );
	}

	public static function clean_product( $product_id ) {
		$product_id = absint( $product_id );
		$fields = self::product_fields( $product_id );
		if ( ! $fields ) { return self::fail( __( 'Product not found.', 'vcm' ) ); }
		$prompt = "You are a professional e-commerce content cleaner. Clean the supplied product title, short description and description without changing factual meaning. Remove accidental repetition, doubled whitespace, broken line breaks, empty HTML tags and obvious formatting noise. Preserve useful HTML structure, brand names, SKUs, numbers, units, shortcodes and product facts. Do not invent or delete meaningful specifications. Return JSON with title, short_description and description.\n\n" . wp_json_encode( $fields, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		$result = self::generate_json( $prompt, array( 'type' => 'object', 'properties' => array( 'title' => array( 'type' => 'string' ), 'short_description' => array( 'type' => 'string' ), 'description' => array( 'type' => 'string' ) ), 'required' => array( 'title', 'short_description', 'description' ) ) );
		if ( is_wp_error( $result ) ) { self::log( $product_id, $product_id, 'clean', self::product_language( $product_id ), self::product_language( $product_id ), 'error', $result->get_error_message() ); return self::fail( $result->get_error_message() ); }
		$snapshot = self::create_snapshot( $product_id, $product_id, 'clean', self::product_language( $product_id ), $fields );
		if ( ! $snapshot ) { return self::fail( __( 'Rollback snapshot could not be created.', 'vcm' ) ); }
		if ( ! self::apply_fields( $product_id, $result ) ) { return self::fail( __( 'Cleaned content could not be saved.', 'vcm' ) ); }
		self::log( $product_id, $product_id, 'clean', self::product_language( $product_id ), self::product_language( $product_id ), 'success', 'Product content cleaned with Gemini.' );
		return array( 'success' => true, 'snapshot_id' => $snapshot );
	}

	public static function duplicate_groups( $limit = 300 ) {
		$ids = get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'private', 'draft' ), 'posts_per_page' => min( 500, max( 50, absint( $limit ) ) ), 'fields' => 'ids', 'no_found_rows' => true, 'suppress_filters' => true ) );
		$groups = array();
		foreach ( $ids as $id ) {
			$fields = self::product_fields( $id );
			if ( ! $fields ) { continue; }
			$text = strtolower( preg_replace( '/\\s+/', ' ', wp_strip_all_tags( $fields['description'] ) ) );
			$text = trim( $text );
			if ( self::strlen( $text ) < 80 ) { continue; }
			$hash = md5( $text );
			$groups[ $hash ][] = array( 'id' => absint( $id ), 'title' => get_the_title( $id ) );
		}
		$out = array();
		foreach ( $groups as $items ) { if ( count( $items ) > 1 ) { $out[] = $items; } }
		usort( $out, function( $a, $b ) { return count( $b ) <=> count( $a ); } );
		return array_slice( $out, 0, 30 );
	}

	public static function rewrite_description( $product_id ) {
		$product_id = absint( $product_id );
		$fields = self::product_fields( $product_id );
		if ( ! $fields ) {
			return self::fail( __( 'Product not found.', 'vcm' ) );
		}
		$prompt = "You are a native e-commerce copywriter. Rewrite only the product description below. Keep the factual meaning, technical data, brand names, numbers, measurements and HTML structure. Make it natural, persuasive and professional for an online store. Do not invent specifications. Return JSON with one key: description.\n\nPRODUCT TITLE:\n" . $fields['title'] . "\n\nDESCRIPTION:\n" . $fields['description'];
		$result = self::generate_json( $prompt, array( 'type' => 'object', 'properties' => array( 'description' => array( 'type' => 'string' ) ), 'required' => array( 'description' ) ) );
		if ( is_wp_error( $result ) ) {
			self::log( $product_id, $product_id, 'rewrite', '', '', 'error', $result->get_error_message() );
			return self::fail( $result->get_error_message() );
		}
		$snapshot = self::create_snapshot( $product_id, $product_id, 'rewrite', self::product_language( $product_id ), $fields );
		if ( ! $snapshot ) {
			return self::fail( __( 'Rollback snapshot could not be created.', 'vcm' ) );
		}
		if ( ! self::apply_fields( $product_id, array( 'description' => isset( $result['description'] ) ? $result['description'] : $fields['description'] ) ) ) {
			return self::fail( __( 'Rewrite could not be saved.', 'vcm' ) );
		}
		self::log( $product_id, $product_id, 'rewrite', self::product_language( $product_id ), self::product_language( $product_id ), 'success', 'Description rewritten with Gemini.' );
		return array( 'success' => true, 'snapshot_id' => $snapshot );
	}

	public static function generate_seo( $product_id ) {
		$product_id = absint( $product_id );
		$fields = self::product_fields( $product_id );
		if ( ! $fields ) {
			return self::fail( __( 'Product not found.', 'vcm' ) );
		}
		$prompt = "You are an SEO copywriter for an e-commerce product page. Create a concise SEO title and a natural meta description based only on the supplied product information. Do not invent facts. Return JSON: {\"seo_title\":\"...\",\"seo_description\":\"...\"}.\n\nTITLE:\n" . $fields['title'] . "\n\nSHORT DESCRIPTION:\n" . $fields['short_description'] . "\n\nDESCRIPTION:\n" . $fields['description'];
		$result = self::generate_json( $prompt, array( 'type' => 'object', 'properties' => array( 'seo_title' => array( 'type' => 'string' ), 'seo_description' => array( 'type' => 'string' ), 'focus_keywords' => array( 'type' => 'string' ) ), 'required' => array( 'seo_title', 'seo_description', 'focus_keywords' ) ) );
		if ( is_wp_error( $result ) ) {
			self::log( $product_id, $product_id, 'seo', '', '', 'error', $result->get_error_message() );
			return self::fail( $result->get_error_message() );
		}
		$snapshot = self::create_snapshot( $product_id, $product_id, 'seo', self::product_language( $product_id ), $fields );
		if ( ! $snapshot ) {
			return self::fail( __( 'Rollback snapshot could not be created.', 'vcm' ) );
		}
		$payload = array(
			'seo_title'       => isset( $result['seo_title'] ) ? $result['seo_title'] : $fields['seo_title'],
			'seo_description' => isset( $result['seo_description'] ) ? $result['seo_description'] : $fields['seo_description'],
		);
		if ( ! self::apply_fields( $product_id, $payload ) ) {
			return self::fail( __( 'SEO content could not be saved.', 'vcm' ) );
		}
		self::log( $product_id, $product_id, 'seo', self::product_language( $product_id ), self::product_language( $product_id ), 'success', 'SEO metadata generated with Gemini.' );
		return array( 'success' => true, 'snapshot_id' => $snapshot );
	}

	private static function credential_candidates() {
		$settings = self::settings();
		$items = array();
		$provider = $settings['provider_mode'];
		if ( 'ai_studio' === $provider || 'auto' === $provider ) {
			if ( 'free' === $settings['usage_mode'] || 'auto' === $settings['usage_mode'] ) {
				$key = ! empty( $settings['free_api_key'] ) ? $settings['free_api_key'] : $settings['api_key'];
				if ( $key ) { $items[] = array( 'provider' => 'ai_studio', 'tier' => 'free', 'api_key' => $key ); }
			}
			if ( 'paid' === $settings['usage_mode'] || 'auto' === $settings['usage_mode'] ) {
				$key = $settings['paid_api_key'];
				if ( $key ) { $items[] = array( 'provider' => 'ai_studio', 'tier' => 'paid', 'api_key' => $key ); }
			}
		}
		// In Auto mode, prefer the standard Google AI Studio Gemini API first.
		// This is the normal path for keys created in Google AI Studio (Free or Paid).
		// Vertex Express is optional and is tried only after AI Studio credentials fail.
		if ( 'vertex_express' === $provider ) {
			$items = array();
			if ( ! empty( $settings['vertex_api_key'] ) ) {
				$items[] = array( 'provider' => 'vertex_express', 'tier' => 'express', 'api_key' => $settings['vertex_api_key'] );
			}
		} elseif ( 'auto' === $provider && ! empty( $settings['vertex_api_key'] ) ) {
			$items[] = array( 'provider' => 'vertex_express', 'tier' => 'express', 'api_key' => $settings['vertex_api_key'] );
		}
		return $items;
	}

	private static function diagnose_access( $api_key = '', $provider = 'ai_studio' ) {
		$settings = self::settings();
		if ( 'vertex_express' === $provider ) {
			if ( empty( $api_key ) ) {
				return new WP_Error( 'vcm_vertex_no_key', 'No Vertex AI Express API key is configured.' );
			}
			return array( 'status' => 200, 'models' => array( $settings['vertex_model'], $settings['vertex_fallback_model'] ) );
		}
		$api_key = $api_key ? $api_key : ( ! empty( $settings['free_api_key'] ) ? $settings['free_api_key'] : $settings['api_key'] );
		if ( empty( $api_key ) ) {
			return new WP_Error( 'vcm_ai_no_key', __( 'No Gemini API key is configured for this mode.', 'vcm' ) );
		}
		$response = wp_remote_get( 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000', array(
			'timeout' => 20,
			'headers' => array( 'x-goog-api-key' => $api_key ),
		) );
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'vcm_ai_transport', 'Gemini API could not be reached: ' . $response->get_error_message() );
		}
		$code = wp_remote_retrieve_response_code( $response );
		$raw = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );
		if ( $code >= 200 && $code < 300 ) {
			$models = array();
			foreach ( (array) ( $data['models'] ?? array() ) as $model ) {
				$name = isset( $model['baseModelId'] ) ? $model['baseModelId'] : ( isset( $model['name'] ) ? preg_replace( '#^models/#', '', $model['name'] ) : '' );
				if ( $name ) { $models[] = $name; }
			}
			return array( 'status' => $code, 'models' => array_values( array_unique( $models ) ) );
		}
		$message = isset( $data['error']['message'] ) ? (string) $data['error']['message'] : 'Gemini rejected the API request.';
		if ( 403 === $code ) {
			$message = 'Google AI Studio denied this project for generateContent (HTTP 403). The key format/authentication was accepted, but Google is blocking generation for the project. This is not a WordPress billing switch. Verify the AI Studio project, region/access, and Gemini API availability, then retest the same key.';
		} elseif ( 401 === $code ) {
			$message = 'Google rejected this API key. Create a fresh key in the intended Free or Paid project and restrict it to the Gemini API.';
		}
		return new WP_Error( 'vcm_ai_access', sprintf( '[HTTP %d] %s', $code, $message ), array( 'status' => $code, 'raw' => $raw ) );
	}

	public static function test_connection() {
		$settings = self::settings();
		$results = array();
		foreach ( self::credential_candidates() as $credential ) {
			$diag = self::diagnose_access( $credential['api_key'], $credential['provider'] );
			if ( is_wp_error( $diag ) ) {
				$results[ $credential['provider'] . ':' . $credential['tier'] ] = array( 'ok' => false, 'message' => $diag->get_error_message() );
				continue;
			}
			$probe = self::generate_json_with_key( 'Return exactly the JSON object {"ok":true}.', array( 'type' => 'object', 'properties' => array( 'ok' => array( 'type' => 'boolean' ) ), 'required' => array( 'ok' ) ), true, $credential['api_key'], $credential['provider'] );
			if ( is_wp_error( $probe ) ) {
				$results[ $credential['tier'] ] = array( 'ok' => false, 'message' => $probe->get_error_message() );
			} else {
				self::$last_tier = $credential['tier'];
				$results[ $credential['provider'] . ':' . $credential['tier'] ] = array( 'ok' => true, 'model' => self::$last_model, 'message' => 'Generation test succeeded.' );
			}
		}
		$ok = false;
		foreach ( $results as $row ) { if ( ! empty( $row['ok'] ) ) { $ok = true; break; } }
		if ( ! $ok ) {
			return self::fail( $results ? implode( ' | ', array_map( function( $r ) { return $r['message']; }, $results ) ) : 'No Gemini API key is configured for the selected mode.' );
		}
		$active = self::last_used_credential();
		return array( 'success' => true, 'mode' => $settings['usage_mode'], 'active_tier' => $active, 'model' => self::$last_model, 'credentials' => $results );
	}

	private static function translation_prompt( $source_language, $target_language, $source ) {
		$labels       = self::language_labels();
		$source_name  = isset( $labels[ $source_language ] ) ? $labels[ $source_language ] : strtoupper( $source_language );
		$target_name  = isset( $labels[ $target_language ] ) ? $labels[ $target_language ] : strtoupper( $target_language );
		$settings     = self::settings();
		$glossary     = self::glossary_for( $source_language, $target_language );
		$html_rule    = ! empty( $settings['preserve_html'] ) ? 'Preserve useful HTML tags and nesting exactly where possible; never output unsafe script or style tags.' : 'Keep the content semantically correct and clean.';
		$glossary_txt = empty( $glossary ) ? '(none)' : wp_json_encode( $glossary, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

		return "You are a senior native {$target_name} e-commerce copywriter and SEO editor.\n"
			. "You receive an existing {$source_name} product page that already exists on another site/source. Your task is NOT to translate sentence-by-sentence. Rebuild the target-language copy from the source facts so it reads like original copy written for a native {$target_name} online store.\n"
			. "The target must be clearly different in wording, sentence structure, ordering, headings and phrasing from the source. Do not imitate a reference site's wording. Keep the factual product information, technical specifications, sizes, units, brand names, model numbers, SKUs and stated features accurate. Never invent certifications, materials, performance claims, prices, stock, guarantees or benefits that are not supported by the source.\n"
			. "For SEO, naturally use relevant search terms that can be inferred from the product name, category, product facts and wording. Avoid keyword stuffing. Prefer commercial search intent, clarity and natural language.\n"
			. "The title should be concise and commercially useful. The short description should be persuasive but factual. The full description should be well structured for an online shop and may reorganize the source content into clearer sections. The SEO title and meta description should be distinct from the body copy and written for search click-through without false claims.\n"
			. "Generate a clean URL slug in {$target_name} using only the core product terms; keep it short and readable. Generate 5-10 relevant focus keywords/phrases in {$target_name}; return them as a comma-separated string.\n"
			. "{$html_rule} Preserve placeholders such as {{variable}}, %%TOKEN%% and shortcodes. Do not add commentary outside the JSON.\n"
			. "Preferred translation/style: {$settings['tone']}.\n"
			. "Glossary rules: {$glossary_txt}\n"
			. "Return ONLY valid JSON with exactly these keys: title, short_description, description, slug, seo_title, seo_description, focus_keywords.\n\n"
			. wp_json_encode( $source, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	}

	private static function content_schema() {
		return array(
			'type' => 'object',
			'properties' => array(
				'title' => array( 'type' => 'string' ),
				'short_description' => array( 'type' => 'string' ),
				'description' => array( 'type' => 'string' ),
				'slug' => array( 'type' => 'string' ),
				'seo_title' => array( 'type' => 'string' ),
				'seo_description' => array( 'type' => 'string' ),
				'focus_keywords' => array( 'type' => 'string' ),
			),
			'required' => array( 'title', 'short_description', 'description', 'slug', 'seo_title', 'seo_description', 'focus_keywords' ),
		);
	}


	public static function available_models( $api_key = '' ) {
		$settings = self::settings();
		$api_key = $api_key ? $api_key : ( ! empty( $settings['free_api_key'] ) ? $settings['free_api_key'] : $settings['api_key'] );
		if ( empty( $api_key ) ) { return array(); }
		$cached = get_transient( 'vcm_ai_models_' . md5( $api_key ) );
		if ( false !== $cached && is_array( $cached ) ) { return $cached; }
		$response = wp_remote_get( 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000', array(
			'timeout' => 20,
			'headers' => array( 'x-goog-api-key' => $api_key ),
		) );
		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) >= 300 ) { return array(); }
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		$out = array();
		foreach ( (array) ( $data['models'] ?? array() ) as $model ) {
			$name = isset( $model['baseModelId'] ) ? $model['baseModelId'] : ( isset( $model['name'] ) ? preg_replace( '#^models/#', '', $model['name'] ) : '' );
			$name = sanitize_text_field( (string) $name );
			if ( '' !== $name ) { $out[ $name ] = $model; }
		}
		set_transient( 'vcm_ai_models_' . md5( $api_key ), $out, HOUR_IN_SECONDS );
		return $out;
	}

	private static function model_candidates( $api_key = '' ) {
		$settings = self::settings();
		$configured = array( $settings['model'], $settings['fallback_model'] );
		$preferred = array( 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-3.5-flash', 'gemini-3.8-flash' );
		$candidates = array_values( array_unique( array_merge( $configured, $preferred ) ) );
		$available = self::available_models( $api_key );
		if ( ! empty( $available ) ) {
			$filtered = array();
			foreach ( $candidates as $candidate ) {
				$candidate = preg_replace( '#^models/#', '', trim( (string) $candidate ) );
				if ( isset( $available[ $candidate ] ) ) {
					$methods = (array) ( $available[ $candidate ]['supportedGenerationMethods'] ?? $available[ $candidate ]['supported_generation_methods'] ?? array() );
					if ( empty( $methods ) || in_array( 'generateContent', $methods, true ) ) {
						$filtered[] = $candidate;
					}
				}
			}
			if ( ! empty( $filtered ) ) {
				return $filtered;
			}
		}
		return array_values( array_unique( array_map( function( $m ) { return preg_replace( '#^models/#', '', trim( (string) $m ) ); }, $candidates ) ) );
	}

	private static function generate_json( $prompt, $schema = null, $skip_preflight = false ) {
		$credentials = self::credential_candidates();
		if ( empty( $credentials ) ) {
			return new WP_Error( 'vcm_ai_no_key', __( 'No Gemini API key is configured for the selected mode.', 'vcm' ) );
		}
		$last = null;
		foreach ( $credentials as $credential ) {
			$result = self::generate_json_with_key( $prompt, $schema, $skip_preflight, $credential['api_key'], $credential['provider'] );
			if ( ! is_wp_error( $result ) ) {
				self::$last_tier = $credential['tier'];
				return $result;
			}
			$last = $result;
			$code = (int) ( $result->get_error_data()['status'] ?? 0 );
			// Auto mode may fall back from a Free project to a Paid project on quota, access, auth, or model errors.
			if ( 'auto' !== self::settings()['usage_mode'] || ! in_array( $code, array( 401, 403, 404, 408, 409, 429, 500, 502, 503 ), true ) ) {
				break;
			}
		}
		return $last instanceof WP_Error ? $last : new WP_Error( 'vcm_ai_api', __( 'Gemini request failed.', 'vcm' ) );
	}

	private static function generate_json_with_key( $prompt, $schema = null, $skip_preflight = false, $api_key = '', $provider = 'ai_studio' ) {
		$settings = self::settings();
		if ( empty( $api_key ) ) {
			return new WP_Error( 'vcm_ai_no_key', __( 'AI API key is empty.', 'vcm' ) );
		}
		if ( null === $schema ) {
			$schema = array( 'type' => 'object', 'properties' => array( 'ok' => array( 'type' => 'boolean' ) ), 'required' => array( 'ok' ) );
		}
		if ( 'vertex_express' === $provider ) {
			$models = array( $settings['vertex_model'], $settings['vertex_fallback_model'] );
		} else {
			// Do not rely on models.list to decide whether generation is permitted.
			// Google can allow models.list while denying generateContent at the project/account level.
			$models = array(
				$settings['model'],
				$settings['fallback_model'],
				'gemini-3.1-flash-lite',
				'gemini-3.5-flash-lite',
				'gemini-3.8-flash',
			);
		}
		$models = array_values( array_unique( array_filter( array_map( function( $m ) { return preg_replace( '#^models/#', '', trim( (string) $m ) ); }, $models ) ) ) );
		$last_error = null;

		foreach ( $models as $model ) {
			if ( '' === $model ) { continue; }

			if ( 'vertex_express' === $provider ) {
				$attempts = array( array( 'version' => 'vertex', 'auth' => 'query' ) );
			} else {
				$version_mode = $settings['api_version_mode'] ?? 'auto';
				$auth_mode    = $settings['auth_mode'] ?? 'auto';
				$versions = 'v1' === $version_mode ? array( 'v1' ) : array( 'v1beta' );
				$auths = 'header' === $auth_mode ? array( 'header' ) : ( 'query' === $auth_mode ? array( 'query' ) : array( 'header', 'query' ) );
				$attempts = array();
				foreach ( $versions as $version ) {
					foreach ( $auths as $auth ) {
						$attempts[] = array( 'version' => $version, 'auth' => $auth );
					}
				}
			}

			foreach ( $attempts as $attempt ) {
				$version = $attempt['version'];
				$auth    = $attempt['auth'];
				if ( 'vertex_express' === $provider ) {
					$url = 'https://aiplatform.googleapis.com/v1/publishers/google/models/' . rawurlencode( $model ) . ':generateContent?key=' . rawurlencode( $api_key );
				} else {
					$base = 'https://generativelanguage.googleapis.com/' . ( 'v1' === $version ? 'v1/' : 'v1beta/' );
					$url = $base . 'models/' . rawurlencode( $model ) . ':generateContent';
					if ( 'query' === $auth ) {
						$url .= '?key=' . rawurlencode( $api_key );
					}
				}

				// Gemini GenerateContent REST currently documents responseMimeType/responseSchema
				// inside generationConfig. Do not use the newer Interactions response_format shape here.
				$body = array(
					'contents' => array( array( 'role' => 'user', 'parts' => array( array( 'text' => (string) $prompt ) ) ) ),
					'generationConfig' => array(
						'candidateCount' => 1,
						'maxOutputTokens' => 12000,
						'responseMimeType' => 'application/json',
						'responseSchema' => $schema,
					),
				);
				if ( ! in_array( $model, array( 'gemini-3.5-flash-lite', 'gemini-3.8-flash' ), true ) ) {
					$body['generationConfig']['temperature'] = 0.25;
				}
				$headers = array( 'Content-Type' => 'application/json', 'Accept' => 'application/json' );
				if ( 'ai_studio' === $provider && 'query' !== $auth ) { $headers['x-goog-api-key'] = $api_key; }

				$response = wp_remote_post( $url, array( 'timeout' => 120, 'headers' => $headers, 'body' => wp_json_encode( $body ) ) );
				if ( is_wp_error( $response ) ) { return $response; }
				$code = wp_remote_retrieve_response_code( $response );
				$raw = wp_remote_retrieve_body( $response );
				$data = json_decode( $raw, true );

				// Some projects/models can reject structured-output fields while allowing plain JSON text.
				// Retry once without structured-output config so Preview/Translate can still work.
				if ( 400 === $code ) {
					$err_text = strtolower( (string) ( $data['error']['message'] ?? $raw ) );
					if ( false !== strpos( $err_text, 'response_format' ) || false !== strpos( $err_text, 'responseformat' ) || false !== strpos( $err_text, 'response_mime_type' ) || false !== strpos( $err_text, 'responseschema' ) || false !== strpos( $err_text, 'response_schema' ) ) {
						$plain_body = $body;
						$plain_body['generationConfig'] = array( 'candidateCount' => 1, 'maxOutputTokens' => 12000 );
						if ( isset( $body['generationConfig']['temperature'] ) ) {
							$plain_body['generationConfig']['temperature'] = $body['generationConfig']['temperature'];
						}
						$response_retry = wp_remote_post( $url, array( 'timeout' => 120, 'headers' => $headers, 'body' => wp_json_encode( $plain_body ) ) );
						if ( ! is_wp_error( $response_retry ) ) {
							$retry_code = wp_remote_retrieve_response_code( $response_retry );
							$retry_raw = wp_remote_retrieve_body( $response_retry );
							$retry_data = json_decode( $retry_raw, true );
							if ( $retry_code >= 200 && $retry_code < 300 ) {
								$text = '';
								foreach ( (array) ( $retry_data['candidates'][0]['content']['parts'] ?? array() ) as $part ) {
									if ( isset( $part['text'] ) ) { $text .= (string) $part['text']; }
								}
								$text = trim( preg_replace( '/\s*```$/', '', preg_replace( '/^```(?:json)?\s*/i', '', $text ) ) );
								$result = json_decode( $text, true );
								if ( is_array( $result ) ) {
									self::$last_model = $model;
									return $result;
								}
							}
							$code = $retry_code;
							$raw = $retry_raw;
							$data = $retry_data;
						}
					}
				}

				if ( $code >= 200 && $code < 300 ) {
					$text = '';
					foreach ( (array) ( $data['candidates'][0]['content']['parts'] ?? array() ) as $part ) {
						if ( isset( $part['text'] ) ) { $text .= (string) $part['text']; }
					}
					$text = trim( preg_replace( '/\s*```$/', '', preg_replace( '/^```(?:json)?\s*/i', '', $text ) ) );
					$result = json_decode( $text, true );
					if ( is_array( $result ) ) {
						self::$last_model = $model;
						return $result;
					}
					$last_error = new WP_Error( 'vcm_ai_invalid_json', __( 'AI returned invalid JSON.', 'vcm' ), array( 'status' => 200, 'model' => $model, 'provider' => $provider, 'version' => $version ) );
					continue;
				}

				$message = isset( $data['error']['message'] ) ? (string) $data['error']['message'] : __( 'AI provider rejected the request.', 'vcm' );
				$last_error = new WP_Error( 'vcm_ai_api', sprintf( '[HTTP %d][%s][%s][%s/%s] %s', $code, $model, $provider, $version, $auth, $message ), array( 'status' => $code, 'model' => $model, 'provider' => $provider, 'version' => $version, 'auth' => $auth, 'raw' => $raw ) );
				if ( 403 === $code ) { return $last_error; }
				if ( 401 === $code || 404 === $code ) { continue; }
				if ( ! in_array( $code, array( 408, 409, 429, 500, 502, 503 ), true ) ) { break; }
			}
			if ( $last_error instanceof WP_Error && 403 === (int) ( $last_error->get_error_data()['status'] ?? 0 ) ) {
				return $last_error;
			}
		}
		return $last_error instanceof WP_Error ? $last_error : new WP_Error( 'vcm_ai_api', __( 'AI request failed.', 'vcm' ) );
	}

	private static function focus_keyword_meta_keys() {
		return array( '_yoast_wpseo_focuskw', 'rank_math_focus_keyword', '_aioseo_keywords', '_vcm_ai_focus_keywords' );
	}

	private static function get_focus_keywords( $product_id ) {
		foreach ( self::focus_keyword_meta_keys() as $key ) {
			$value = get_post_meta( $product_id, $key, true );
			if ( is_string( $value ) && '' !== trim( $value ) ) {
				return $value;
			}
		}
		return '';
	}

	private static function set_focus_keywords( $product_id, $value ) {
		$value = sanitize_text_field( (string) $value );
		$target = '_vcm_ai_focus_keywords';
		if ( defined( 'WPSEO_VERSION' ) ) {
			$target = '_yoast_wpseo_focuskw';
		} elseif ( defined( 'RANK_MATH_VERSION' ) ) {
			$target = 'rank_math_focus_keyword';
		} elseif ( defined( 'AIOSEO_VERSION' ) ) {
			$target = '_aioseo_keywords';
		}
		update_post_meta( $product_id, $target, $value );
	}

	private static function seo_meta_keys( $field ) {
		$active = array();
		if ( defined( 'WPSEO_VERSION' ) ) {
			$active[] = 'title' === $field ? '_yoast_wpseo_title' : '_yoast_wpseo_metadesc';
		}
		if ( defined( 'RANK_MATH_VERSION' ) ) {
			$active[] = 'title' === $field ? 'rank_math_title' : 'rank_math_description';
		}
		if ( defined( 'AIOSEO_VERSION' ) ) {
			$active[] = 'title' === $field ? '_aioseo_title' : '_aioseo_description';
		}
		$all = 'title' === $field
			? array( '_yoast_wpseo_title', 'rank_math_title', '_aioseo_title' )
			: array( '_yoast_wpseo_metadesc', 'rank_math_description', '_aioseo_description' );
		return array_values( array_unique( array_merge( $active, $all ) ) );
	}

	private static function get_seo_meta( $product_id, $field ) {
		foreach ( self::seo_meta_keys( $field ) as $key ) {
			$value = get_post_meta( $product_id, $key, true );
			if ( '' !== (string) $value ) {
				return (string) $value;
			}
		}
		$fallback = get_post_meta( $product_id, '_vcm_ai_' . $field, true );
		return '' !== (string) $fallback ? (string) $fallback : '';
	}

	private static function set_seo_meta( $product_id, $field, $value ) {
		$value = wp_strip_all_tags( (string) $value );
		$keys = self::seo_meta_keys( $field );
		$target = '';
		foreach ( $keys as $key ) {
			if ( metadata_exists( 'post', $product_id, $key ) || ( self::has_seo_plugin() && in_array( $key, array_slice( $keys, 0, 1 ), true ) ) ) {
				$target = $key;
				break;
			}
		}
		if ( '' === $target ) {
			update_post_meta( $product_id, '_vcm_ai_' . $field, $value );
			return;
		}
		update_post_meta( $product_id, $target, $value );
	}

	public static function has_seo_plugin() {
		return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' );
	}

	private static function apply_fields( $product_id, $fields ) {
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : false;
		if ( ! $product ) {
			return false;
		}
		$post = array( 'ID' => $product_id );
		if ( array_key_exists( 'title', $fields ) && '' !== (string) $fields['title'] ) {
			$post['post_title'] = wp_strip_all_tags( (string) $fields['title'] );
		}
		if ( array_key_exists( 'description', $fields ) && '' !== (string) $fields['description'] ) {
			$post['post_content'] = wp_kses_post( (string) $fields['description'] );
		}
		if ( array_key_exists( 'short_description', $fields ) && '' !== (string) $fields['short_description'] ) {
			$post['post_excerpt'] = wp_kses_post( (string) $fields['short_description'] );
		}
		if ( array_key_exists( 'slug', $fields ) && '' !== trim( (string) $fields['slug'] ) ) {
			$slug = sanitize_title( (string) $fields['slug'] );
			if ( $slug ) {
				$post['post_name'] = wp_unique_post_slug( $slug, $product_id, get_post_status( $product_id ), 'product', 0 );
			}
		}
		if ( count( $post ) > 1 ) {
			$result = wp_update_post( wp_slash( $post ), true );
			if ( is_wp_error( $result ) ) {
				return false;
			}
		}
		if ( array_key_exists( 'seo_title', $fields ) && '' !== (string) $fields['seo_title'] ) {
			self::set_seo_meta( $product_id, 'title', $fields['seo_title'] );
		}
		if ( array_key_exists( 'seo_description', $fields ) && '' !== (string) $fields['seo_description'] ) {
			self::set_seo_meta( $product_id, 'description', $fields['seo_description'] );
		}
		if ( array_key_exists( 'focus_keywords', $fields ) && '' !== trim( (string) $fields['focus_keywords'] ) ) {
			self::set_focus_keywords( $product_id, $fields['focus_keywords'] );
		}
		return true;
	}

	private static function glossary_for( $source_language, $target_language ) {
		$rows = get_option( self::GLOSSARY_OPTION, array() );
		$rows = is_array( $rows ) ? $rows : array();
		$out  = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$sl = isset( $row['source_language'] ) ? sanitize_key( $row['source_language'] ) : '';
			$tl = isset( $row['target_language'] ) ? sanitize_key( $row['target_language'] ) : '';
			if ( $sl === $source_language && $tl === $target_language && ! empty( $row['source'] ) && isset( $row['target'] ) ) {
				$out[] = array( 'source' => (string) $row['source'], 'target' => (string) $row['target'] );
			}
		}
		return $out;
	}

	public static function save_glossary_text( $text ) {
		$rows = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || 0 === strpos( $line, '#' ) ) {
				continue;
			}
			$parts = array_map( 'trim', explode( '|', $line, 4 ) );
			if ( 4 !== count( $parts ) ) {
				continue;
			}
			$rows[] = array(
				'source_language' => sanitize_key( $parts[0] ),
				'target_language' => sanitize_key( $parts[1] ),
				'source' => sanitize_text_field( $parts[2] ),
				'target' => sanitize_text_field( $parts[3] ),
			);
		}
		update_option( self::GLOSSARY_OPTION, $rows, false );
		return $rows;
	}

	public static function glossary_text() {
		$rows = get_option( self::GLOSSARY_OPTION, array() );
		$out = array();
		foreach ( (array) $rows as $row ) {
			if ( ! is_array( $row ) ) { continue; }
			$out[] = implode( '|', array( $row['source_language'] ?? '', $row['target_language'] ?? '', $row['source'] ?? '', $row['target'] ?? '' ) );
		}
		return implode( "\n", $out );
	}

	private static function memory_get( $hash ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT payload FROM ' . self::memory_table() . ' WHERE memory_hash = %s LIMIT 1', $hash ) );
		if ( ! $row ) {
			return false;
		}
		$data = json_decode( $row->payload, true );
		return is_array( $data ) ? $data : false;
	}

	private static function memory_save( $hash, $source_language, $target_language, $payload ) {
		global $wpdb;
		$wpdb->replace(
			self::memory_table(),
			array(
				'memory_hash' => $hash,
				'source_language' => sanitize_key( $source_language ),
				'target_language' => sanitize_key( $target_language ),
				'payload' => wp_json_encode( $payload ),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s' )
		);
	}

	public static function create_snapshot( $source_product_id, $target_product_id, $action, $target_language, $fields ) {
		global $wpdb;
		$ok = $wpdb->insert(
			self::snapshots_table(),
			array(
				'source_product_id' => absint( $source_product_id ),
				'target_product_id' => absint( $target_product_id ),
				'action' => sanitize_key( $action ),
				'target_language' => sanitize_key( $target_language ),
				'fields_json' => wp_json_encode( $fields ),
				'status' => 'active',
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s', '%s' )
		);
		return false === $ok ? 0 : absint( $wpdb->insert_id );
	}

	public static function snapshots( $limit = 30 ) {
		global $wpdb;
		$limit = min( 100, max( 1, absint( $limit ) ) );
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::snapshots_table() . ' ORDER BY id DESC LIMIT %d', $limit ), ARRAY_A );
	}

	public static function restore_snapshot( $snapshot_id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::snapshots_table() . ' WHERE id = %d LIMIT 1', absint( $snapshot_id ) ) );
		if ( ! $row ) {
			return self::fail( __( 'Snapshot not found.', 'vcm' ) );
		}
		$fields = json_decode( $row->fields_json, true );
		if ( ! is_array( $fields ) || ! self::product_fields( $row->target_product_id ) ) {
			return self::fail( __( 'Snapshot data or target product is no longer available.', 'vcm' ) );
		}
		if ( ! self::apply_fields( $row->target_product_id, $fields ) ) {
			return self::fail( __( 'Snapshot could not be restored.', 'vcm' ) );
		}
		$wpdb->update( self::snapshots_table(), array( 'status' => 'restored' ), array( 'id' => absint( $snapshot_id ) ), array( '%s' ), array( '%d' ) );
		self::log( $row->source_product_id, $row->target_product_id, 'rollback', $row->target_language, $row->target_language, 'success', 'Snapshot restored.' );
		return array( 'success' => true );
	}

	public static function logs( $limit = 40 ) {
		global $wpdb;
		$limit = min( 100, max( 1, absint( $limit ) ) );
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::logs_table() . ' ORDER BY id DESC LIMIT %d', $limit ), ARRAY_A );
	}

	private static function log( $product_id, $target_product_id, $action, $source_language, $target_language, $status, $message ) {
		global $wpdb;
		$wpdb->insert(
			self::logs_table(),
			array(
				'product_id' => absint( $product_id ),
				'target_product_id' => absint( $target_product_id ),
				'action' => sanitize_key( $action ),
				'source_language' => sanitize_key( $source_language ),
				'target_language' => sanitize_key( $target_language ),
				'status' => sanitize_key( $status ),
				'message' => sanitize_textarea_field( $message ),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s' )
		);
	}

	private static function fail( $message ) {
		self::$last_error = (string) $message;
		return array( 'success' => false, 'message' => self::$last_error );
	}
}
