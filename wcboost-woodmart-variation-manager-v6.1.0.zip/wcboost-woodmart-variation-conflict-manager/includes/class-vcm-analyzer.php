<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VCM_Analyzer {
	private $attribute_taxonomies = null;
	private $wcboost_active = null;
	private $woodmart_active = null;
	private static $probe_mode = false;
	private static $simulation_mode = false;

	public static function begin_probe() {
		self::$probe_mode = true;
	}

	public static function end_probe() {
		self::$probe_mode = false;
	}

	public static function is_probe_mode() {
		return self::$probe_mode;
	}

	public static function begin_simulation() {
		self::$simulation_mode = true;
	}

	public static function end_simulation() {
		self::$simulation_mode = false;
	}

	public static function is_simulation_mode() {
		return self::$simulation_mode;
	}

	public function is_wcboost_active() {
		if ( null !== $this->wcboost_active ) {
			return $this->wcboost_active;
		}
		$this->wcboost_active = defined( 'WCBOOST_VARIATION_SWATCHES_FILE' ) || class_exists( '\\WCBoost\\VariationSwatches\\Plugin' ) || $this->plugin_slug_active( 'wcboost-variation-swatches' );
		return $this->wcboost_active;
	}

	public function is_woodmart_active() {
		if ( null !== $this->woodmart_active ) {
			return $this->woodmart_active;
		}
		$this->woodmart_active = function_exists( 'woodmart_get_opt' ) || function_exists( 'woodmart_has_swatches' ) || defined( 'WOODMART_VERSION' );
		return $this->woodmart_active;
	}

	private function plugin_slug_active( $slug ) {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return function_exists( 'is_plugin_active' ) && is_plugin_active( $slug . '/' . $slug . '.php' );
	}

	public function get_attribute_taxonomies() {
		if ( null !== $this->attribute_taxonomies ) {
			return $this->attribute_taxonomies;
		}
		$this->attribute_taxonomies = array();
		if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
			foreach ( (array) wc_get_attribute_taxonomies() as $tax ) {
				$this->attribute_taxonomies[ 'pa_' . $tax->attribute_name ] = $tax;
			}
		}
		return $this->attribute_taxonomies;
	}

	/**
	 * Analyze one product. Conflict means both renderers actually output the
	 * single-product swatch markup for the same attribute.
	 */
	public function get_product_data( $product_id, $include_render_probe = false ) {
		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return false;
		}

		// IMPORTANT: inspect the same variation-attribute options that WooCommerce passes
		// to variable.php (taxonomy attributes use slugs here). This keeps the scanner
		// aligned with the live renderer without rendering the whole frontend page.
		$variation_attributes = $product->get_variation_attributes();
		$woodmart             = array();
		$wcboost              = array();
		$conflicts            = array();
		$woodmart_variation_image_candidates = array();

		foreach ( $variation_attributes as $attribute_name => $options ) {
			$options = is_array( $options ) ? array_values( array_filter( $options, static function( $value ) { return '' !== (string) $value; } ) ) : array();
			if ( empty( $options ) ) {
				continue;
			}

			$product_attribute = $product->get_attributes()[ $attribute_name ] ?? false;
			if ( ! $product_attribute instanceof WC_Product_Attribute || ! $product_attribute->get_variation() ) {
				continue;
			}

			$woodmart_info = $this->evaluate_woodmart_renderer( $product, $attribute_name, $options );
			$wcboost_info  = $this->evaluate_wcboost_renderer( $product, $attribute_name );

			if ( $woodmart_info['renders'] ) {
				$woodmart[ $attribute_name ] = $woodmart_info;
			} elseif ( ! empty( $woodmart_info['variation_image_candidate'] ) ) {
				$woodmart_variation_image_candidates[ $attribute_name ] = $woodmart_info;
			}
			if ( $wcboost_info['renders'] ) {
				$wcboost[ $attribute_name ] = $wcboost_info;
			}

			if ( $woodmart_info['renders'] && $wcboost_info['renders'] ) {
				$conflicts[ $attribute_name ] = array(
					'label'    => wc_attribute_label( $attribute_name ),
					'woodmart' => $woodmart_info,
					'wcboost'  => $wcboost_info,
					'managed'  => $this->is_attribute_managed( $product_id, $attribute_name ),
					'key'      => $attribute_name,
				);
			}
		}

		// Variation-image swatches need the real template context because WoodMart can build
		// them from WooCommerce variation thumbnails rather than term metadata. Only candidate
		// attributes enter this local render, so a normal catalog scan stays lightweight while
		// language-specific false positives are avoided.
		if ( ! empty( $woodmart_variation_image_candidates ) ) {
			$local_render = $this->probe_real_single_product_render( $product, false );
			foreach ( array_keys( $woodmart_variation_image_candidates ) as $attribute_name ) {
				if ( ! empty( $local_render['woodmart'][ $attribute_name ] ) ) {
					$woodmart_info = $woodmart_variation_image_candidates[ $attribute_name ];
					$woodmart_info['renders'] = true;
					$woodmart_info['source'] = 'WoodMart variation-image swatch renderer (template-verified)';
					$woodmart[ $attribute_name ] = $woodmart_info;
				}
			}
		}

		foreach ( array_keys( $woodmart_variation_image_candidates ) as $attribute_name ) {
			if ( ! empty( $woodmart[ $attribute_name ]['renders'] ) ) {
				$wcboost_info = isset( $wcboost[ $attribute_name ] ) ? $wcboost[ $attribute_name ] : null;
				if ( ! $wcboost_info && isset( $variation_attributes[ $attribute_name ] ) ) {
					$wcboost_info = $this->evaluate_wcboost_renderer( $product, $attribute_name );
				}
				if ( $wcboost_info && ! empty( $wcboost_info['renders'] ) ) {
					$wcboost[ $attribute_name ] = $wcboost_info;
					$conflicts[ $attribute_name ] = array(
						'label'    => wc_attribute_label( $attribute_name ),
						'woodmart' => $woodmart[ $attribute_name ],
						'wcboost'  => $wcboost_info,
						'managed'  => $this->is_attribute_managed( $product_id, $attribute_name ),
						'key'      => $attribute_name,
					);
				}
			}
		}

		// The catalog path is intentionally read-only. The legacy HTTP/live-render probe
		// has been removed so a recheck can never trigger WCBoost's own metadata materialization.
		$probe_status = $include_render_probe ? 'safe_logic' : 'logic';

		$disabled = $this->get_disabled_attributes( $product_id );
		$stage = $this->get_stage( $product_id );

		return array(
			'id'                  => $product_id,
			'title'               => $product->get_name(),
			'sku'                 => $product->get_sku(),
			'status'              => $product->get_status(),
			'variation_count'     => count( $product->get_children() ),
			'permalink'           => get_permalink( $product_id ),
			'edit_url'            => admin_url( 'post.php?post=' . absint( $product_id ) . '&action=edit' ),
			'thumbnail'           => $this->get_thumbnail( $product_id ),
			'language'            => $this->get_product_language( $product_id ),
			'woodmart_attrs'      => $woodmart,
			'wcboost_attrs'       => $wcboost,
			'conflicts'           => $conflicts,
			'conflict'            => ! empty( $conflicts ),
			'disabled_attrs'      => $disabled,
			'managed'             => ! empty( $disabled ),
			'stage'               => $stage,
			'baseline_hash'       => $this->get_baseline_hash( $product_id ),
			'baseline_matches'    => $this->baseline_matches( $product_id ),
			'probe_status'        => $probe_status,
			'engine_status'        => $this->get_engine_status(),
		);
	}

	/**
	 * Evaluate the actual WoodMart single-product swatch condition without rendering
	 * the complete page. WoodMart's variable.php calls woodmart_has_swatches() and
	 * only prints its .wd-swatches-single block when that function returns swatches.
	 */
	private function evaluate_woodmart_renderer( $product, $attribute_name, $options ) {
		$info = array(
			'renders'    => false,
			'terms'      => 0,
			'term_names' => array(),
			'source'     => 'WoodMart single-product renderer',
		);

		if ( ! $this->is_woodmart_active() || ! taxonomy_exists( $attribute_name ) ) {
			return $info;
		}

		if ( function_exists( 'woodmart_has_swatches' ) ) {
			// The helper is the normal WoodMart render gate. We pass the real option list,
			// but keep the call read-only. Variation-image-only swatches are checked separately
			// below because some WoodMart builds decide those from variation thumbnails.
			$swatches = woodmart_has_swatches( $product->get_id(), $attribute_name, $options, array(), false );
			if ( is_array( $swatches ) ) {
				foreach ( array_keys( $swatches ) as $value ) {
					$term = get_term_by( 'slug', $value, $attribute_name );
					if ( $term && ! is_wp_error( $term ) ) {
						$info['terms']++;
						$info['term_names'][] = $term->name;
					}
				}
				if ( ! empty( $swatches ) ) {
					$info['renders'] = true;
				}
			}
		}

		// Fail-safe fallback for WoodMart builds where the helper is renamed: reproduce
		// the documented term-metadata gate, read-only.
		if ( ! $info['renders'] ) {
			foreach ( $options as $option ) {
				$term = is_numeric( $option ) ? get_term( (int) $option, $attribute_name ) : get_term_by( 'slug', (string) $option, $attribute_name );
				if ( ! $term || is_wp_error( $term ) ) {
					continue;
				}
				$has_color = '' !== (string) get_term_meta( $term->term_id, 'color', true );
				$has_image = '' !== (string) get_term_meta( $term->term_id, 'image', true );
				$has_text  = '' !== (string) get_term_meta( $term->term_id, 'not_dropdown', true );
				if ( $has_color || $has_image || $has_text ) {
					$info['renders'] = true;
					$info['terms']++;
					$info['term_names'][] = $term->name;
				}
			}
		}

		// Important: WoodMart can also produce a swatch from images attached to
		// WooCommerce variations. This does not require color/image/not_dropdown term
		// metadata, so it must be considered separately to avoid false negatives.
		if ( ! $info['renders'] && $this->woodmart_uses_variation_image_swatches( $product, $attribute_name, $options ) ) {
			$info['variation_image_candidate'] = true;
			$info['source'] = 'WoodMart variation-image candidate';
		}

		return $info;
	}

	private function woodmart_uses_variation_image_swatches( $product, $attribute_name, $options ) {
		if ( ! $product || ! function_exists( 'woodmart_get_opt' ) ) {
			return false;
		}

		$use_variation_images = woodmart_get_opt( 'swatches_use_variation_images' );
		if ( ! $this->truthy_option( $use_variation_images ) ) {
			return false;
		}

		$grid_attribute = '';
		if ( function_exists( 'woodmart_grid_swatches_attribute' ) ) {
			try {
				$grid_attribute = woodmart_grid_swatches_attribute( $product->get_id() );
			} catch ( Throwable $e ) {
				$grid_attribute = '';
			}
		}
		if ( ! $grid_attribute ) {
			$grid_attribute = get_post_meta( $product->get_id(), '_woodmart_swatches_attribute', true );
		}
		if ( ! $grid_attribute ) {
			$grid_attribute = woodmart_get_opt( 'grid_swatches_attribute' );
		}
	
		$grid_attribute = sanitize_key( (string) $grid_attribute );
		$attribute_key = sanitize_key( $attribute_name );
		$attribute_alt = sanitize_key( preg_replace( '/^pa_/', '', $attribute_name ) );
		if ( '' === $grid_attribute || ! in_array( $grid_attribute, array( $attribute_key, 'pa_' . $attribute_alt, $attribute_alt ), true ) ) {
			return false;
		}

		$options = array_map( 'sanitize_title', (array) $options );
		$options = array_values( array_filter( array_unique( $options ) ) );
		if ( empty( $options ) ) {
			return false;
		}

		$attribute_meta_key = 'attribute_' . $attribute_key;
		foreach ( (array) $product->get_children() as $variation_id ) {
			$variation_id = absint( $variation_id );
			if ( ! $variation_id || ! get_post_status( $variation_id ) ) {
				continue;
			}
			$value = sanitize_title( (string) get_post_meta( $variation_id, $attribute_meta_key, true ) );
			if ( '' === $value || ! in_array( $value, $options, true ) ) {
				continue;
			}
			if ( get_post_thumbnail_id( $variation_id ) ) {
				return true;
			}
		}

		return false;
	}

	private function truthy_option( $value ) {
		if ( function_exists( 'wc_string_to_bool' ) ) {
			return wc_string_to_bool( $value );
		}
		return in_array( strtolower( (string) $value ), array( '1', 'yes', 'true', 'on' ), true );
	}

	/**
	 * Reproduce WCBoost's get_swatches_args() decision without calling it. The live
	 * method can materialize mapped product metadata into the database on first read;
	 * this scanner must never write to a product merely to inspect it.
	 */
	private function evaluate_wcboost_renderer( $product, $attribute_name ) {
		$info = array(
			'renders' => false,
			'type'    => 'select',
			'source'  => 'WCBoost renderer',
		);

		if ( ! $this->is_wcboost_active() ) {
			return $info;
		}

		$meta = get_post_meta( $product->get_id(), 'wcboost_variation_swatches', true );
		$meta = is_array( $meta ) ? $meta : array();
		$key  = sanitize_title( $attribute_name );
		$type = '';

		if ( isset( $meta[ $key ] ) && is_array( $meta[ $key ] ) ) {
			$type = isset( $meta[ $key ]['type'] ) ? sanitize_key( $meta[ $key ]['type'] ) : '';
		}

		if ( empty( $type ) || 'default' === $type ) {
			if ( taxonomy_exists( $attribute_name ) ) {
				$tax = isset( $this->get_attribute_taxonomies()[ $attribute_name ] ) ? $this->get_attribute_taxonomies()[ $attribute_name ] : null;
				$type = $tax && ! empty( $tax->attribute_type ) ? sanitize_key( $tax->attribute_type ) : 'select';
			} else {
				$type = 'select';
			}

			// WCBoost defaults auto_button to yes; use a read-only lookup here so the
			// scan does not trigger Settings::get_option(), which can persist defaults.
			$auto_button = get_option( 'wcboost_variation_swatches_auto_button', 'yes' );
			if ( 'select' === $type && wc_string_to_bool( $auto_button ) ) {
				$type = 'button';
			}
		}

		$info['type'] = $type;
		$info['renders'] = in_array( $type, array( 'color', 'image', 'label', 'button' ), true );
		return $info;
	}

	private function extract_main_variations_form( $html, $product_id ) {
		if ( ! is_string( $html ) || '' === $html ) {
			return '';
		}
		$forms = array();
		if ( ! preg_match_all( '/<form\\b[^>]*>.*?<\\/form>/is', $html, $matches ) ) {
			return '';
		}
		foreach ( $matches[0] as $form ) {
			if ( ! preg_match( '/class=["\'][^"\']*(?:^|\\s)variations_form(?:\\s|[^"\']*)["\']/i', $form ) ) {
				continue;
			}
			if ( ! preg_match( '/data-product_id=["\']' . preg_quote( (string) absint( $product_id ), '/' ) . '["\']/i', $form ) ) {
				continue;
			}
			$forms[] = $form;
		}
		return ! empty( $forms ) ? $forms[0] : '';
	}

	private function extract_live_woodmart_blocks( $form ) {
		$result = array();
		$this->extract_live_blocks( $form, 'div', array( 'wd-swatches-single', 'swatches-on-single' ), function( $tag, $block ) use ( &$result ) {
			$attr = $this->tag_attribute( $tag, 'data-id' );
			$attr = sanitize_title( $attr );
			if ( '' === $attr || $this->html_hidden( $tag ) || $this->html_hidden( $block ) ) {
				return;
			}
			if ( ! preg_match( '/class=["\'][^"\']*(?:^|\\s)(?:wd-swatch|swatch-on-single|woodmart-swatch)(?:\\s|[^"\']*)["\']/i', $block ) ) {
				return;
			}
			if ( ! preg_match( '/data-value=["\'][^"\']+["\']/i', $block ) ) {
				return;
			}
			$result[ $attr ] = true;
		} );
		return $result;
	}

	private function extract_live_wcboost_blocks( $form ) {
		$result = array();
		$this->extract_live_blocks( $form, 'ul', array( 'wcboost-variation-swatches__wrapper' ), function( $tag, $block ) use ( &$result ) {
			$attr = $this->tag_attribute( $tag, 'data-attribute_name' );
			$attr = sanitize_title( preg_replace( '/^attribute_/', '', $attr ) );
			if ( '' === $attr || $this->html_hidden( $tag ) || $this->html_hidden( $block ) ) {
				return;
			}
			if ( ! preg_match( '/class=["\'][^"\']*(?:^|\\s)wcboost-variation-swatches__item(?:\\s|[^"\']*)["\']/i', $block ) ) {
				return;
			}
			if ( ! preg_match( '/data-value=["\'][^"\']+["\']/i', $block ) ) {
				return;
			}
			$result[ $attr ] = true;
		} );
		return $result;
	}

	private function extract_live_blocks( $html, $tag_name, $markers, $callback ) {
		$pattern = '/<' . preg_quote( $tag_name, '/' ) . '\\b[^>]*class=["\'][^"\']*["\'][^>]*>/i';
		if ( ! preg_match_all( $pattern, $html, $matches, PREG_OFFSET_CAPTURE ) ) {
			return;
		}
		foreach ( $matches[0] as $m ) {
			$tag = $m[0];
			$is_marker = false;
			$class = $this->tag_attribute_from_string( $tag, 'class' );
			foreach ( $markers as $marker ) {
				if ( preg_match( '/(?:^|\\s)' . preg_quote( $marker, '/' ) . '(?:\\s|$)/i', $class ) ) {
					$is_marker = true;
					break;
				}
			}
			if ( ! $is_marker ) {
				continue;
			}
			$start = (int) $m[1];
			$block = $this->extract_balanced_tag_block( $html, $start, $tag_name );
			if ( '' !== $block ) {
				$callback( $tag, $block );
			}
		}
	}

	private function extract_balanced_tag_block( $html, $start, $tag_name ) {
		$end_tag = preg_quote( $tag_name, '/' );
		$pattern = '/<\\/?' . $end_tag . '\\b[^>]*>/i';
		if ( ! preg_match( $pattern, $html, $open, PREG_OFFSET_CAPTURE, $start ) ) {
			return '';
		}
		$cursor = $open[0][1];
		$depth = 0;
		if ( ! preg_match_all( $pattern, $html, $tags, PREG_OFFSET_CAPTURE, $cursor ) ) {
			return '';
		}
		foreach ( $tags[0] as $t ) {
			$token = $t[0];
			if ( preg_match( '/^<\\//', $token ) ) {
				$depth--;
				if ( 0 === $depth ) {
					return substr( $html, $start, (int) $t[1] + strlen( $token ) - $start );
				}
			} elseif ( ! preg_match( '/\\/\\s*>$/', $token ) ) {
				$depth++;
			}
		}
		return '';
	}

	private function tag_attribute( $tag, $name ) {
		return $this->tag_attribute_from_string( $tag, $name );
	}

	private function tag_attribute_from_string( $tag, $name ) {
		if ( preg_match( '/\\b' . preg_quote( $name, '/' ) . '=["\']([^"\']*)["\']/i', $tag, $m ) ) {
			return html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' );
		}
		return '';
	}

	private function html_hidden( $html ) {
		if ( preg_match( '/\\bhidden(?:\\s*=\\s*["\'][^"\']*["\'])?/i', $html ) ) {
			return true;
		}
		$class = $this->tag_attribute_from_string( $html, 'class' );
		if ( preg_match( '/(?:^|\\s)(?:hidden|is-hidden|wd-hidden|woocommerce-hidden)(?:\\s|$)/i', $class ) ) {
			return true;
		}
		if ( preg_match( '/style=["\'][^"\']*display\\s*:\\s*none/i', $html ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Render the actual template locally for the quarantine verification only.
	 * This is kept separate from scanning; scanning uses the public page probe.
	 */
	/**
	 * Render the WooCommerce variable-product template locally with the WCBoost
	 * swatch callback temporarily suspended. This gives us a real WoodMart output
	 * check without invoking WCBoost's product-meta materialization path.
	 */
	private function probe_real_single_product_render( $product, $simulate_manager = false ) {
		try {
			$available_variations = $product->get_available_variations();
			$attributes = $product->get_variation_attributes();
		} catch ( Throwable $e ) {
			return array( 'woodmart' => array(), 'wcboost' => array(), 'html' => '' );
		}
		if ( empty( $available_variations ) || empty( $attributes ) ) {
			return array( 'woodmart' => array(), 'wcboost' => array(), 'html' => '' );
		}

		$original_product = isset( $GLOBALS['product'] ) ? $GLOBALS['product'] : null;
		$original_post    = isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null;
		$post             = get_post( $product->get_id() );
		if ( $post ) {
			$GLOBALS['post'] = $post;
		}
		$GLOBALS['product'] = $product;

		$removed_callbacks = $this->suspend_wcboost_swatches_callback();
		if ( $simulate_manager ) {
			self::begin_simulation();
		} else {
			self::begin_probe();
		}

		$html = '';
		try {
			$html = wc_get_template_html(
				'single-product/add-to-cart/variable.php',
				array(
					'available_variations' => $available_variations,
					'attributes'          => $attributes,
					'selected_attributes'  => $product->get_default_attributes(),
				)
			);
		} catch ( Throwable $e ) {
			$html = '';
		}

		if ( $simulate_manager ) {
			self::end_simulation();
		} else {
			self::end_probe();
		}
		$this->restore_wcboost_swatches_callback( $removed_callbacks );
		$GLOBALS['product'] = $original_product;
		$GLOBALS['post'] = $original_post;

		return $this->extract_render_markers( $html );
	}

	private function suspend_wcboost_swatches_callback() {
		global $wp_filter;
		$removed = array();
		$hook_name = 'woocommerce_dropdown_variation_attribute_options_html';
		if ( empty( $wp_filter[ $hook_name ] ) || ! is_object( $wp_filter[ $hook_name ] ) || ! isset( $wp_filter[ $hook_name ]->callbacks ) ) {
			return $removed;
		}

		foreach ( $wp_filter[ $hook_name ]->callbacks as $priority => $callbacks ) {
			foreach ( $callbacks as $entry ) {
				$callback = isset( $entry['function'] ) ? $entry['function'] : null;
				$accepted_args = isset( $entry['accepted_args'] ) ? (int) $entry['accepted_args'] : 1;
				if ( ! is_array( $callback ) || 2 !== count( $callback ) || ! is_object( $callback[0] ) || ! is_string( $callback[1] ) ) {
					continue;
				}
				$class_name = get_class( $callback[0] );
				if ( false === stripos( $class_name, 'WCBoost' ) || 'swatches_html' !== $callback[1] ) {
					continue;
				}
				if ( remove_filter( $hook_name, $callback, $priority ) ) {
					$removed[] = array( 'callback' => $callback, 'priority' => (int) $priority, 'accepted_args' => $accepted_args );
				}
			}
		}
		return $removed;
	}

	private function restore_wcboost_swatches_callback( $removed_callbacks ) {
		foreach ( (array) $removed_callbacks as $entry ) {
			if ( isset( $entry['callback'], $entry['priority'], $entry['accepted_args'] ) ) {
				add_filter( 'woocommerce_dropdown_variation_attribute_options_html', $entry['callback'], (int) $entry['priority'], (int) $entry['accepted_args'] );
			}
		}
	}

	private function extract_render_markers( $html ) {
		$result = array( 'woodmart' => array(), 'wcboost' => array(), 'html' => $html );
		if ( ! is_string( $html ) || '' === $html ) {
			return $result;
		}
		$result['woodmart'] = $this->extract_live_woodmart_blocks( $html );
		$result['wcboost'] = $this->extract_live_wcboost_blocks( $html );
		return $result;
	}

	public function get_disabled_attributes( $product_id ) {
		global $wpdb;
		$json = $wpdb->get_var( $wpdb->prepare( 'SELECT disabled_attrs FROM ' . VCM_Plugin::table_name() . ' WHERE product_id = %d', absint( $product_id ) ) );
		$value = $json ? json_decode( $json, true ) : array();
		if ( ! is_array( $value ) ) {
			return array();
		}
		$value = array_map( 'sanitize_key', $value );
		return array_values( array_unique( array_filter( $value ) ) );
	}

	public function is_attribute_managed( $product_id, $attribute_name ) {
		return in_array( sanitize_key( $attribute_name ), $this->get_disabled_attributes( $product_id ), true );
	}

	private function persist_disabled_attributes( $product_id, $list ) {
		global $wpdb;
		$product_id = absint( $product_id );
		$list = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) $list ) ) ) );
		$table = VCM_Plugin::table_name();

		if ( null === $wpdb->get_var( $wpdb->prepare( 'SELECT product_id FROM ' . $table . ' WHERE product_id = %d', $product_id ) ) ) {
			$this->index_product( $product_id );
		}

		$wpdb->update(
			$table,
			array(
				'disabled_attrs' => wp_json_encode( $list ),
				'managed'        => empty( $list ) ? 0 : 1,
			),
			array( 'product_id' => $product_id ),
			array( '%s', '%d' ),
			array( '%d' )
		);
		return $list;
	}

	public function set_attribute_managed( $product_id, $attribute_name, $disabled ) {
		$attribute_name = sanitize_key( $attribute_name );
		$list = $this->get_disabled_attributes( $product_id );

		if ( $disabled ) {
			if ( ! in_array( $attribute_name, $list, true ) ) {
				$list[] = $attribute_name;
			}
			if ( 'original' === $this->get_stage( $product_id ) ) {
				$this->start_quarantine( $product_id, array( $attribute_name ) );
			}
		} else {
			$list = array_values( array_diff( $list, array( $attribute_name ) ) );
		}

		$this->persist_disabled_attributes( $product_id, $list );
		if ( empty( $list ) ) {
			$this->set_stage( $product_id, 'original' );
		}
		return $list;
	}

	public function set_product_conflicts_managed( $product_id, $disabled ) {
		$data = $this->get_product_data( $product_id );
		if ( ! $data ) {
			return false;
		}
		$attrs = array_keys( $data['conflicts'] );
		if ( $disabled ) {
			return $this->start_quarantine( $product_id, $attrs );
		}
		$this->persist_disabled_attributes( $product_id, array() );
		$this->set_stage( $product_id, 'original' );
		return true;
	}

	public function start_quarantine( $product_id, $attrs ) {
		$attrs = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) $attrs ) ) ) );
		if ( empty( $attrs ) ) {
			return false;
		}
		$current = $this->get_disabled_attributes( $product_id );
		$merged  = array_values( array_unique( array_merge( $current, $attrs ) ) );
		$was_quarantined = 'quarantine' === $this->get_stage( $product_id );
		$this->persist_disabled_attributes( $product_id, $merged );
		if ( ! $was_quarantined || '' === $this->get_baseline_hash( $product_id ) ) {
			$this->save_baseline( $product_id );
		}
		$this->set_stage( $product_id, 'quarantine' );
		return true;
	}

	public function approve_quarantine( $product_id ) {
		if ( 'quarantine' !== $this->get_stage( $product_id ) ) {
			return false;
		}
		if ( ! $this->baseline_matches( $product_id ) ) {
			return false;
		}

		// Verify the manager is actually suppressing WoodMart output while WCBoost remains.
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return false;
		}
		$probe = $this->probe_real_single_product_render( $product, true );
		$disabled = $this->get_disabled_attributes( $product_id );
		if ( ! empty( $disabled ) ) {
			foreach ( $disabled as $attribute ) {
				if ( ! empty( $probe['woodmart'][ $attribute ] ) ) {
					return false;
				}
				$wcboost = $this->evaluate_wcboost_renderer( $product, $attribute );
				if ( empty( $wcboost['renders'] ) ) {
					return false;
				}
			}
		}
		if ( ! VCM_Persistence::approve_product( $product_id, $disabled ) ) {
			return false;
		}
		$this->set_stage( $product_id, 'approved' );
		return true;
	}

	public function restore_original( $product_id ) {
		$product_id = absint( $product_id );


		VCM_Persistence::restore_product( $product_id );
		$this->persist_disabled_attributes( $product_id, array() );
		$this->clear_baseline( $product_id );
		$this->set_stage( $product_id, 'original' );
		return true;
	}

	private function get_stage( $product_id ) {
		global $wpdb;
		$value = $wpdb->get_var( $wpdb->prepare( 'SELECT stage FROM ' . VCM_Plugin::table_name() . ' WHERE product_id = %d', absint( $product_id ) ) );
		return $value ? sanitize_key( $value ) : 'original';
	}

	public function get_stage_public( $product_id ) {
		return $this->get_stage( $product_id );
	}

	private function set_stage( $product_id, $stage ) {
		global $wpdb;
		$wpdb->update(
			VCM_Plugin::table_name(),
			array(
				'stage' => sanitize_key( $stage ),
				'quarantine_at' => ( 'quarantine' === $stage ? current_time( 'mysql' ) : null ),
				'approved_at' => ( 'approved' === $stage ? current_time( 'mysql' ) : null ),
			),
			array( 'product_id' => absint( $product_id ) ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	private function save_baseline( $product_id ) {
		global $wpdb;
		$hash = $this->fingerprint_product( $product_id );
		$wpdb->update(
			VCM_Plugin::table_name(),
			array( 'baseline_hash' => $hash ),
			array( 'product_id' => absint( $product_id ) ),
			array( '%s' ),
			array( '%d' )
		);
	}

	private function clear_baseline( $product_id ) {
		global $wpdb;
		$wpdb->update(
			VCM_Plugin::table_name(),
			array( 'baseline_hash' => '' ),
			array( 'product_id' => absint( $product_id ) ),
			array( '%s' ),
			array( '%d' )
		);
	}

	public function refresh_baseline( $product_id ) {
		if ( 'quarantine' !== $this->get_stage( $product_id ) ) {
			return false;
		}
		$this->save_baseline( $product_id );
		return true;
	}

	public function get_baseline_hash( $product_id ) {
		global $wpdb;
		return (string) $wpdb->get_var( $wpdb->prepare( 'SELECT baseline_hash FROM ' . VCM_Plugin::table_name() . ' WHERE product_id = %d', absint( $product_id ) ) );
	}

	public function baseline_matches( $product_id ) {
		$baseline = $this->get_baseline_hash( $product_id );
		if ( '' === $baseline ) {
			return true;
		}
		return hash_equals( $baseline, $this->fingerprint_product( $product_id ) );
	}

	private function fingerprint_product( $product_id ) {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return '';
		}

		$payload = array(
			'id' => $product_id,
			'attributes' => array(),
			'variation_ids' => array_map( 'absint', (array) $product->get_children() ),
			'variation_images' => array(),
			'wcboost' => get_post_meta( $product_id, 'wcboost_variation_swatches', true ),
			'woodmart_product_meta' => array(
				'_woodmart_swatches_attribute' => get_post_meta( $product_id, '_woodmart_swatches_attribute', true ),
			),
			'woodmart_options' => array(),
			'woodmart_terms' => array(),
		);

		if ( function_exists( 'woodmart_get_opt' ) ) {
			$payload['woodmart_options']['swatches_use_variation_images'] = woodmart_get_opt( 'swatches_use_variation_images' );
			$payload['woodmart_options']['grid_swatches_attribute'] = woodmart_get_opt( 'grid_swatches_attribute' );
		}

		foreach ( (array) $product->get_children() as $variation_id ) {
			$variation_id = absint( $variation_id );
			if ( ! $variation_id ) {
				continue;
			}
			$payload['variation_images'][ $variation_id ] = absint( get_post_thumbnail_id( $variation_id ) );
		}

		foreach ( $product->get_attributes() as $name => $attr ) {
			if ( ! $attr instanceof WC_Product_Attribute || ! $attr->get_variation() ) {
				continue;
			}
			$payload['attributes'][ $name ] = array(
				'variation' => $attr->get_variation(),
				'taxonomy' => $attr->is_taxonomy(),
				'options' => $attr->get_options(),
			);
			if ( $attr->is_taxonomy() ) {
				foreach ( $attr->get_options() as $term_id ) {
					$payload['woodmart_terms'][ $term_id ] = array(
						'color' => get_term_meta( $term_id, 'color', true ),
						'image' => get_term_meta( $term_id, 'image', true ),
						'not_dropdown' => get_term_meta( $term_id, 'not_dropdown', true ),
					);
				}
			}
		}

		return hash( 'sha256', wp_json_encode( $payload ) );
	}

	public function index_product( $product_id ) {
		global $wpdb;
		$data = $this->get_product_data( $product_id );
		if ( ! $data ) {
			$wpdb->delete( VCM_Plugin::table_name(), array( 'product_id' => absint( $product_id ) ), array( '%d' ) );
			return false;
		}

		$disabled = $this->get_disabled_attributes( $product_id );
		$stage = $this->get_stage( $product_id );
		// A manual quarantine/final-approved rule is manager state, not a derived
		// conflict flag. A later scan must not silently erase it just because the
		// current renderer conditions changed. Restore Original is the explicit way
		// to remove that state.
		if ( ! in_array( $stage, array( 'quarantine', 'approved' ), true ) ) {
			$disabled = array();
			$stage = 'original';
		}
		$payload = array(
			'product_id'      => absint( $product_id ),
			'variation_count' => absint( $data['variation_count'] ),
			'conflict'        => $data['conflict'] ? 1 : 0,
			'managed'         => ! empty( $disabled ) ? 1 : 0,
			'disabled_attrs'  => wp_json_encode( $disabled ),
			'woodmart_attrs'  => wp_json_encode( array_values( array_keys( $data['woodmart_attrs'] ) ) ),
			'wcboost_attrs'   => wp_json_encode( array_values( array_keys( $data['wcboost_attrs'] ) ) ),
			'last_scanned'    => current_time( 'mysql' ),
			'stage'           => $stage,
		);
		$wpdb->replace(
			VCM_Plugin::table_name(),
			$payload,
			array( '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s' )
		);
		return true;
	}

	/**
	 * Refresh an existing index row without changing its quarantine/approval stage.
	 * This is used by safe rechecks and bulk quarantine to clear stale conflict flags.
	 */
	public function sync_scan_row( $product_id, $data = null ) {
		global $wpdb;
		$product_id = absint( $product_id );
		if ( ! $product_id ) {
			return false;
		}
		if ( ! is_array( $data ) ) {
			$data = $this->get_product_data( $product_id );
		}
		if ( ! $data ) {
			$wpdb->delete( VCM_Plugin::table_name(), array( 'product_id' => $product_id ), array( '%d' ) );
			return false;
		}
		$wpdb->update(
			VCM_Plugin::table_name(),
			array(
				'variation_count' => absint( $data['variation_count'] ),
				'conflict'        => ! empty( $data['conflict'] ) ? 1 : 0,
				'woodmart_attrs'  => wp_json_encode( array_values( array_keys( $data['woodmart_attrs'] ) ) ),
				'wcboost_attrs'   => wp_json_encode( array_values( array_keys( $data['wcboost_attrs'] ) ) ),
				'last_scanned'    => current_time( 'mysql' ),
			),
			array( 'product_id' => $product_id ),
			array( '%d', '%d', '%s', '%s', '%s' ),
			array( '%d' )
		);
		return true;
	}

	public function index_products( $ids ) {
		$count = 0;
		foreach ( (array) $ids as $id ) {
			if ( $this->index_product( $id ) ) {
				$count++;
			}
		}
		return $count;
	}

	public function get_product_language( $product_id ) {
		if ( function_exists( 'apply_filters' ) ) {
			$wpml = apply_filters( 'wpml_post_language_details', null, $product_id );
			if ( is_array( $wpml ) && ! empty( $wpml['language_code'] ) ) {
				return strtoupper( sanitize_key( $wpml['language_code'] ) );
			}
		}
		if ( function_exists( 'pll_get_post_language' ) ) {
			$lang = pll_get_post_language( $product_id, 'slug' );
			if ( $lang ) {
				return strtoupper( sanitize_key( $lang ) );
			}
		}
		return '';
	}

	public function get_thumbnail( $product_id ) {
		$image_id = get_post_thumbnail_id( $product_id );
		if ( $image_id ) {
			$url = wp_get_attachment_image_url( $image_id, 'woocommerce_thumbnail' );
			if ( $url ) {
				return $url;
			}
		}
		return wc_placeholder_img_src( 'woocommerce_thumbnail' );
	}

	public function get_engine_status() {
		return array(
			'woocommerce' => array(
				'active'  => VCM_Plugin::is_woocommerce_ready(),
				'version' => defined( 'WC_VERSION' ) ? WC_VERSION : '',
			),
			'woodmart' => array(
				'active'  => $this->is_woodmart_active(),
				'version' => defined( 'WOODMART_VERSION' ) ? WOODMART_VERSION : '',
			),
			'wcboost' => array(
				'active'  => $this->is_wcboost_active(),
				'version' => defined( 'WCBOOST_VARIATION_SWATCHES_FILE' ) && class_exists( '\\WCBoost\\VariationSwatches\\Plugin' ) ? (string) ( \WCBoost\VariationSwatches\Plugin::instance()->version ) : '',
			),
		);
	}

	public function count_variable_products() {
		global $wpdb;
		$sql = "SELECT COUNT(DISTINCT p.ID)
			FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID
			INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
			INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
			WHERE p.post_type = 'product'
			AND p.post_status IN ('publish','private','draft')
			AND tt.taxonomy = 'product_type'
			AND t.slug = 'variable'";
		return absint( $wpdb->get_var( $sql ) );
	}

	public function stats() {
		global $wpdb;
		$table = VCM_Plugin::table_name();
		return array(
			'scanned'    => absint( $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ) ),
			'conflicts'  => absint( $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE conflict = 1" ) ),
			'quarantine' => absint( $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE stage = 'quarantine'" ) ),
			'approved'   => absint( $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE stage = 'approved'" ) ),
			'woodmart'   => absint( $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE woodmart_attrs IS NOT NULL AND woodmart_attrs <> '[]'" ) ),
			'wcboost'    => absint( $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE wcboost_attrs IS NOT NULL AND wcboost_attrs <> '[]'" ) ),
		);
	}

	public function prune_non_variable_indexed_products() {
		global $wpdb;
		$table = VCM_Plugin::table_name();
		$sql = "DELETE i FROM {$table} i
			WHERE NOT EXISTS (
				SELECT 1
				FROM {$wpdb->term_relationships} tr
				INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
				INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
				WHERE tr.object_id = i.product_id
				AND tt.taxonomy = 'product_type'
				AND t.slug = 'variable'
			)";
		$wpdb->query( $sql );
	}

	public function get_scan_state() {
		$state = get_option( VCM_Plugin::state_option(), array( 'status' => 'never' ) );
		return is_array( $state ) ? $state : array( 'status' => 'never' );
	}

	public function set_scan_state( $state ) {
		update_option( VCM_Plugin::state_option(), (array) $state, false );
	}
}
