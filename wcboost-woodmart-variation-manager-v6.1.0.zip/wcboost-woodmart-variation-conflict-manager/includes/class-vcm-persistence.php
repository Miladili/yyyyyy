<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Independent persistence layer for Final Approved rules.
 *
 * The main plugin is responsible for scan/quarantine/admin UX. Once a rule is
 * Final Approved, this class stores an exact copy in a dedicated option and
 * installs a tiny must-use compatibility plugin. That MU plugin remains active
 * even when this manager is deactivated, while leaving WooCommerce, WoodMart,
 * WCBoost, products, attributes, terms and variations untouched.
 */
final class VCM_Persistence {
	const OPTION_NAME = 'vcm_persistent_rules';
	const MU_FILE_NAME = 'vcm-variation-conflict-persistent.php';
	const RULES_VERSION = 2;

	private static $last_error = '';

	public static function last_error() {
		return self::$last_error;
	}

	public static function install_persistent_layer() {
		$rules = self::get_rules();
		if ( empty( $rules ) ) {
			return self::remove_mu_file();
		}
		return self::write_mu_file();
	}

	public static function downgrade_legacy_approvals_to_quarantine() {
		global $wpdb;
		$table = VCM_Plugin::table_name();
		// Do not rely on a new table column here; stage is already present in 3.0.
		$wpdb->query( "UPDATE {$table} SET stage = 'quarantine', approved_at = NULL WHERE stage = 'approved'" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		// Any old manager-only approvals must never become silently persistent.
		delete_option( self::OPTION_NAME );
		self::remove_mu_file();
	}

	public static function get_rules() {
		$rules = get_option( self::OPTION_NAME, array() );
		if ( ! is_array( $rules ) ) {
			return array();
		}

		$out = array();
		foreach ( $rules as $product_id => $attributes ) {
			$product_id = absint( $product_id );
			if ( ! $product_id || ! is_array( $attributes ) ) {
				continue;
			}
			$clean = array();
			foreach ( $attributes as $attribute ) {
				$attribute = sanitize_key( $attribute );
				if ( $attribute ) {
					$clean[] = $attribute;
				}
			}
			$clean = array_values( array_unique( $clean ) );
			if ( ! empty( $clean ) ) {
				$out[ $product_id ] = $clean;
			}
		}
		return $out;
	}

	public static function is_approved( $product_id, $attribute = null ) {
		$rules = self::get_rules();
		$product_id = absint( $product_id );
		if ( ! isset( $rules[ $product_id ] ) ) {
			return false;
		}
		if ( null === $attribute ) {
			return true;
		}
		return in_array( sanitize_key( $attribute ), $rules[ $product_id ], true );
	}

	public static function approve_product( $product_id, $attributes ) {
		$product_id = absint( $product_id );
		$attributes = self::sanitize_attributes( $attributes );
		if ( ! $product_id || empty( $attributes ) ) {
			self::$last_error = __( 'No approved product/attribute rule was supplied.', 'vcm' );
			return false;
		}

		$rules = self::get_rules();
		$current = isset( $rules[ $product_id ] ) ? $rules[ $product_id ] : array();
		$merged  = array_values( array_unique( array_merge( $current, $attributes ) ) );
		$rules[ $product_id ] = $merged;

		// Create/verify the MU layer first. If the filesystem is not writable,
		// do not publish the option, so Final Approved can never become half-persistent.
		self::clear_woodmart_caches( $product_id );

		if ( ! self::write_mu_file() ) {
			self::$last_error = __( 'The persistent layer could not be installed. Make sure wp-content/mu-plugins is writable, then try Final approval again.', 'vcm' );
			return false;
		}

		update_option( self::OPTION_NAME, $rules, false );
		return true;
	}

	public static function restore_product( $product_id ) {
		$product_id = absint( $product_id );
		$rules = self::get_rules();
		unset( $rules[ $product_id ] );

		// Disable the rule first. Even if cleanup of the MU file later fails,
		// its code will read an option without this product and therefore do nothing.
		update_option( self::OPTION_NAME, $rules, false );
		self::clear_woodmart_caches( $product_id );

		if ( empty( $rules ) ) {
			self::remove_mu_file();
		} else {
			self::write_mu_file();
		}
		return true;
	}

	public static function clear_woodmart_caches_public( $product_id ) {
		self::clear_woodmart_caches( $product_id );
	}

	private static function clear_woodmart_caches( $product_id ) {
		$product_id = absint( $product_id );
		if ( ! $product_id ) {
			return;
		}

		delete_transient( 'woodmart_swatches_cache_' . $product_id );
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : false;
		if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
			return;
		}

		foreach ( (array) $product->get_attributes() as $attribute_name => $attribute ) {
			delete_transient( 'woodmart_swatches_cache_' . $attribute_name . '_' . $product_id );
		}
	}

	private static function sanitize_attributes( $attributes ) {
		$out = array();
		foreach ( (array) $attributes as $attribute ) {
			$attribute = sanitize_key( $attribute );
			if ( $attribute ) {
				$out[] = $attribute;
			}
		}
		return array_values( array_unique( $out ) );
	}

	private static function mu_dir() {
		return defined( 'WPMU_PLUGIN_DIR' ) ? WPMU_PLUGIN_DIR : WP_CONTENT_DIR . '/mu-plugins';
	}

	private static function mu_path() {
		return trailingslashit( self::mu_dir() ) . self::MU_FILE_NAME;
	}

	private static function write_mu_file() {
		self::$last_error = '';
		$dir = self::mu_dir();
		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return false;
		}
		if ( ! is_dir( $dir ) || ! is_writable( $dir ) ) {
			return false;
		}

		$path = self::mu_path();
		$contents = <<<'PHP'
<?php
/**
// Persistent MU-plugin template header lives only inside the generated MU file below.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'vcm_persistent_rules' ) ) {
	function vcm_persistent_rules() {
		static $rules = null;
		if ( null !== $rules ) {
			return $rules;
		}
		$rules = get_option( 'vcm_persistent_rules', array() );
		return is_array( $rules ) ? $rules : array();
	}
}

if ( ! function_exists( 'vcm_persistent_current_product_id' ) ) {
	function vcm_persistent_current_product_id() {
		static $id = null;
		if ( null !== $id ) {
			return $id;
		}
		global $product, $post;
		if ( is_object( $product ) && is_a( $product, 'WC_Product' ) ) {
			$id = absint( $product->get_id() );
		} elseif ( $post instanceof WP_Post && 'product' === $post->post_type ) {
			$id = absint( $post->ID );
		} else {
			$id = absint( get_queried_object_id() );
		}
		return $id;
	}
}

add_filter( 'get_term_metadata', function( $value, $object_id, $meta_key, $single, $meta_type ) {
	if ( 'term' !== $meta_type || ! function_exists( 'is_product' ) || ! is_product() ) {
		return $value;
	}
	if ( ! in_array( $meta_key, array( 'color', 'image', 'not_dropdown' ), true ) ) {
		return $value;
	}

	$rules = vcm_persistent_rules();
	$product_id = vcm_persistent_current_product_id();
	if ( ! $product_id || empty( $rules[ $product_id ] ) ) {
		return $value;
	}

	$trace = debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 8 );
	$is_woodmart = false;
	foreach ( $trace as $frame ) {
		if ( ! empty( $frame['function'] ) && in_array( $frame['function'], array( 'woodmart_has_swatch', 'woodmart_has_swatches', 'woodmart_get_option_variations' ), true ) ) {
			$is_woodmart = true;
			break;
		}
	}
	if ( ! $is_woodmart ) {
		return $value;
	}

	$term = get_term( absint( $object_id ) );
	if ( ! $term || is_wp_error( $term ) ) {
		return $value;
	}
	$disabled = array_map( 'sanitize_key', (array) $rules[ $product_id ] );
	return in_array( sanitize_key( $term->taxonomy ), $disabled, true ) ? false : $value;
}, 99, 5 );

// Defensive renderer boundary. It is used only on final-approved products and only
// when WoodMart markup still exists after metadata suppression (for example, when a
// theme build has already cached its swatch decision). It does not hide via CSS.
add_action( 'woocommerce_before_variations_form', function() {
	if ( ! function_exists( 'is_product' ) || ! is_product() || ! function_exists( 'wc_get_product' ) ) {
		return;
	}
	$id = vcm_persistent_current_product_id();
	$rules = vcm_persistent_rules();
	if ( ! $id || empty( $rules[ $id ] ) ) {
		return;
	}
	$GLOBALS['vcm_persistent_buffer_level'] = ob_get_level();
	ob_start();
}, 1 );

add_action( 'woocommerce_after_variations_form', function() {
	if ( ! isset( $GLOBALS['vcm_persistent_buffer_level'] ) ) {
		return;
	}
	$level = (int) $GLOBALS['vcm_persistent_buffer_level'];
	unset( $GLOBALS['vcm_persistent_buffer_level'] );
	if ( ob_get_level() <= $level ) {
		return;
	}

	$html = ob_get_clean();
	$id = vcm_persistent_current_product_id();
	$rules = vcm_persistent_rules();
	$disabled = $id && ! empty( $rules[ $id ] ) ? array_map( 'sanitize_title', (array) $rules[ $id ] ) : array();
	if ( empty( $disabled ) || ( false === stripos( $html, 'wd-swatches-single' ) && false === stripos( $html, 'swatches-on-single' ) ) || strlen( $html ) > 500000 ) {
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		return;
	}

	foreach ( array_unique( $disabled ) as $taxonomy ) {
		$ids = array( sanitize_title( $taxonomy ), sanitize_title( preg_replace( '/^pa_/', '', $taxonomy ) ) );
		foreach ( array_unique( $ids ) as $data_id ) {
			while ( preg_match( '~<div\b(?=[^>]*\bclass=(?:"|\')([^"\']*(?:\bwd-swatches-single\b|\bswatches-on-single\b)[^"\']*)(?:"|\'))(?=[^>]*\bdata-id=(?:"|\')' . preg_quote( $data_id, '~' ) . '(?:"|\'))[^>]*>~i', $html, $m, PREG_OFFSET_CAPTURE ) ) {
				$open_pos = (int) $m[0][1];
				$after = $open_pos + strlen( $m[0][0] );
				$tail = substr( $html, $after );
				preg_match_all( '~</?div\b[^>]*>~i', $tail, $tags, PREG_OFFSET_CAPTURE );
				$depth = 1;
				$close_end = null;
				foreach ( $tags[0] as $tag ) {
					if ( 0 === stripos( $tag[0], '</div' ) ) {
						--$depth;
						if ( 0 === $depth ) {
							$close_end = $after + $tag[1] + strlen( $tag[0] );
							break;
						}
					} else {
						++$depth;
					}
				}
				if ( null === $close_end ) {
					// Fail safe: never damage unknown markup.
					echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					return;
				}
				$html = substr( $html, 0, $open_pos ) . substr( $html, $close_end );
			}
		}
	}
	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}, 99999 );
PHP;

		// Write with LOCK_EX. If a previous file exists, preserve its owner/permissions where possible.
		$result = file_put_contents( $path, $contents, LOCK_EX );
		if ( false === $result ) {
			self::$last_error = __( 'Could not write the persistent MU plugin file.', 'vcm' );
			return false;
		}
		return true;
	}

	private static function remove_mu_file() {
		$path = self::mu_path();
		if ( file_exists( $path ) ) {
			return @unlink( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
		return true;
	}
}
