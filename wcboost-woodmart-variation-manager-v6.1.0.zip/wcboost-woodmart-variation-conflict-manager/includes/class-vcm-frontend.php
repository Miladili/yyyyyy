<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VCM_Frontend {
	private $analyzer;

	private $buffer_level = null;

	public function __construct( $analyzer ) {
		$this->analyzer = $analyzer;
		// Primary protection: do not let WoodMart's term-swatch metadata reach its renderer.
		add_filter( 'get_term_metadata', array( $this, 'suppress_woodmart_term_swatch_meta' ), 99, 5 );

		// Defensive renderer boundary: if a WoodMart build still emits its wrapper through another
		// internal path, remove only that server-rendered WoodMart block for quarantined attributes.
		// This is NOT CSS hiding and does not touch WooCommerce/WCBoost variation markup.
		add_action( 'woocommerce_before_variations_form', array( $this, 'begin_renderer_guard' ), 1 );
		add_action( 'woocommerce_after_variations_form', array( $this, 'end_renderer_guard' ), 99999 );
	}

	/**
	 * Suppress the WoodMart term-swatch metadata only while WoodMart's own
	 * swatch renderer is asking for it. This prevents WoodMart from creating
	 * its swatch markup; nothing is CSS-hidden and nothing is written to DB.
	 */
	public function suppress_woodmart_term_swatch_meta( $value, $object_id, $meta_key, $single, $meta_type ) {
		if ( 'term' !== $meta_type || VCM_Analyzer::is_probe_mode() ) {
			return $value;
		}
		if ( is_admin() && ! VCM_Analyzer::is_simulation_mode() ) {
			return $value;
		}
		if ( ! is_admin() && ! is_product() ) {
			return $value;
		}
		if ( ! in_array( $meta_key, array( 'color', 'image', 'not_dropdown' ), true ) ) {
			return $value;
		}
		if ( ! $this->inside_woodmart_swatch_reader() ) {
			return $value;
		}

		global $post;
		$product_id = ( $post && ! empty( $post->ID ) ) ? absint( $post->ID ) : 0;
		if ( ! $product_id ) {
			return $value;
		}

		if ( 'quarantine' !== $this->analyzer->get_stage_public( $product_id ) ) {
			return $value;
		}

		$disabled = $this->analyzer->get_disabled_attributes( $product_id );
		if ( empty( $disabled ) ) {
			return $value;
		}

		$term = get_term( absint( $object_id ) );
		if ( ! $term || is_wp_error( $term ) ) {
			return $value;
		}

		if ( in_array( sanitize_key( $term->taxonomy ), $disabled, true ) ) {
			return false;
		}

		return $value;
	}

	private function inside_woodmart_swatch_reader() {
		$trace = debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 12 );
		$known = array(
			'woodmart_has_swatch',
			'woodmart_has_swatches',
			'woodmart_get_option_variations',
		);
		foreach ( $trace as $frame ) {
			if ( ! empty( $frame['function'] ) && in_array( $frame['function'], $known, true ) ) {
				return true;
			}
		}
		return false;
	}
	public function begin_renderer_guard() {
		if ( ( is_admin() && ! VCM_Analyzer::is_simulation_mode() ) || VCM_Analyzer::is_probe_mode() || ! $this->is_product_request() ) {
			return;
		}

		$product_id = $this->get_current_product_id();
		if ( ! $product_id || 'quarantine' !== $this->analyzer->get_stage_public( $product_id ) || empty( $this->analyzer->get_disabled_attributes( $product_id ) ) ) {
			return;
		}

		$this->buffer_level = ob_get_level();
		ob_start();
	}

	public function end_renderer_guard() {
		if ( null === $this->buffer_level || ob_get_level() <= $this->buffer_level ) {
			$this->buffer_level = null;
			return;
		}

		$html = ob_get_clean();
		$this->buffer_level = null;

		$product_id = $this->get_current_product_id();
		$disabled   = $product_id ? $this->analyzer->get_disabled_attributes( $product_id ) : array();

		if ( ! $product_id || empty( $disabled ) || '' === $html ) {
			echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		$html = $this->remove_quarantined_woodmart_wrappers( $html, $disabled );
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private function is_product_request() {
		return is_product() || ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() );
	}

	private function get_current_product_id() {
		global $product, $post;

		if ( is_object( $product ) && is_a( $product, 'WC_Product' ) ) {
			return absint( $product->get_id() );
		}

	if ( $post instanceof WP_Post && 'product' === $post->post_type ) {
			return absint( $post->ID );
		}

		return absint( get_queried_object_id() );
	}

	/**
	 * Remove only server-rendered WoodMart single-product swatch wrappers whose data-id
	 * belongs to a quarantined attribute. WCBoost's markup has different classes and is untouched.
	 *
	 * @param string $html
	 * @param array  $disabled_taxonomies
	 * @return string
	 */
	private function remove_quarantined_woodmart_wrappers( $html, $disabled_taxonomies ) {
		$disabled_ids = array();
		foreach ( (array) $disabled_taxonomies as $taxonomy ) {
			$disabled_ids[] = sanitize_title( $taxonomy );
			$disabled_ids[] = sanitize_title( preg_replace( '/^pa_/', '', $taxonomy ) );
		}
		$disabled_ids = array_values( array_unique( array_filter( $disabled_ids ) ) );

		if ( empty( $disabled_ids ) || ( false === stripos( $html, 'wd-swatches-single' ) && false === stripos( $html, 'swatches-on-single' ) ) ) {
			return $html;
		}

		foreach ( $disabled_ids as $data_id ) {
			$pattern = "~<div\\b(?=[^>]*\\bclass=(?:\"|')[^\"']*(?:\\bwd-swatches-single\\b|\\bswatches-on-single\\b|\\bswatches-select\\b)[^\"']*(?:\"|'))(?=[^>]*\\bdata-id=(?:\"|')" . preg_quote( $data_id, '~' ) . "(?:\"|'))[^>]*>~i";
			while ( preg_match( $pattern, $html, $match, PREG_OFFSET_CAPTURE ) ) {
				$open_pos = (int) $match[0][1];
				$open_tag = $match[0][0];
				$offset_after_open = $open_pos + strlen( $open_tag );
				$tail = substr( $html, $offset_after_open );
				$tags = array();
				preg_match_all( '~</?div\\b[^>]*>~i', $tail, $tags, PREG_OFFSET_CAPTURE );
				$depth = 1;
				$close_end = null;

				foreach ( $tags[0] as $tag ) {
					$tag_text = $tag[0];
					if ( 0 === stripos( $tag_text, '</div' ) ) {
						--$depth;
						if ( 0 === $depth ) {
							$close_end = $offset_after_open + $tag[1] + strlen( $tag_text );
							break;
						}
					} else {
						++$depth;
					}
				}

				if ( null === $close_end ) {
					// Fail safe: never rewrite markup when the wrapper cannot be balanced.
					return $html;
				}

				$html = substr( $html, 0, $open_pos ) . substr( $html, $close_end );
			}
		}

		return $html;
	}

}
