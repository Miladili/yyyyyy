<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class VCM_Plugin {
	private static $instance = null;
	public $analyzer;
	public $ai;
	public $frontend;
	public $admin;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->maybe_upgrade();
		$this->analyzer  = new VCM_Analyzer();
		$this->ai        = new VCM_AI();
		$this->frontend  = new VCM_Frontend( $this->analyzer );
		$this->admin     = new VCM_Admin( $this->analyzer, $this->ai );
	}

	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'vcm_variation_index';
	}

	public static function state_option() {
		return 'vcm_scan_state';
	}

	public static function version_option() {
		return 'vcm_db_version';
	}

	public static function activate() {
		self::create_or_upgrade_table();
		VCM_AI::create_or_upgrade_tables();
		VCM_Persistence::install_persistent_layer();
		update_option( self::version_option(), VCM_DB_VERSION, false );
		if ( false === get_option( self::state_option(), false ) ) {
			add_option( self::state_option(), array( 'status' => 'never' ), '', false );
		}
	}

	private function maybe_upgrade() {
		$current = get_option( self::version_option(), '' );
		if ( VCM_DB_VERSION !== $current ) {
			self::create_or_upgrade_table();
			VCM_AI::create_or_upgrade_tables();
			VCM_Persistence::install_persistent_layer();
				update_option( self::version_option(), VCM_DB_VERSION, false );
		}
	}

	private static function create_or_upgrade_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table_name();
		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			product_id bigint(20) unsigned NOT NULL,
			variation_count int(11) unsigned NOT NULL DEFAULT 0,
			conflict tinyint(1) unsigned NOT NULL DEFAULT 0,
			managed tinyint(1) unsigned NOT NULL DEFAULT 0,
			disabled_attrs longtext NULL,
			woodmart_attrs longtext NULL,
			wcboost_attrs longtext NULL,
			last_scanned datetime NULL,
			stage varchar(20) NOT NULL DEFAULT 'original',
			baseline_hash char(64) NOT NULL DEFAULT '',
			quarantine_at datetime NULL,
			approved_at datetime NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY product_id (product_id),
			KEY conflict (conflict),
			KEY managed (managed),
			KEY stage (stage),
			KEY last_scanned (last_scanned)
		) {$charset};";
		dbDelta( $sql );
	}

	public static function deactivate() {
		// Keep manager data and approved persistence. Deactivation never touches product data.
	}

	public static function is_woocommerce_ready() {
		return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_product' );
	}
}
