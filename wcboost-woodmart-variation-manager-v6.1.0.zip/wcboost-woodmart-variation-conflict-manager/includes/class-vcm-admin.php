<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VCM_Admin {
	private $analyzer;
	private $ai;
	private $page_slug = 'vcm-variation-conflicts';

	public function __construct( $analyzer, $ai ) {
		$this->analyzer = $analyzer;
		$this->ai       = $ai;

		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'save_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_notices', array( $this, 'requirements_notice' ) );
		add_filter( 'bulk_actions-edit-product', array( $this, 'product_bulk_actions' ) );
		add_filter( 'handle_bulk_actions-edit-product', array( $this, 'handle_product_bulk_action' ), 10, 3 );
		add_action( 'add_meta_boxes', array( $this, 'product_meta_box' ) );

		add_action( 'wp_ajax_vcm_start_scan', array( $this, 'ajax_start_scan' ) );
		add_action( 'wp_ajax_vcm_scan_batch', array( $this, 'ajax_scan_batch' ) );
		add_action( 'wp_ajax_vcm_toggle_attribute', array( $this, 'ajax_toggle_attribute' ) );
		add_action( 'wp_ajax_vcm_bulk_manage', array( $this, 'ajax_bulk_manage' ) );
		add_action( 'wp_ajax_vcm_quarantine_all', array( $this, 'ajax_quarantine_all' ) );
		add_action( 'wp_ajax_vcm_approve', array( $this, 'ajax_approve' ) );
		add_action( 'wp_ajax_vcm_restore', array( $this, 'ajax_restore' ) );
		add_action( 'wp_ajax_vcm_recheck', array( $this, 'ajax_recheck' ) );

		add_action( 'wp_ajax_vcm_ai_translate', array( $this, 'ajax_ai_translate' ) );
		add_action( 'wp_ajax_vcm_ai_translate_batch', array( $this, 'ajax_ai_translate_batch' ) );
		add_action( 'wp_ajax_vcm_ai_preview', array( $this, 'ajax_ai_preview' ) );
		add_action( 'wp_ajax_vcm_ai_clean', array( $this, 'ajax_ai_clean' ) );
		add_action( 'wp_ajax_vcm_ai_rewrite', array( $this, 'ajax_ai_rewrite' ) );
		add_action( 'wp_ajax_vcm_ai_seo', array( $this, 'ajax_ai_seo' ) );
		add_action( 'wp_ajax_vcm_ai_test', array( $this, 'ajax_ai_test' ) );
		add_action( 'wp_ajax_vcm_ai_rollback', array( $this, 'ajax_ai_rollback' ) );
		add_action( 'wp_ajax_vcm_ai_catalog_scan', array( $this, 'ajax_ai_catalog_scan' ) );
		add_action( 'wp_ajax_vcm_missing_scan_start', array( $this, 'ajax_missing_scan_start' ) );
		add_action( 'wp_ajax_vcm_missing_scan_batch', array( $this, 'ajax_missing_scan_batch' ) );
	}

	public function menu() {
		add_menu_page(
			__( 'WCBoost Manager', 'vcm' ),
			__( 'WCBoost Manager', 'vcm' ),
			'manage_woocommerce',
			$this->page_slug,
			array( $this, 'render_page' ),
			'dashicons-admin-generic',
			56
		);
		$parent = $this->page_slug;
		add_submenu_page( $parent, __( 'Variation Conflicts', 'vcm' ), __( 'Variation Conflicts', 'vcm' ), 'manage_woocommerce', $parent, array( $this, 'render_page' ) );
		add_submenu_page( $parent, __( 'Missing Languages', 'vcm' ), __( 'Missing Languages', 'vcm' ), 'manage_woocommerce', 'vcm-variation-conflicts-missing', array( $this, 'render_missing_languages_page' ) );
		add_submenu_page( $parent, __( 'AI Translation Center', 'vcm' ), __( 'AI Translation Center', 'vcm' ), 'manage_woocommerce', 'vcm-variation-conflicts-translate', array( $this, 'render_translation_page' ) );
		add_submenu_page( $parent, __( 'Catalog Health', 'vcm' ), __( 'Catalog Health', 'vcm' ), 'manage_woocommerce', 'vcm-variation-conflicts-health', array( $this, 'render_health_page' ) );
		add_submenu_page( $parent, __( 'AI Tools & Logs', 'vcm' ), __( 'AI Tools & Logs', 'vcm' ), 'manage_woocommerce', 'vcm-variation-conflicts-tools', array( $this, 'render_tools_page' ) );
		add_submenu_page( $parent, __( 'Settings', 'vcm' ), __( 'Settings', 'vcm' ), 'manage_woocommerce', 'vcm-variation-conflicts-settings', array( $this, 'render_settings_page' ) );
	}


	public function product_bulk_actions( $actions ) {
		$actions['vcm_ai_translate'] = __( 'Open AI Translator for selected products', 'vcm' );
		return $actions;
	}

	public function handle_product_bulk_action( $redirect_to, $action, $post_ids ) {
		if ( 'vcm_ai_translate' !== $action || empty( $post_ids ) ) {
			return $redirect_to;
		}
		$ids = array_map( 'absint', (array) $post_ids );
		$ids = array_values( array_filter( $ids ) );
		if ( empty( $ids ) ) {
			return $redirect_to;
		}
		return add_query_arg( array( 'page' => 'vcm-variation-conflicts-translate', 'selected_products' => implode( ',', $ids ) ), admin_url( 'admin.php' ) );
	}

	public function assets( $hook ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$allowed_pages = array( $this->page_slug, 'vcm-variation-conflicts-missing', 'vcm-variation-conflicts-translate', 'vcm-variation-conflicts-health', 'vcm-variation-conflicts-tools', 'vcm-variation-conflicts-settings' );
		$current_page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		$is_manager_page = in_array( $current_page, $allowed_pages, true ) || $hook === 'toplevel_page_' . $this->page_slug;
		$is_product_editor = in_array( $hook, array( 'post.php', 'post-new.php' ), true ) && $screen && 'product' === $screen->post_type;
		if ( ! $is_manager_page && ! $is_product_editor ) {
			return;
		}
		wp_enqueue_style( 'vcm-admin', VCM_URL . 'assets/admin.css', array(), VCM_VERSION );
		wp_enqueue_script( 'vcm-admin', VCM_URL . 'assets/admin.js', array( 'jquery' ), VCM_VERSION, true );
		wp_localize_script(
			'vcm-admin',
			'VCM_DATA',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'vcm_admin' ),
				'batchSize'   => 10,
				'productEdit' => $is_product_editor,
				'productId'   => $is_product_editor ? absint( get_the_ID() ) : 0,
			)
		);
	}

	public function requirements_notice() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		if ( ! VCM_Plugin::is_woocommerce_ready() ) {
			echo '<div class="notice notice-error"><p><strong>WCBoost Manager:</strong> WooCommerce is required.</p></div>';
		}
	}

	public function save_settings() {
		if ( ! isset( $_POST['vcm_save_settings'] ) || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		check_admin_referer( 'vcm_save_settings' );
		VCM_AI::update_settings(
			array(
				'provider_mode' => isset( $_POST['provider_mode'] ) ? wp_unslash( $_POST['provider_mode'] ) : 'auto',
				'vertex_api_key' => isset( $_POST['vertex_api_key'] ) ? wp_unslash( $_POST['vertex_api_key'] ) : '',
				'vertex_model' => isset( $_POST['vertex_model'] ) ? wp_unslash( $_POST['vertex_model'] ) : '',
				'vertex_fallback_model' => isset( $_POST['vertex_fallback_model'] ) ? wp_unslash( $_POST['vertex_fallback_model'] ) : '',
				'api_key' => isset( $_POST['api_key'] ) ? wp_unslash( $_POST['api_key'] ) : '',
				'free_api_key' => isset( $_POST['free_api_key'] ) ? wp_unslash( $_POST['free_api_key'] ) : '',
				'paid_api_key' => isset( $_POST['paid_api_key'] ) ? wp_unslash( $_POST['paid_api_key'] ) : '',
				'usage_mode' => isset( $_POST['usage_mode'] ) ? wp_unslash( $_POST['usage_mode'] ) : 'auto',
				'model' => isset( $_POST['model'] ) ? wp_unslash( $_POST['model'] ) : '',
				'fallback_model' => isset( $_POST['fallback_model'] ) ? wp_unslash( $_POST['fallback_model'] ) : '',
				'tone' => isset( $_POST['tone'] ) ? wp_unslash( $_POST['tone'] ) : '',
				'default_targets' => isset( $_POST['default_targets'] ) ? wp_unslash( $_POST['default_targets'] ) : '',
				'preserve_html' => isset( $_POST['preserve_html'] ) ? 1 : 0,
				'api_version_mode' => isset( $_POST['api_version_mode'] ) ? wp_unslash( $_POST['api_version_mode'] ) : 'auto',
				'auth_mode' => isset( $_POST['auth_mode'] ) ? wp_unslash( $_POST['auth_mode'] ) : 'auto',
			)
		);
		VCM_AI::save_glossary_text( isset( $_POST['glossary'] ) ? wp_unslash( $_POST['glossary'] ) : '' );
		add_settings_error( 'vcm_messages', 'vcm_saved', __( 'AI settings and glossary saved.', 'vcm' ), 'updated' );
	}

	private function verify_request() {
		check_ajax_referer( 'vcm_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'vcm' ) ), 403 );
		}
		if ( ! VCM_Plugin::is_woocommerce_ready() ) {
			wp_send_json_error( array( 'message' => __( 'WooCommerce is not active.', 'vcm' ) ), 400 );
		}
	}

	public function product_meta_box() {
		add_meta_box( 'vcm_ai_product_box', __( 'AI Product Tools', 'vcm' ), array( $this, 'render_product_meta_box' ), 'product', 'side', 'default' );
	}

	public function render_product_meta_box( $post ) {
		$quality = VCM_AI::quality( $post->ID );
		$languages = VCM_AI::active_languages();
		$settings = VCM_AI::settings();
		$current_language = VCM_AI::product_language( $post->ID );
		$targets = array_values( array_filter( array_map( 'sanitize_key', array_map( 'trim', explode( ',', $settings['default_targets'] ) ) ), function( $code ) use ( $current_language ) { return $code && $code !== $current_language; } ) );
		$languages = array_filter( $languages, function( $label, $code ) use ( $current_language ) { return $code !== $current_language; }, ARRAY_FILTER_USE_BOTH );
		?><div class="vcm-product-ai-box">
			<div class="vcm-quality-mini"><strong>Quality <?php echo esc_html( $quality['score'] ); ?>%</strong><span><?php echo esc_html( count( $quality['issues'] ) ); ?> issue(s)</span></div>
			<p class="description"><?php esc_html_e( 'AI changes are snapshot-protected and can be rolled back from the manager.', 'vcm' ); ?></p>
			<div class="vcm-meta-actions"><button type="button" class="button vcm-ai-rewrite" data-product-id="<?php echo esc_attr( $post->ID ); ?>">Rewrite description</button><button type="button" class="button vcm-ai-seo" data-product-id="<?php echo esc_attr( $post->ID ); ?>">Generate SEO</button><button type="button" class="button vcm-ai-clean" data-product-id="<?php echo esc_attr( $post->ID ); ?>">Clean content</button></div>
			<label class="vcm-field-label">Translate to</label>
			<select class="widefat vcm-ai-target">
				<?php foreach ( $languages as $code => $label ) : ?>
				<option value="<?php echo esc_attr( $code ); ?>"><?php echo esc_html( $label . ' (' . strtoupper( $code ) . ')' ); ?></option>
				<?php endforeach; ?>
			</select>
			<p><button type="button" class="button button-primary widefat vcm-ai-translate-current" data-product-id="<?php echo esc_attr( $post->ID ); ?>">Translate product</button></p>
		</div><?php
	}

	/* ---------------- Conflict manager ---------------- */
	public function ajax_start_scan() {
		$this->verify_request();
		$this->analyzer->set_scan_state(
			array(
				'status' => 'running', 'page' => 1, 'processed' => 0,
				'total' => $this->analyzer->count_variable_products(), 'started' => current_time( 'mysql' ),
			)
		);
		wp_send_json_success( array( 'state' => $this->analyzer->get_scan_state() ) );
	}

	public function ajax_scan_batch() {
		$this->verify_request();
		$page  = isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1;
		$batch = isset( $_POST['batch'] ) ? min( 20, max( 5, absint( $_POST['batch'] ) ) ) : 10;
		$query = new WP_Query(
			array(
				'post_type' => 'product', 'post_status' => array( 'publish', 'private', 'draft' ),
				'posts_per_page' => $batch, 'paged' => $page, 'fields' => 'ids', 'no_found_rows' => true, 'suppress_filters' => true,
				'tax_query' => array( array( 'taxonomy' => 'product_type', 'field' => 'slug', 'terms' => array( 'variable' ) ) ),
			)
		);
		$ids = $query->posts;
		$this->analyzer->index_products( $ids );
		$state = $this->analyzer->get_scan_state();
		$state['page'] = $page + 1;
		$state['processed'] = absint( $state['processed'] ) + count( $ids );
		$done = count( $ids ) < $batch;
		$state['status'] = $done ? 'complete' : 'running';
		if ( $done ) {
			$this->analyzer->prune_non_variable_indexed_products();
			$state['completed'] = current_time( 'mysql' );
		}
		$this->analyzer->set_scan_state( $state );
		wp_send_json_success( array( 'done' => $done, 'nextPage' => $done ? null : $page + 1, 'state' => $state, 'stats' => $this->analyzer->stats() ) );
	}

	public function ajax_toggle_attribute() {
		$this->verify_request();
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$attribute = isset( $_POST['attribute'] ) ? sanitize_key( wp_unslash( $_POST['attribute'] ) ) : '';
		if ( ! $product_id || ! $attribute ) {
			wp_send_json_error( array( 'message' => __( 'Invalid product or attribute.', 'vcm' ) ), 400 );
		}
		$data = $this->analyzer->get_product_data( $product_id );
		if ( ! $data || ! isset( $data['conflicts'][ $attribute ] ) ) {
			wp_send_json_error( array( 'message' => __( 'This attribute is not a current real WoodMart + WCBoost overlap.', 'vcm' ) ), 400 );
		}
		if ( isset( $_POST['quarantine'] ) && '1' === (string) $_POST['quarantine'] ) {
			if ( ! $this->analyzer->start_quarantine( $product_id, array( $attribute ) ) ) {
				wp_send_json_error( array( 'message' => __( 'Could not create the quarantine rule.', 'vcm' ) ), 400 );
			}
		} else {
			$this->analyzer->set_attribute_managed( $product_id, $attribute, false );
		}
		wp_send_json_success( array( 'product' => $this->analyzer->get_product_data( $product_id ) ) );
	}

	public function ajax_quarantine_all() {
		$this->verify_request();
		$offset = isset( $_POST['offset'] ) ? max( 0, absint( $_POST['offset'] ) ) : 0;
		$batch  = isset( $_POST['batch'] ) ? min( 20, max( 5, absint( $_POST['batch'] ) ) ) : 10;
		global $wpdb;
		$table = VCM_Plugin::table_name();
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT product_id FROM {$table} WHERE conflict = 1 ORDER BY product_id ASC LIMIT %d OFFSET %d", $batch, $offset ) );
		$changed = 0;
		foreach ( (array) $ids as $id ) {
			$id = absint( $id );
			if ( ! $id || 'approved' === $this->analyzer->get_stage_public( $id ) ) { continue; }
			$data = $this->analyzer->get_product_data( $id );
			if ( $data && ! empty( $data['conflicts'] ) && 'original' === $data['stage'] && $this->analyzer->start_quarantine( $id, array_keys( $data['conflicts'] ) ) ) {
				$changed++;
			}
		}
		$next = $offset + count( (array) $ids );
		$has_more = count( (array) $ids ) === $batch;
		wp_send_json_success( array( 'changed' => $changed, 'nextOffset' => $has_more ? $next : null, 'done' => ! $has_more, 'stats' => $this->analyzer->stats() ) );
	}

	public function ajax_bulk_manage() {
		$this->verify_request();
		$ids = isset( $_POST['ids'] ) && is_array( $_POST['ids'] ) ? array_values( array_unique( array_filter( array_map( 'absint', wp_unslash( $_POST['ids'] ) ) ) ) ) : array();
		$ids = array_slice( $ids, 0, 100 );
		$mode = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : 'quarantine';
		$changed = 0;
		foreach ( $ids as $id ) {
			if ( 'restore' === $mode ) {
				$changed += $this->analyzer->restore_original( $id ) ? 1 : 0;
			} else {
				$changed += $this->analyzer->set_product_conflicts_managed( $id, true ) ? 1 : 0;
			}
		}
		wp_send_json_success( array( 'changed' => $changed, 'stats' => $this->analyzer->stats() ) );
	}

	public function ajax_approve() {
		$this->verify_request();
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		if ( ! $product_id || ! $this->analyzer->approve_quarantine( $product_id ) ) {
			$message = VCM_Persistence::last_error() ? VCM_Persistence::last_error() : __( 'Final approval is blocked. Recheck the product and its quarantined baseline.', 'vcm' );
			wp_send_json_error( array( 'message' => $message ), 400 );
		}
		wp_send_json_success( array( 'product' => $this->analyzer->get_product_data( $product_id ) ) );
	}

	public function ajax_restore() {
		$this->verify_request();
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		if ( ! $product_id || ! $this->analyzer->restore_original( $product_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Restore could not be completed.', 'vcm' ) ), 400 );
		}
		wp_send_json_success( array( 'product' => $this->analyzer->get_product_data( $product_id ) ) );
	}

	public function ajax_recheck() {
		$this->verify_request();
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$data = $product_id ? $this->analyzer->get_product_data( $product_id, false ) : false;
		if ( ! $data ) {
			wp_send_json_error( array( 'message' => __( 'Product not found.', 'vcm' ) ), 400 );
		}
		$this->analyzer->sync_scan_row( $product_id, $data );
		wp_send_json_success( array( 'product' => $data ) );
	}

	/* ---------------- AI ---------------- */
	public function ajax_ai_translate() {
		$this->verify_request();
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$target = isset( $_POST['target_language'] ) ? sanitize_key( wp_unslash( $_POST['target_language'] ) ) : '';
		if ( ! $product_id || ! $target ) {
			wp_send_json_error( array( 'message' => __( 'Product and target language are required.', 'vcm' ) ), 400 );
		}
		$mode = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : 'smart';
		$result = VCM_AI::translate_product( $product_id, $target, array( 'mode' => in_array( $mode, array( 'smart', 'force' ), true ) ? $mode : 'smart' ) );
		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ?? VCM_AI::last_error() ), 400 );
		}
		$result['quality'] = VCM_AI::quality( $result['target_product_id'] );
		wp_send_json_success( array( 'result' => $result ) );
	}

	public function ajax_ai_translate_batch() {
		$this->verify_request();
		$source = isset( $_POST['source_language'] ) ? sanitize_key( wp_unslash( $_POST['source_language'] ) ) : 'de';
		$target = isset( $_POST['target_language'] ) ? sanitize_key( wp_unslash( $_POST['target_language'] ) ) : '';
		$search = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		$page   = isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1;
		$batch  = isset( $_POST['batch'] ) ? min( 3, max( 1, absint( $_POST['batch'] ) ) ) : 2;
		if ( ! $source || ! $target || $source === $target ) {
			wp_send_json_error( array( 'message' => __( 'Choose different source and target languages.', 'vcm' ) ), 400 );
		}
		$mode = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : 'smart';
		$mode = in_array( $mode, array( 'smart', 'force' ), true ) ? $mode : 'smart';
		// Smart bulk mode always consumes the first remaining candidates. This prevents offset skipping when processed products leave the needs list.
		$result = VCM_AI::translation_candidates( $source, $target, 1, $batch, $search, 'needs' );
		$processed = 0;
		$success = 0;
		$skipped = 0;
		$errors = array();
		foreach ( (array) $result['ids'] as $product_id ) {
			$processed++;
			$target_id = VCM_AI::translation_product_id( $product_id, $target );
			if ( ! $target_id || $target_id === absint( $product_id ) ) {
				$skipped++;
				continue;
			}
			$item = VCM_AI::translate_product( $product_id, $target, array( 'mode' => $mode ) );
			if ( ! empty( $item['success'] ) ) {
				$success++;
			} else {
				$errors[] = '#' . absint( $product_id ) . ': ' . ( $item['message'] ?? VCM_AI::last_error() );
			}
		}
		$next = ( $processed < $batch || empty( $result['ids'] ) ) ? 0 : 1;
		wp_send_json_success( array(
			'total' => absint( $result['total'] ),
			'processed' => $processed,
			'success' => $success,
			'skipped' => $skipped,
			'errors' => $errors,
			'page' => $page,
			'next_page' => $next,
			'done' => ! $next,
		) );
	}

	public function ajax_ai_preview() {
		$this->verify_request();
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$target = isset( $_POST['target_language'] ) ? sanitize_key( wp_unslash( $_POST['target_language'] ) ) : '';
		$result = VCM_AI::preview_translation( $product_id, $target );
		if ( empty( $result['success'] ) ) { wp_send_json_error( array( 'message' => $result['message'] ?? VCM_AI::last_error() ), 400 ); }
		wp_send_json_success( array( 'result' => $result ) );
	}

	public function ajax_ai_clean() {
		$this->verify_request();
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$result = VCM_AI::clean_product( $product_id );
		if ( empty( $result['success'] ) ) { wp_send_json_error( array( 'message' => $result['message'] ?? VCM_AI::last_error() ), 400 ); }
		wp_send_json_success( array( 'result' => $result ) );
	}

	public function ajax_ai_rewrite() {
		$this->verify_request();
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$result = VCM_AI::rewrite_description( $product_id );
		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ?? VCM_AI::last_error() ), 400 );
		}
		wp_send_json_success( array( 'result' => $result ) );
	}

	public function ajax_ai_seo() {
		$this->verify_request();
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$result = VCM_AI::generate_seo( $product_id );
		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ?? VCM_AI::last_error() ), 400 );
		}
		wp_send_json_success( array( 'result' => $result ) );
	}

	public function ajax_ai_test() {
		$this->verify_request();
		$result = VCM_AI::test_connection();
		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ?? VCM_AI::last_error() ), 400 );
		}
		wp_send_json_success( $result );
	}

	public function ajax_ai_rollback() {
		$this->verify_request();
		$snapshot = isset( $_POST['snapshot_id'] ) ? absint( $_POST['snapshot_id'] ) : 0;
		$result = VCM_AI::restore_snapshot( $snapshot );
		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ?? VCM_AI::last_error() ), 400 );
		}
		wp_send_json_success( $result );
	}



	private function missing_state_key() {
		return 'vcm_missing_scan_' . absint( get_current_user_id() );
	}

	private function missing_results_key( $source, $target ) {
		return 'vcm_missing_results_' . absint( get_current_user_id() ) . '_' . md5( $source . '|' . $target );
	}

	public function ajax_missing_scan_start() {
		$this->verify_request();
		$source = isset( $_POST['source_language'] ) ? sanitize_key( wp_unslash( $_POST['source_language'] ) ) : '';
		$target = isset( $_POST['target_language'] ) ? sanitize_key( wp_unslash( $_POST['target_language'] ) ) : '';
		if ( $source && $target && $source === $target ) {
			wp_send_json_error( array( 'message' => __( 'Source and target languages must be different.', 'vcm' ) ), 400 );
		}
		$key = $this->missing_state_key();
		$state = array( 'status' => 'running', 'source' => $source, 'target' => $target, 'page' => 1, 'processed' => 0, 'found' => 0, 'started' => current_time( 'mysql' ) );
		update_option( $key, $state, false );
		delete_transient( $this->missing_results_key( $source, $target ) );
		wp_send_json_success( array( 'state' => $state ) );
	}

	public function ajax_missing_scan_batch() {
		$this->verify_request();
		$key = $this->missing_state_key();
		$state = get_option( $key, array() );
		if ( empty( $state['status'] ) || 'running' !== $state['status'] ) {
			wp_send_json_error( array( 'message' => __( 'No missing-language scan is running.', 'vcm' ) ), 400 );
		}
		$page = isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : absint( $state['page'] ?: 1 );
		$batch = isset( $_POST['batch'] ) ? min( 30, max( 5, absint( $_POST['batch'] ) ) ) : 25;
		$result = VCM_AI::missing_language_batch( $state['source'], $state['target'], $page, $batch );
		$cache = get_transient( $this->missing_results_key( $state['source'], $state['target'] ) );
		$cache = is_array( $cache ) ? $cache : array();
		$existing = array();
		foreach ( $cache as $row ) { $existing[ absint( $row['canonical_id'] ?? $row['id'] ?? 0 ) ] = $row; }
		foreach ( (array) $result['rows'] as $row ) { $existing[ absint( $row['canonical_id'] ?? $row['id'] ?? 0 ) ] = $row; }
		$cache = array_values( $existing );
		$state['page'] = $result['done'] ? $page : ( $result['next_page'] ?: $page + 1 );
		$state['processed'] = absint( $state['processed'] ) + absint( $result['processed'] );
		$state['found'] = count( $cache );
		$state['total_source'] = absint( $result['total_source'] );
		$state['status'] = $result['done'] ? 'complete' : 'running';
		if ( $result['done'] ) {
			$state['completed'] = current_time( 'mysql' );
			set_transient( $this->missing_results_key( $state['source'], $state['target'] ), $cache, 12 * HOUR_IN_SECONDS );
		}
		update_option( $key, $state, false );
		wp_send_json_success( array( 'done' => $result['done'], 'nextPage' => $result['next_page'], 'state' => $state ) );
	}

	public function ajax_ai_catalog_scan() {
		$this->verify_request();
		$page = isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1;
		$batch = isset( $_POST['batch'] ) ? min( 25, max( 5, absint( $_POST['batch'] ) ) ) : 20;
		$target = isset( $_POST['target_language'] ) ? sanitize_key( wp_unslash( $_POST['target_language'] ) ) : '';
		$only_incomplete = ! empty( $_POST['only_incomplete'] );
		$result = VCM_AI::catalog_scan_batch( $page, $batch, $target, $only_incomplete );
		wp_send_json_success( $result );
	}

	/* ---------------- Page rendering ---------------- */
	public function render_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! VCM_Plugin::is_woocommerce_ready() ) { return; }
		?><div class="wrap vcm-wrap"><?php settings_errors( 'vcm_messages' ); $this->render_page_header( 'conflicts' ); $this->render_conflicts(); ?></div><?php
	}

	private function render_page_header( $active ) {
		$links = array(
			'conflicts' => array( 'Variation Conflicts', $this->page_slug ),
			'missing' => array( 'Missing Languages', 'vcm-variation-conflicts-missing' ),
			'translate' => array( 'AI Translation', 'vcm-variation-conflicts-translate' ),
			'health' => array( 'Catalog Health', 'vcm-variation-conflicts-health' ),
			'tools' => array( 'AI Tools & Logs', 'vcm-variation-conflicts-tools' ),
			'settings' => array( 'Settings', 'vcm-variation-conflicts-settings' ),
		);
		?><div class="vcm-hero vcm-hero-compact"><div><div class="vcm-kicker">WooCommerce workspace</div><h1>WCBoost Manager</h1><p>Variation safety, multilingual content and catalog health are separated into focused workspaces.</p></div><div class="vcm-hero-badge"><span class="dashicons dashicons-admin-generic"></span> <?php echo esc_html( $links[ $active ][0] ?? 'WCBoost Manager' ); ?></div></div>
		<div class="vcm-main-tabs"><?php foreach ( $links as $key => $link ) : $url = add_query_arg( array( 'page' => $link[1] ), admin_url( 'admin.php' ) ); ?><a class="vcm-main-tab <?php echo $key === $active ? 'is-active' : ''; ?>" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $link[0] ); ?></a><?php endforeach; ?></div><?php
	}

	public function render_missing_languages_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! VCM_Plugin::is_woocommerce_ready() ) { return; }
		?><div class="wrap vcm-wrap"><?php $this->render_page_header( 'missing' ); $this->render_missing_languages(); ?></div><?php
	}

	public function render_translation_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! VCM_Plugin::is_woocommerce_ready() ) { return; }
		?><div class="wrap vcm-wrap"><?php $this->render_page_header( 'translate' ); $this->render_translation_center(); ?></div><?php
	}

	public function render_health_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! VCM_Plugin::is_woocommerce_ready() ) { return; }
		?><div class="wrap vcm-wrap"><?php $this->render_page_header( 'health' ); $this->render_catalog_health(); ?></div><?php
	}

	public function render_tools_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! VCM_Plugin::is_woocommerce_ready() ) { return; }
		?><div class="wrap vcm-wrap"><?php $this->render_page_header( 'tools' ); $this->render_tools(); ?></div><?php
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! VCM_Plugin::is_woocommerce_ready() ) { return; }
		?><div class="wrap vcm-wrap"><?php $this->render_page_header( 'settings' ); $this->render_settings(); ?></div><?php
	}

	private function render_missing_languages() {
		$languages = VCM_AI::active_languages();
		$source = isset( $_GET['source'] ) ? sanitize_key( wp_unslash( $_GET['source'] ) ) : '';
		$target = isset( $_GET['target'] ) ? sanitize_key( wp_unslash( $_GET['target'] ) ) : '';
		if ( ! $source && isset( $languages['de'] ) ) { $source = 'de'; }
		$key = $this->missing_results_key( $source, $target );
		$rows = get_transient( $key );
		$rows = is_array( $rows ) ? $rows : array();
		$page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$per_page = 12;
		$items = array_slice( $rows, ( $page - 1 ) * $per_page, $per_page );
		$state = get_option( $this->missing_state_key(), array() );
		?><div class="vcm-section-card"><div class="vcm-section-head"><div><h2>Missing Languages</h2><p>Find translation groups where the selected target page does not exist. The scan is read-only and runs through AJAX.</p></div><div class="vcm-hero-actions"><button type="button" class="button button-primary" id="vcm-missing-rescan"><span class="dashicons dashicons-update"></span> Rescan languages</button><span id="vcm-missing-progress" class="vcm-ai-scan-progress"></span></div></div>
		<form class="vcm-ai-filter" method="get"><input type="hidden" name="page" value="vcm-variation-conflicts-missing"><label>Source language<select name="source"><option value="">Any source</option><?php foreach ( $languages as $code => $label ) : ?><option value="<?php echo esc_attr( $code ); ?>" <?php selected( $source, $code ); ?>><?php echo esc_html( $label . ' (' . strtoupper( $code ) . ')' ); ?></option><?php endforeach; ?></select></label><label>Target language<select name="target"><option value="">Find any missing target</option><?php foreach ( $languages as $code => $label ) : ?><option value="<?php echo esc_attr( $code ); ?>" <?php selected( $target, $code ); ?>><?php echo esc_html( $label . ' (' . strtoupper( $code ) . ')' ); ?></option><?php endforeach; ?></select></label><button class="button">Filter results</button></form>
		<div class="vcm-missing-summary"><strong><?php echo esc_html( count( $rows ) ); ?></strong><span>missing-language groups found in the last scan</span><?php if ( ! empty( $state['completed'] ) && $state['source'] === $source && $state['target'] === $target ) : ?><small>Completed <?php echo esc_html( $state['completed'] ); ?></small><?php endif; ?></div></div>
		<div class="vcm-product-grid" id="vcm-missing-results">
		<?php if ( empty( $items ) ) : ?><div class="vcm-section-card vcm-empty-state"><span class="dashicons dashicons-search"></span><strong>No cached scan results.</strong><span>Select the languages and click Rescan languages.</span></div><?php else : foreach ( $items as $row ) : $this->render_missing_card( $row, $target ); endforeach; endif; ?>
		</div>
		<?php $this->pagination_simple( count( $rows ), $page, $per_page, 'vcm-variation-conflicts-missing', array( 'source' => $source, 'target' => $target ) );
	}

	private function render_missing_card( $row, $target ) {
		$missing = (array) ( $row['missing_languages'] ?? array() );
		$present = (array) ( $row['languages_present'] ?? array() );
		$variation = VCM_AI::variation_summary( $row['id'] ?? 0 );
		$target_id = ( $target && ! empty( $row['id'] ) ) ? VCM_AI::translation_product_id( $row['id'], $target ) : 0;
		?><div class="vcm-product-card"><div class="vcm-product-card-media"><img src="<?php echo esc_url( $row['image'] ?? '' ); ?>" alt=""></div><div class="vcm-product-card-body"><div class="vcm-card-kicker"><?php echo esc_html( strtoupper( $row['language'] ?? '' ) ); ?> · #<?php echo esc_html( $row['id'] ?? '' ); ?></div><h3><?php echo esc_html( $row['title'] ?? 'Untitled product' ); ?></h3><div class="vcm-card-meta"><span>SKU: <?php echo esc_html( $row['sku'] ?: '—' ); ?></span><span>Type: <?php echo esc_html( $row['type'] ?: '—' ); ?></span><span>Price: <?php echo esc_html( $row['price'] ?: '—' ); ?></span><span><?php echo $variation['has_variations'] ? esc_html( $variation['count'] . ' variations · ' . $variation['with_image'] . '/' . $variation['count'] . ' images' ) : 'No variations'; ?></span></div><div class="vcm-card-line"><strong>Available:</strong><div><?php foreach ( $present as $code => $pid ) : ?><span class="vcm-lang-pill is-good"><?php echo esc_html( strtoupper( $code ) ); ?></span><?php endforeach; ?></div></div><div class="vcm-card-line"><strong>Missing:</strong><div><?php foreach ( $missing as $code => $label ) : ?><span class="vcm-lang-pill is-missing"><?php echo esc_html( strtoupper( $code ) ); ?></span><?php endforeach; ?></div></div><div class="vcm-card-actions"><a class="button button-primary" href="<?php echo esc_url( $row['edit_url'] ?? '#' ); ?>" target="_blank">Edit source</a><a class="button" href="<?php echo esc_url( $row['view_url'] ?? '#' ); ?>" target="_blank">View source</a><?php if ( $target_id ) : ?><a class="button" href="<?php echo esc_url( get_permalink( $target_id ) ); ?>" target="_blank">View target</a><?php endif; ?></div></div></div><?php
	}

	private function render_translation_center() {
		$settings = VCM_AI::settings();
		$languages = VCM_AI::active_languages();
		$source = isset( $_GET['source'] ) ? sanitize_key( wp_unslash( $_GET['source'] ) ) : ( isset( $languages['de'] ) ? 'de' : (string) array_key_first( $languages ) );
		$target = isset( $_GET['target'] ) ? sanitize_key( wp_unslash( $_GET['target'] ) ) : '';
		if ( ! $target ) { $default = array_filter( array_map( 'trim', explode( ',', $settings['default_targets'] ) ) ); $target = sanitize_key( $default[0] ?? '' ); }
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$mode = isset( $_GET['mode'] ) ? sanitize_key( wp_unslash( $_GET['mode'] ) ) : 'needs';
		$page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$result = ( $source && $target && $source !== $target ) ? VCM_AI::translation_candidates( $source, $target, $page, 12, $search, 'needs' === $mode ? 'needs' : 'all' ) : array( 'ids' => array(), 'total' => 0 );
		?><div class="vcm-section-card"><div class="vcm-section-head"><div><h2>AI Translation Center</h2><p>Only linked target pages are processed. The plugin checks each target field and replaces fields that are empty or still in the source language. Existing good target-language copy is left untouched in Smart mode.</p></div><div class="vcm-api-state"><span class="vcm-dot"></span><?php echo empty( $settings['api_key'] ) ? 'API key not configured' : 'Gemini ready'; ?></div></div>
		<form class="vcm-ai-filter" method="get"><input type="hidden" name="page" value="vcm-variation-conflicts-translate"><label>Source<select name="source"><?php foreach ( $languages as $code => $label ) : ?><option value="<?php echo esc_attr( $code ); ?>" <?php selected( $source, $code ); ?>><?php echo esc_html( $label . ' (' . strtoupper( $code ) . ')' ); ?></option><?php endforeach; ?></select></label><label>Target<select name="target"><?php foreach ( $languages as $code => $label ) : ?><option value="<?php echo esc_attr( $code ); ?>" <?php selected( $target, $code ); ?>><?php echo esc_html( $label . ' (' . strtoupper( $code ) . ')' ); ?></option><?php endforeach; ?></select></label><label>View<select name="mode"><option value="needs" <?php selected( $mode, 'needs' ); ?>>Needs translation / repair</option><option value="all" <?php selected( $mode, 'all' ); ?>>All linked target pages</option></select></label><label>Search<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Product title, SKU or text"></label><button class="button">Load</button><button type="button" class="button button-primary" id="vcm-ai-translate-all" data-source="<?php echo esc_attr( $source ); ?>" data-target="<?php echo esc_attr( $target ); ?>">Translate all needing attention</button><span id="vcm-ai-progress" class="vcm-ai-progress"></span></form></div>
		<div class="vcm-table-card"><div class="vcm-table-head"><div><h2><?php echo esc_html( 'German' === ( $languages[ $source ] ?? '' ) ? 'German → ' . ( $languages[ $target ] ?? strtoupper( $target ) ) : strtoupper( $source ) . ' → ' . strtoupper( $target ) ); ?></h2><p>Preview is read-only. Apply creates a snapshot first.</p></div><div class="vcm-page-info"><?php echo esc_html( $result['total'] . ' products need attention' ); ?></div></div><div class="vcm-translation-list">
		<?php if ( empty( $result['ids'] ) ) : ?><div class="vcm-empty-state"><span class="dashicons dashicons-yes"></span><strong>No linked target products need translation.</strong><span>Try “All linked target pages” or check Missing Languages.</span></div><?php else : foreach ( $result['ids'] as $id ) : $this->render_translation_card( $id, $target ); endforeach; endif; ?></div></div>
		<?php $this->pagination_simple( $result['total'], $page, 12, 'vcm-variation-conflicts-translate', array( 'source' => $source, 'target' => $target, 'mode' => $mode, 's' => $search ) );
	}

	private function render_translation_card( $id, $target ) {
		$product = wc_get_product( $id ); if ( ! $product ) { return; }
		$target_id = VCM_AI::translation_product_id( $id, $target );
		$status = VCM_AI::translation_status( $id, $target );
		$quality = VCM_AI::quality( $id );
		$variation = VCM_AI::variation_summary( $id );
		?><div class="vcm-translation-card"><div class="vcm-product-card-media"><img src="<?php echo esc_url( VCM_AI::image_url( $id ) ); ?>" alt=""></div><div class="vcm-translation-main"><div class="vcm-card-kicker"><?php echo esc_html( strtoupper( VCM_AI::product_language( $id ) ) ); ?> · #<?php echo esc_html( $id ); ?> · Target #<?php echo esc_html( $target_id ); ?></div><h3><?php echo esc_html( $product->get_name() ); ?></h3><div class="vcm-card-meta"><span>SKU: <?php echo esc_html( $product->get_sku() ?: '—' ); ?></span><span>Price: <?php echo esc_html( $product->get_price() !== '' ? $product->get_price() : '—' ); ?></span><span>Quality: <?php echo esc_html( $quality['score'] ); ?>%</span><span><?php echo $variation['has_variations'] ? esc_html( $variation['count'] . ' variations · ' . $variation['with_image'] . '/' . $variation['count'] . ' images' ) : 'No variations'; ?></span></div><div class="vcm-field-statuses"><?php foreach ( (array) ( $status['fields'] ?? array() ) as $field => $info ) : ?><span class="vcm-field-status <?php echo esc_attr( $info['status'] ); ?>"><strong><?php echo esc_html( $info['label'] ); ?></strong><small><?php echo esc_html( str_replace( '_', ' ', $info['status'] ) ); ?></small></span><?php endforeach; ?></div></div><div class="vcm-translation-actions"><button type="button" class="button vcm-ai-preview" data-product-id="<?php echo esc_attr( $id ); ?>" data-target-language="<?php echo esc_attr( $target ); ?>" <?php disabled( ! $target_id ); ?>>Preview</button><button type="button" class="button button-primary vcm-ai-translate" data-product-id="<?php echo esc_attr( $id ); ?>" data-target-language="<?php echo esc_attr( $target ); ?>" <?php disabled( ! $target_id ); ?>>Translate</button><a class="button" href="<?php echo esc_url( get_permalink( $id ) ); ?>" target="_blank">View source</a><?php if ( $target_id ) : ?><a class="button" href="<?php echo esc_url( get_permalink( $target_id ) ); ?>" target="_blank">View target</a><a class="button-link" href="<?php echo esc_url( get_edit_post_link( $target_id, '' ) ); ?>" target="_blank">Edit target</a><?php endif; ?></div></div><?php
	}

	private function render_catalog_health() {
		$languages = VCM_AI::active_languages();
		$language = isset( $_GET['language'] ) ? sanitize_key( wp_unslash( $_GET['language'] ) ) : '';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$result = VCM_AI::query_health_products( $language, $search, $page, 12 );
		?><div class="vcm-section-card"><div class="vcm-section-head"><div><h2>Catalog Health</h2><p>Read-only catalog audit: content completeness, variation health and separate WoodMart/WCBoost renderer status.</p></div><button type="button" class="button button-primary" id="vcm-health-refresh">Refresh audit</button></div><form class="vcm-ai-filter" method="get"><input type="hidden" name="page" value="vcm-variation-conflicts-health"><label>Language<select name="language"><option value="">All languages</option><?php foreach ( $languages as $code => $label ) : ?><option value="<?php echo esc_attr( $code ); ?>" <?php selected( $language, $code ); ?>><?php echo esc_html( $label . ' (' . strtoupper( $code ) . ')' ); ?></option><?php endforeach; ?></select></label><label>Search<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>"></label><button class="button">Filter</button></form></div><div class="vcm-health-list">
		<?php if ( empty( $result['ids'] ) ) : ?><div class="vcm-section-card vcm-empty-state"><span class="dashicons dashicons-yes"></span><strong>No products found.</strong></div><?php else : foreach ( $result['ids'] as $id ) : $this->render_health_card( $id ); endforeach; endif; ?></div><?php $this->pagination_simple( $result['total'], $page, 12, 'vcm-variation-conflicts-health', array( 'language' => $language, 's' => $search ) );
	}

	private function render_health_card( $id ) {
		$h = VCM_AI::health_report( $id, $this->analyzer ); if ( empty( $h ) ) { return; }
		?><div class="vcm-health-card"><div class="vcm-product-card-media"><img src="<?php echo esc_url( $h['image'] ); ?>" alt=""></div><div class="vcm-health-main"><div class="vcm-card-kicker"><?php echo esc_html( strtoupper( $h['language'] ?: '—' ) ); ?> · #<?php echo esc_html( $h['id'] ); ?></div><h3><?php echo esc_html( $h['title'] ); ?></h3><div class="vcm-card-meta"><span>SKU: <?php echo esc_html( $h['sku'] ?: '—' ); ?></span><span>Type: <?php echo esc_html( $h['type'] ); ?></span><span>Price: <?php echo esc_html( $h['price'] ?: '—' ); ?></span></div><div class="vcm-health-sections"><div><strong>Core content</strong><div class="vcm-health-chips"><?php foreach ( $h['content'] as $key => $ok ) : ?><span class="vcm-health-chip <?php echo $ok ? 'ok' : 'bad'; ?>"><?php echo esc_html( ucwords( str_replace( '_', ' ', $key ) ) ); ?></span><?php endforeach; ?></div></div><div><strong>Variations</strong><div class="vcm-health-metrics"><span><?php echo esc_html( $h['variations']['count'] ); ?> total</span><span><?php echo esc_html( $h['variations']['missing_price'] ); ?> price missing</span><span><?php echo esc_html( $h['variations']['missing_sku'] ); ?> SKU missing</span><span><?php echo esc_html( $h['variations']['missing_image'] ); ?> image missing</span><span><?php echo esc_html( $h['variations']['duplicates'] ); ?> duplicate combo</span></div></div><div><strong>Renderer / swatches</strong><div class="vcm-health-metrics"><span>WoodMart: <?php echo esc_html( $h['engines']['woodmart']['count'] ); ?></span><span>WCBoost: <?php echo esc_html( $h['engines']['wcboost']['count'] ); ?></span><span class="<?php echo empty( $h['engines']['conflicts'] ) ? '' : 'vcm-danger-text'; ?>">Overlap: <?php echo esc_html( count( $h['engines']['conflicts'] ) ); ?></span></div></div></div></div><div class="vcm-health-actions"><a class="button button-primary" href="<?php echo esc_url( $h['edit_url'] ); ?>" target="_blank">Edit product</a><a class="button" href="<?php echo esc_url( $h['view_url'] ); ?>" target="_blank">View</a></div></div><?php
	}

	private function pagination_simple( $total, $page, $per_page, $slug, $args = array() ) {
		$pages = max( 1, (int) ceil( $total / $per_page ) ); if ( $pages <= 1 ) { return; }
		$args = array_merge( array( 'page' => $slug, 'paged' => '%#%' ), $args );
		echo '<div class="tablenav"><div class="tablenav-pages">' . paginate_links( array( 'base' => add_query_arg( $args, admin_url( 'admin.php' ) ), 'format' => '', 'current' => $page, 'total' => $pages, 'prev_text' => '&lsaquo;', 'next_text' => '&rsaquo;' ) ) . '</div></div>';
	}

	private function main_tab( $tab, $label ) {
		$current = ( isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'conflicts' ) === $tab;
		$url = add_query_arg( array( 'page' => $this->page_slug, 'tab' => $tab ), admin_url( 'admin.php' ) );
		echo '<a class="vcm-main-tab ' . ( $current ? 'is-active' : '' ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
	}

	private function render_conflicts() {
		$stats = $this->analyzer->stats();
		$state = $this->analyzer->get_scan_state();
		$status = $this->analyzer->get_engine_status();
		$view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'conflicts';
		$page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$per_page = 20;
		$ids = $this->query_conflict_ids( $view, $page, $per_page );
		$rows = array();
		foreach ( $ids['ids'] as $id ) {
			$data = $this->analyzer->get_product_data( $id );
			if ( ! $data ) { continue; }
			if ( 'conflicts' === $view && empty( $data['conflicts'] ) ) { $this->analyzer->sync_scan_row( $id, $data ); continue; }
			$rows[] = $data;
		}
		?>
		<div class="vcm-conflict-topbar"><div><strong>Variation conflict safety</strong><span>Scan the real frontend renderer without changing variations.</span></div><div class="vcm-hero-actions"><button class="button button-primary" id="vcm-run-scan"><span class="dashicons dashicons-update"></span> Scan renderer conflicts</button><span class="vcm-scan-status" id="vcm-scan-status"><?php echo 'running' === ( $state['status'] ?? '' ) ? esc_html( 'Scanning…' ) : ( 'complete' === ( $state['status'] ?? '' ) ? esc_html( 'Scan complete' ) : esc_html( 'No scan yet' ) ); ?></span></div></div>
		<div class="vcm-engines"><?php $this->render_status_badge( $status['woocommerce']['active'], $status['woocommerce']['version'], 'WooCommerce' ); ?><?php $this->render_status_badge( $status['woodmart']['active'], $status['woodmart']['version'], 'WoodMart' ); ?><?php $this->render_status_badge( $status['wcboost']['active'], $status['wcboost']['version'], 'WCBoost' ); ?></div>
		<div class="vcm-cards vcm-cards-4"><?php $this->stat_card( 'Scanned', $stats['scanned'], 'conflicts', 'dashicons-search' ); ?><?php $this->stat_card( 'Real duplicates', $stats['conflicts'], 'conflicts', 'dashicons-warning' ); ?><?php $this->stat_card( 'Quarantine', $stats['quarantine'], 'quarantine', 'dashicons-shield' ); ?><?php $this->stat_card( 'Final approved', $stats['approved'], 'approved', 'dashicons-yes-alt' ); ?></div>
		<div class="vcm-safe-note"><div class="dashicons dashicons-shield-alt"></div><div><strong>Safety first</strong><span>Quarantine and final approval change only the manager's WoodMart-rendering boundary. WooCommerce variation records are not created, deleted or rewritten.</span></div></div>
		<div class="vcm-toolbar"><div class="vcm-tabs"><?php $this->conflict_tab( 'conflicts', 'Real duplicates', $stats['conflicts'] ); ?><?php $this->conflict_tab( 'quarantine', 'Quarantine', $stats['quarantine'] ); ?><?php $this->conflict_tab( 'approved', 'Final approved', $stats['approved'] ); ?><?php $this->conflict_tab( 'all', 'All scanned', $stats['scanned'] ); ?></div><div class="vcm-bulk-actions"><select id="vcm-bulk-mode"><option value="quarantine">Quarantine selected conflicts</option><option value="restore">Restore selected to original</option></select><button class="button" id="vcm-apply-bulk">Apply</button><button class="button button-primary" id="vcm-quarantine-all">Scan &amp; quarantine all</button></div></div>
		<div class="vcm-table-card"><div class="vcm-table-head"><div><h2>Variation conflict audit</h2><p>Only real same-attribute WoodMart + WCBoost renderer overlaps are listed.</p></div><div class="vcm-page-info"><?php echo esc_html( count( $rows ) . ' products on this page' ); ?></div></div>
		<table class="widefat fixed striped vcm-table"><thead><tr><th class="check-column"><input type="checkbox" id="vcm-check-all"></th><th>Product</th><th>Lang</th><th>SKU</th><th>Variations</th><th>Duplicate</th><th>State</th><th>Actions</th></tr></thead><tbody><?php if ( empty( $rows ) ) : ?><tr><td colspan="8" class="vcm-empty"><span class="dashicons dashicons-yes"></span><strong>Nothing to show.</strong><span>Run the renderer scan or change the view.</span></td></tr><?php else : foreach ( $rows as $row ) : $this->render_conflict_row( $row ); endforeach; endif; ?></tbody></table></div><?php $this->pagination( $ids['total'], $page, $per_page, $view ); ?>
		<?php
	}

	private function render_ai_center() {
		$settings = VCM_AI::settings();
		$source = isset( $_GET['source'] ) ? sanitize_key( wp_unslash( $_GET['source'] ) ) : '';
		$target = isset( $_GET['target'] ) ? sanitize_key( wp_unslash( $_GET['target'] ) ) : '';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$selected_products = isset( $_GET['selected_products'] ) ? array_values( array_filter( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_GET['selected_products'] ) ) ) ) ) ) : array();
		$page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$languages = VCM_AI::active_languages();
		if ( ! $source ) { $source = isset( $languages['de'] ) ? 'de' : array_key_first( $languages ); }
		if ( ! $target ) { $default_targets = array_filter( array_map( 'trim', explode( ',', $settings['default_targets'] ) ) ); $target = sanitize_key( $default_targets[0] ?? '' ); }
		$result = VCM_AI::query_products( $source, $search, $page, 20 );
		if ( ! empty( $selected_products ) ) {
			$selected_matches = array();
			foreach ( $selected_products as $selected_id ) {
				if ( $source !== VCM_AI::product_language( $selected_id ) ) {
					continue;
				}
				if ( $search ) {
					$fields = VCM_AI::product_fields( $selected_id );
					$haystack = strtolower( wp_strip_all_tags( implode( ' ', array( $fields['title'] ?? '', $fields['short_description'] ?? '', $fields['description'] ?? '' ) ) ) );
					if ( false === strpos( $haystack, strtolower( $search ) ) ) { continue; }
				}
				$selected_matches[] = absint( $selected_id );
			}
			$result = array( 'ids' => array_slice( $selected_matches, ( $page - 1 ) * 20, 20 ), 'total' => count( $selected_matches ) );
		}
		?>
		<div class="vcm-section-card vcm-catalog-scan-card"><div class="vcm-section-head"><div><h2>Multilingual Catalog Scanner</h2><p>Find incomplete translation groups, missing target languages and target pages with missing content. The scan is AJAX-based and does not change products.</p></div><div class="vcm-hero-actions"><button type="button" class="button button-primary" id="vcm-ai-rescan"><span class="dashicons dashicons-update"></span> Rescan catalog</button><span class="vcm-ai-scan-progress" id="vcm-ai-scan-progress"></span></div></div>
			<div class="vcm-scan-filter"><label>Check missing language<select id="vcm-ai-scan-target"><option value="">Any missing language</option><?php foreach ( $languages as $code => $label ) : ?><option value="<?php echo esc_attr( $code ); ?>"><?php echo esc_html( $label . ' (' . strtoupper( $code ) . ')' ); ?></option><?php endforeach; ?></select></label><label class="vcm-check-inline"><input type="checkbox" id="vcm-ai-scan-incomplete" checked> Only show products/groups with problems</label></div>
			<div id="vcm-ai-scan-results" class="vcm-scan-results"><div class="vcm-scan-empty"><span class="dashicons dashicons-search"></span><strong>Click Rescan catalog</strong><span>The results will appear here without reloading the page.</span></div></div>
		</div>
		<div class="vcm-section-card"><div class="vcm-section-head"><div><h2>AI Translation Center</h2><p>Generate original target-language product copy from the existing source product. The target product/page must already exist through your multilingual plugin.</p></div><div class="vcm-api-state"><span class="vcm-dot"></span><?php echo empty( $settings['api_key'] ) ? 'API key not configured' : 'Gemini ready'; ?></div></div>
			<form class="vcm-ai-filter" method="get"><input type="hidden" name="page" value="<?php echo esc_attr( $this->page_slug ); ?>"><input type="hidden" name="tab" value="ai"><label>Source<select name="source"><?php foreach ( $languages as $code => $label ) : ?><option value="<?php echo esc_attr( $code ); ?>" <?php selected( $source, $code ); ?>><?php echo esc_html( $label . ' (' . strtoupper( $code ) . ')' ); ?></option><?php endforeach; ?></select></label><label>Target<select name="target"><?php foreach ( $languages as $code => $label ) : ?><option value="<?php echo esc_attr( $code ); ?>" <?php selected( $target, $code ); ?>><?php echo esc_html( $label . ' (' . strtoupper( $code ) . ')' ); ?></option><?php endforeach; ?></select></label><label class="vcm-filter-search">Search<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Product title, description…"></label><button class="button button-primary">Find products</button></form>
			<div class="vcm-ai-toolbar"><div class="vcm-bulk-actions"><select id="vcm-ai-bulk-action"><option value="translate">Generate &amp; translate selected → <?php echo esc_html( strtoupper( $target ) ); ?></option><option value="rewrite">Rewrite selected descriptions</option><option value="clean">Clean selected content</option><option value="seo">Generate SEO for selected</option></select><button class="button" id="vcm-ai-bulk-run">Run selected</button><button type="button" class="button button-primary" id="vcm-ai-translate-all">Generate &amp; translate all found</button></div><span class="vcm-ai-progress" id="vcm-ai-progress"></span></div>
			<div class="vcm-table-card"><table class="widefat fixed striped vcm-table vcm-ai-table"><thead><tr><th class="check-column"><input type="checkbox" id="vcm-ai-check-all"></th><th>Product</th><th>Source</th><th>Target</th><th>Quality</th><th>Action</th></tr></thead><tbody>
			<?php if ( empty( $result['ids'] ) ) : ?><tr><td colspan="6" class="vcm-empty"><span class="dashicons dashicons-translation"></span><strong>No source-language products found.</strong><span>Choose a source language or search again.</span></td></tr><?php else : foreach ( $result['ids'] as $product_id ) : $this->render_ai_row( $product_id, $target ); endforeach; endif; ?>
			</tbody></table></div><?php $this->pagination_ai( $result['total'], $page, 20, $source, $target, $search ); ?>
		</div>
		<?php
	}

	private function render_ai_row( $product_id, $target ) {
		$product = wc_get_product( $product_id );
		if ( ! $product ) { return; }
		$source_language = VCM_AI::product_language( $product_id );
		$quality = VCM_AI::quality( $product_id );
		$target_id = VCM_AI::translation_product_id( $product_id, $target );
		$target_product = $target_id ? wc_get_product( $target_id ) : false;
		$can_translate = (bool) ( $target_product && $target_id !== $product_id && $source_language !== $target );
		$status = $can_translate ? VCM_AI::translation_status( $product_id, $target ) : array( 'status' => 'missing_target', 'label' => 'No linked target' );
		?>
		<tr>
			<td class="check-column"><input type="checkbox" class="vcm-ai-row-check" value="<?php echo esc_attr( $product_id ); ?>" <?php checked( isset( $_GET['selected_products'] ) && in_array( absint( $product_id ), array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_GET['selected_products'] ) ) ) ), true ) ); ?>></td>
			<td class="vcm-product-cell"><img src="<?php echo esc_url( VCM_AI::image_url( $product_id ) ); ?>" alt=""><div><strong><?php echo esc_html( $product->get_name() ); ?></strong><span>#<?php echo esc_html( $product_id ); ?></span></div></td>
			<td><span class="vcm-lang-pill"><?php echo esc_html( strtoupper( $source_language ) ); ?></span></td>
			<td><?php echo $can_translate ? '<span class="vcm-target-ok">#' . esc_html( $target_id ) . ' · ' . esc_html( strtoupper( $target ) ) . '</span><span class="vcm-translation-status ' . esc_attr( $status['status'] ) . '">' . esc_html( $status['label'] ) . '</span>' : '<span class="vcm-target-missing">No linked target</span>'; ?></td>
			<td><span class="vcm-quality-score q-<?php echo esc_attr( floor( $quality['score'] / 10 ) ); ?>"><?php echo esc_html( $quality['score'] ); ?>%</span></td>
			<td class="vcm-actions"><button type="button" class="button button-primary vcm-ai-translate" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-target-language="<?php echo esc_attr( $target ); ?>" <?php disabled( ! $can_translate ); ?>>Generate &amp; Translate</button> <button type="button" class="button vcm-ai-preview" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-target-language="<?php echo esc_attr( $target ); ?>" <?php disabled( ! $can_translate ); ?>>Preview</button> <button type="button" class="button vcm-ai-clean" data-product-id="<?php echo esc_attr( $product_id ); ?>">Clean</button> <button type="button" class="button vcm-ai-rewrite" data-product-id="<?php echo esc_attr( $product_id ); ?>">Rewrite</button> <button type="button" class="button vcm-ai-seo" data-product-id="<?php echo esc_attr( $product_id ); ?>">SEO</button></td>
		</tr><?php
	}

	private function render_tools() {
		$snapshots = VCM_AI::snapshots( 40 );
		$logs = VCM_AI::logs( 40 );
		$duplicates = VCM_AI::duplicate_groups( 300 );
		?>
		<div class="vcm-tool-grid"><div class="vcm-section-card"><div class="vcm-section-head"><div><h2>Product Quality</h2><p>Simple deterministic checks for content completeness. No AI call is used for the score.</p></div></div><div class="vcm-quality-list"><div>Title length</div><div>Short description</div><div>Full description</div><div>SKU</div><div>Main image</div><div>Category</div><div>SEO title</div><div>SEO description</div></div></div>
		<div class="vcm-section-card"><div class="vcm-section-head"><div><h2>Duplicate Description Detector</h2><p>Exact duplicate full descriptions found across the sampled product catalog.</p></div></div><div class="vcm-duplicate-groups"><?php if ( empty( $duplicates ) ) : ?><div class="vcm-detail-empty">No exact duplicate description groups found in the current sample.</div><?php else : foreach ( $duplicates as $group ) : ?><div class="vcm-duplicate-group"><strong><?php echo esc_html( count( $group ) ); ?> products</strong><div><?php foreach ( $group as $item ) : ?><a href="<?php echo esc_url( admin_url( 'post.php?post=' . absint( $item['id'] ) . '&action=edit' ) ); ?>" target="_blank"><?php echo esc_html( $item['title'] ? $item['title'] : '#' . $item['id'] ); ?></a><?php endforeach; ?></div></div><?php endforeach; endif; ?></div></div>
		<div class="vcm-section-card"><div class="vcm-section-head"><div><h2>Snapshots &amp; Rollback</h2><p>Every AI write creates a snapshot of the target content before changes.</p></div></div><div class="vcm-log-table-wrap"><table class="widefat fixed striped"><thead><tr><th>ID</th><th>Action</th><th>Target</th><th>Language</th><th>Created</th><th>Status</th><th></th></tr></thead><tbody><?php if ( empty( $snapshots ) ) : ?><tr><td colspan="7">No snapshots yet.</td></tr><?php else : foreach ( $snapshots as $row ) : ?><tr><td>#<?php echo esc_html( $row['id'] ); ?></td><td><?php echo esc_html( ucfirst( $row['action'] ) ); ?></td><td>#<?php echo esc_html( $row['target_product_id'] ); ?></td><td><?php echo esc_html( strtoupper( $row['target_language'] ) ); ?></td><td><?php echo esc_html( $row['created_at'] ); ?></td><td><?php echo esc_html( $row['status'] ); ?></td><td><?php if ( 'restored' !== $row['status'] ) : ?><button type="button" class="button vcm-ai-rollback" data-snapshot-id="<?php echo esc_attr( $row['id'] ); ?>">Rollback</button><?php endif; ?></td></tr><?php endforeach; endif; ?></tbody></table></div></div></div>
		<div class="vcm-section-card"><div class="vcm-section-head"><div><h2>AI Activity Log</h2><p>Translation, rewriting, SEO, rollback and API errors are recorded here.</p></div></div><div class="vcm-log-table-wrap"><table class="widefat fixed striped"><thead><tr><th>Date</th><th>Action</th><th>Product</th><th>Target</th><th>Status</th><th>Message</th></tr></thead><tbody><?php if ( empty( $logs ) ) : ?><tr><td colspan="6">No AI activity yet.</td></tr><?php else : foreach ( $logs as $row ) : ?><tr><td><?php echo esc_html( $row['created_at'] ); ?></td><td><?php echo esc_html( ucfirst( $row['action'] ) ); ?></td><td>#<?php echo esc_html( $row['product_id'] ); ?> → #<?php echo esc_html( $row['target_product_id'] ); ?></td><td><?php echo esc_html( strtoupper( $row['target_language'] ) ); ?></td><td><span class="vcm-log-status <?php echo esc_attr( $row['status'] ); ?>"><?php echo esc_html( $row['status'] ); ?></span></td><td><?php echo esc_html( $row['message'] ); ?></td></tr><?php endforeach; endif; ?></tbody></table></div></div>
		<?php
	}

	private function render_settings() {
		$settings = VCM_AI::settings();
		$mode = $settings['usage_mode'];
		?><div class="vcm-section-card"><div class="vcm-section-head"><div><h2>AI Provider &amp; Gemini Settings</h2><p>For a normal Gemini API key created in Google AI Studio, choose <strong>Google AI Studio Gemini API</strong> and <strong>Free project only</strong>. Auto mode also starts with AI Studio Free, then Paid, and uses Cloud only as an optional fallback.</p></div><button type="button" class="button" id="vcm-ai-test">Test all AI connections</button></div>
		<form method="post"><input type="hidden" name="vcm_save_settings" value="1"><?php wp_nonce_field( 'vcm_save_settings' ); ?>
		<div class="vcm-settings-grid">
		<label>AI backend<select name="provider_mode"><option value="auto" <?php selected( $settings['provider_mode'], 'auto' ); ?>>Auto — AI Studio Free → Paid → Cloud fallback</option><option value="vertex_express" <?php selected( $settings['provider_mode'], 'vertex_express' ); ?>>Google Cloud Vertex AI Express</option><option value="ai_studio" <?php selected( $settings['provider_mode'], 'ai_studio' ); ?>>Google AI Studio Gemini API</option></select><span class="description">Auto starts with the normal Google AI Studio API key (Free first, then Paid). Vertex Express is optional and is used only as a fallback when configured.</span></label>
		<label>Gemini API version<select name="api_version_mode"><option value="auto" <?php selected( $settings['api_version_mode'] ?? 'auto', 'auto' ); ?>>Auto — v1 stable → v1beta fallback</option><option value="v1" <?php selected( $settings['api_version_mode'] ?? 'auto', 'v1' ); ?>>v1 stable only</option><option value="v1beta" <?php selected( $settings['api_version_mode'] ?? 'auto', 'v1beta' ); ?>>v1beta only</option></select><span class="description">The plugin tries the stable API first and falls back to v1beta only when needed.</span></label>
		<label>API key transport<select name="auth_mode"><option value="auto" <?php selected( $settings['auth_mode'] ?? 'auto', 'auto' ); ?>>Auto — standard header → query fallback</option><option value="header" <?php selected( $settings['auth_mode'] ?? 'auto', 'header' ); ?>>x-goog-api-key header</option><option value="query" <?php selected( $settings['auth_mode'] ?? 'auto', 'query' ); ?>>URL key query</option></select><span class="description">Both are official Gemini API authentication styles. Auto is recommended.</span></label>
		<label>AI usage mode<select name="usage_mode"><option value="auto" <?php selected( $mode, 'auto' ); ?>>Auto — Free first, Paid fallback</option><option value="free" <?php selected( $mode, 'free' ); ?>>Free project only</option><option value="paid" <?php selected( $mode, 'paid' ); ?>>Paid project only</option></select><span class="description">Recommended: Auto. If the Free key hits quota or access errors, the plugin can fall back to the Paid key when you have provided one.</span></label>
		<label>Free-tier project API Key<input type="password" name="free_api_key" value="<?php echo esc_attr( $settings['free_api_key'] ); ?>" autocomplete="off"><span class="description">Key created in a Google AI Studio project that uses the Free Tier.</span></label>
		<label>Paid-tier project API Key <span style="font-weight:400">(optional)</span><input type="password" name="paid_api_key" value="<?php echo esc_attr( $settings['paid_api_key'] ); ?>" autocomplete="off"><span class="description">Key created in a project with billing enabled. Auto mode uses this only when the Free project cannot complete the request.</span></label>
		<label>Vertex AI Express API Key <span style="font-weight:400">(optional)</span><input type="password" name="vertex_api_key" value="<?php echo esc_attr( $settings['vertex_api_key'] ); ?>" autocomplete="off"><span class="description">Optional fallback only. Create this from Google Cloud Express Mode, not the AI Studio API Keys page.</span></label>
		<label>Vertex Express primary model<select name="vertex_model"><option value="gemini-3.5-flash" <?php selected( $settings['vertex_model'], 'gemini-3.5-flash' ); ?>>Gemini 3.5 Flash</option><option value="gemini-3.1-flash-lite" <?php selected( $settings['vertex_model'], 'gemini-3.1-flash-lite' ); ?>>Gemini 3.1 Flash-Lite</option><option value="gemini-3.8-flash" <?php selected( $settings['vertex_model'], 'gemini-3.8-flash' ); ?>>Gemini 3.8 Flash</option></select></label>
		<label>Vertex Express fallback model<select name="vertex_fallback_model"><option value="gemini-3.1-flash-lite" <?php selected( $settings['vertex_fallback_model'], 'gemini-3.1-flash-lite' ); ?>>Gemini 3.1 Flash-Lite</option><option value="gemini-3.5-flash" <?php selected( $settings['vertex_fallback_model'], 'gemini-3.5-flash' ); ?>>Gemini 3.5 Flash</option><option value="gemini-3.8-flash" <?php selected( $settings['vertex_fallback_model'], 'gemini-3.8-flash' ); ?>>Gemini 3.8 Flash</option></select></label>
		<label>Primary Gemini model<select name="model"><option value="gemini-3.1-flash-lite" <?php selected( $settings['model'], 'gemini-3.1-flash-lite' ); ?>>Gemini 3.1 Flash-Lite</option><option value="gemini-3.5-flash-lite" <?php selected( $settings['model'], 'gemini-3.5-flash-lite' ); ?>>Gemini 3.5 Flash-Lite</option><option value="gemini-3.5-flash" <?php selected( $settings['model'], 'gemini-3.5-flash' ); ?>>Gemini 3.5 Flash</option><option value="gemini-3.8-flash" <?php selected( $settings['model'], 'gemini-3.8-flash' ); ?>>Gemini 3.8 Flash</option></select><span class="description">The API key's project determines whether usage is billed as Free or Paid. This setting chooses the model only.</span></label>
		<label>Fallback model<select name="fallback_model"><option value="gemini-3.1-flash-lite" <?php selected( $settings['fallback_model'], 'gemini-3.1-flash-lite' ); ?>>Gemini 3.1 Flash-Lite</option><option value="gemini-3.5-flash-lite" <?php selected( $settings['fallback_model'], 'gemini-3.5-flash-lite' ); ?>>Gemini 3.5 Flash-Lite</option><option value="gemini-3.5-flash" <?php selected( $settings['fallback_model'], 'gemini-3.5-flash' ); ?>>Gemini 3.5 Flash</option></select></label>
		<label>Translation style<input type="text" name="tone" value="<?php echo esc_attr( $settings['tone'] ); ?>"><span class="description">Examples: Natural, Professional, Luxury, Technical.</span></label>
		<label>Default target languages<input type="text" name="default_targets" value="<?php echo esc_attr( $settings['default_targets'] ); ?>"><span class="description">Comma separated codes, e.g. en,fr,it</span></label>
		</div><label class="vcm-check"><input type="checkbox" name="preserve_html" value="1" <?php checked( ! empty( $settings['preserve_html'] ) ); ?>> Preserve product HTML structure</label>
		<div class="vcm-ai-tier-note"><strong>Important:</strong> A Gemini API key cannot turn billing on or remove a Google access restriction. If AI Studio returns <code>403 Project denied</code>, the plugin stops retrying models because Google is denying generation at the project/account level. Auto can then move to another configured credential/provider. Google Cloud Express is optional. It is not required for a normal Google AI Studio API key.</div>
		<h3>Glossary</h3><p class="description">One rule per line: <code>source|target|original term|preferred translation</code>. Example: <code>de|en|Edelstahl|stainless steel</code></p><textarea name="glossary" rows="10" class="large-text code"><?php echo esc_textarea( VCM_AI::glossary_text() ); ?></textarea><p><button class="button button-primary">Save settings</button></p></form></div>
		<div class="vcm-section-card"><div class="vcm-section-head"><div><h2>How Auto mode works</h2><p>Auto never tries to turn a Free project into a Paid project. It uses the keys you provide.</p></div></div><div class="vcm-setup-grid"><div><strong>1. AI Studio Free</strong><span>Auto starts here with the normal key you create in Google AI Studio.</span></div><div><strong>2. AI Studio Paid</strong><span>If a Paid key is supplied and Free cannot complete the request, Auto can fall back to it.</span></div><div><strong>3. Cloud fallback</strong><span>Vertex/Cloud is optional and is tried only when configured and earlier Google AI Studio credentials fail.</span></div><div><strong>3. Smart model handling</strong><span>Do not rotate through models after a project-level 403; move to the next provider/key instead.</span></div></div></div><?php
	}

	private function query_conflict_ids( $view, $page, $per_page ) {
		global $wpdb;
		$table = VCM_Plugin::table_name();
		$offset = ( $page - 1 ) * $per_page;
		$where = '1=1';
		if ( 'conflicts' === $view ) { $where .= ' AND i.conflict=1'; }
		elseif ( 'quarantine' === $view ) { $where .= " AND i.stage='quarantine'"; }
		elseif ( 'approved' === $view ) { $where .= " AND i.stage='approved'"; }
		$total = absint( $wpdb->get_var( "SELECT COUNT(*) FROM {$table} i WHERE {$where}" ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_col( $wpdb->prepare( "SELECT i.product_id FROM {$table} i WHERE {$where} ORDER BY i.conflict DESC, i.product_id DESC LIMIT %d OFFSET %d", $per_page, $offset ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return array( 'ids' => array_map( 'absint', $rows ), 'total' => $total );
	}

	private function render_conflict_row( $row ) {
		$conflicts = $row['conflicts'];
		$stage = $row['stage'];
		?><tr class="vcm-product-row"><td class="check-column"><input type="checkbox" class="vcm-row-check" value="<?php echo esc_attr( $row['id'] ); ?>"></td><td class="vcm-product-cell"><img src="<?php echo esc_url( $row['thumbnail'] ); ?>" alt=""><div><strong><?php echo esc_html( $row['title'] ); ?></strong><span>#<?php echo esc_html( $row['id'] ); ?></span></div></td><td><span class="vcm-lang-pill"><?php echo $row['language'] ? esc_html( $row['language'] ) : '—'; ?></span></td><td><?php echo $row['sku'] ? esc_html( $row['sku'] ) : '<span class="vcm-muted">—</span>'; ?></td><td><span class="vcm-count-pill"><?php echo esc_html( $row['variation_count'] ); ?></span></td><td><?php echo ! empty( $conflicts ) ? '<span class="vcm-state is-conflict"><span class="dashicons dashicons-warning"></span>YES</span>' : '<span class="vcm-state"><span class="dashicons dashicons-no"></span>NO</span>'; ?></td><td><?php echo $this->stage_badge( $stage, $row['baseline_matches'] ); ?></td><td class="vcm-actions"><button type="button" class="button-link vcm-toggle-details" aria-expanded="false">Details</button> <a href="<?php echo esc_url( $row['edit_url'] ); ?>" target="_blank" rel="noopener noreferrer">Edit</a> <a href="<?php echo esc_url( $row['permalink'] ); ?>" target="_blank" rel="noopener noreferrer">View</a></td></tr>
		<tr class="vcm-details-row" style="display:none"><td colspan="8"><div class="vcm-details"><div class="vcm-detail-head"><div><strong>Real renderer audit</strong><span class="vcm-detail-sub"><?php echo esc_html( count( $conflicts ) . ' duplicated attribute(s)' ); ?></span></div><div class="vcm-product-actions"><?php if ( 'quarantine' === $stage ) : ?><button class="button button-primary vcm-approve" data-product-id="<?php echo esc_attr( $row['id'] ); ?>">Confirm final</button><?php elseif ( 'approved' !== $stage && ! empty( $conflicts ) ) : ?><button class="button button-primary vcm-quarantine" data-product-id="<?php echo esc_attr( $row['id'] ); ?>" data-attribute="<?php echo esc_attr( array_key_first( $conflicts ) ); ?>">Quarantine</button><?php endif; ?><?php if ( 'quarantine' === $stage || 'approved' === $stage ) : ?><button class="button vcm-restore" data-product-id="<?php echo esc_attr( $row['id'] ); ?>">Restore original</button><?php endif; ?></div></div>
		<?php if ( empty( $conflicts ) ) : ?><div class="vcm-detail-empty">No current same-attribute WoodMart + WCBoost overlap was found.</div><?php else : ?><div class="vcm-conflict-grid"><?php foreach ( $conflicts as $key => $conflict ) : ?><div class="vcm-conflict-item"><div class="vcm-conflict-title"><div><strong><?php echo esc_html( $conflict['label'] ); ?></strong><code><?php echo esc_html( $key ); ?></code></div><span class="vcm-state is-conflict">Duplicate</span></div><div class="vcm-engine-line"><span class="engine-badge wd">WoodMart</span><span>Renderer condition satisfied</span></div><div class="vcm-engine-line"><span class="engine-badge boost">WCBoost</span><span>Renderer condition satisfied</span></div><?php if ( ! empty( $conflict['woodmart']['term_names'] ) ) : ?><div class="vcm-term-list"><?php echo esc_html( implode( ', ', $conflict['woodmart']['term_names'] ) ); ?></div><?php endif; ?><div class="vcm-quarantine-actions"><?php if ( 'approved' !== $stage ) : ?><button class="button vcm-quarantine" data-product-id="<?php echo esc_attr( $row['id'] ); ?>" data-attribute="<?php echo esc_attr( $key ); ?>">Quarantine this attribute</button><?php endif; ?><button class="button-link vcm-recheck" data-product-id="<?php echo esc_attr( $row['id'] ); ?>">Recheck</button></div></div><?php endforeach; ?></div><?php endif; ?><div class="vcm-detail-foot">Stage: <strong><?php echo esc_html( ucfirst( $stage ) ); ?></strong>. <?php echo $row['baseline_matches'] ? 'Baseline unchanged.' : '<strong class="vcm-danger-text">Baseline changed.</strong>'; ?></div></div></td></tr><?php
	}

	private function stage_badge( $stage, $baseline_ok ) {
		if ( 'approved' === $stage ) { return '<span class="vcm-state is-managed"><span class="dashicons dashicons-yes-alt"></span>Final approved</span>'; }
		if ( 'quarantine' === $stage ) { return '<span class="vcm-state is-quarantine"><span class="dashicons dashicons-shield"></span>Quarantine' . ( $baseline_ok ? '' : ' · changed' ) . '</span>'; }
		return '<span class="vcm-state"><span class="dashicons dashicons-undo"></span>Original</span>';
	}

	private function conflict_tab( $view, $label, $count ) {
		$current = ( isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'conflicts' ) === $view;
		$url = add_query_arg( array( 'page' => $this->page_slug, 'tab' => 'conflicts', 'view' => $view ), admin_url( 'admin.php' ) );
		echo '<a class="vcm-tab ' . ( $current ? 'is-active' : '' ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . ' <span>' . esc_html( $count ) . '</span></a>';
	}

	private function render_status_badge( $active, $version, $label ) {
		$class = $active ? 'is-ok' : 'is-missing';
		$text = $active ? 'Detected' : 'Not detected';
		echo '<span class="vcm-engine ' . esc_attr( $class ) . '"><span class="vcm-dot"></span><strong>' . esc_html( $label ) . '</strong><span>' . esc_html( $text ) . ( $version ? ' · ' . esc_html( $version ) : '' ) . '</span></span>';
	}

	private function stat_card( $label, $value, $view, $icon ) {
		$url = add_query_arg( array( 'page' => $this->page_slug, 'tab' => 'conflicts', 'view' => $view ), admin_url( 'admin.php' ) );
		echo '<a class="vcm-card" href="' . esc_url( $url ) . '"><span class="vcm-card-icon dashicons ' . esc_attr( $icon ) . '"></span><span class="vcm-card-value">' . esc_html( $value ) . '</span><span class="vcm-card-label">' . esc_html( $label ) . '</span></a>';
	}

	private function pagination( $total, $page, $per_page, $view ) {
		$pages = max( 1, (int) ceil( $total / $per_page ) );
		if ( $pages <= 1 ) { return; }
		echo '<div class="tablenav"><div class="tablenav-pages">';
		echo paginate_links( array( 'base' => add_query_arg( array( 'page' => $this->page_slug, 'tab' => 'conflicts', 'view' => $view, 'paged' => '%#%' ), admin_url( 'admin.php' ) ), 'format' => '', 'current' => $page, 'total' => $pages, 'prev_text' => '&lsaquo;', 'next_text' => '&rsaquo;' ) );
		echo '</div></div>';
	}

	private function pagination_ai( $total, $page, $per_page, $source, $target, $search ) {
		$pages = max( 1, (int) ceil( $total / $per_page ) );
		if ( $pages <= 1 ) { return; }
		echo '<div class="tablenav"><div class="tablenav-pages">';
		echo paginate_links( array( 'base' => add_query_arg( array( 'page' => $this->page_slug, 'tab' => 'ai', 'source' => $source, 'target' => $target, 's' => $search, 'paged' => '%#%' ), admin_url( 'admin.php' ) ), 'format' => '', 'current' => $page, 'total' => $pages, 'prev_text' => '&lsaquo;', 'next_text' => '&rsaquo;' ) );
		echo '</div></div>';
	}
}
