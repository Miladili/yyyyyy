<?php
/*
 * Plugin Name: WCBoost Variation Manager & AI Product Content
 * Plugin URI: https://example.com/
 * Description: Audits real WoodMart + WCBoost variation-swatch conflicts and provides a focused Gemini-powered product translation, rewriting, SEO and rollback workspace.
 * Version: 6.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: OpenAI
 * Text Domain: vcm
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VCM_VERSION', '6.1.0' );
define( 'VCM_FILE', __FILE__ );
define( 'VCM_DIR', plugin_dir_path( __FILE__ ) );
define( 'VCM_URL', plugin_dir_url( __FILE__ ) );
define( 'VCM_DB_VERSION', '5.7.0' );

require_once VCM_DIR . 'includes/class-vcm-ai.php';
require_once VCM_DIR . 'includes/class-vcm-analyzer.php';
require_once VCM_DIR . 'includes/class-vcm-frontend.php';
require_once VCM_DIR . 'includes/class-vcm-persistence.php';
require_once VCM_DIR . 'includes/class-vcm-admin.php';
require_once VCM_DIR . 'includes/class-vcm-plugin.php';

register_activation_hook( VCM_FILE, array( 'VCM_Plugin', 'activate' ) );
register_deactivation_hook( VCM_FILE, array( 'VCM_Plugin', 'deactivate' ) );

VCM_Plugin::instance();
