=== WCBoost Manager & AI Product Content ===

Version 5.5.0

Purpose
-------
A focused WooCommerce admin workspace with four separate areas:

1. Variation Conflicts
   Detect real same-attribute WoodMart + WCBoost frontend swatch conflicts. The existing conflict logic is kept intact; this module does not rewrite WooCommerce variation records.

2. Missing Languages
   Scan translation groups through AJAX and find products/groups where a selected target language page does not exist. Source and target can be selected from the languages currently connected to Polylang or WPML. Results are cached after the scan and shown as paginated product cards with image and key details.

3. AI Translation Center
   Work only on target-language product pages that already exist. Each target field is inspected individually. Smart mode replaces only fields that are empty, still equal to the source, or still detected in the source language. Preview is read-only. Apply creates a rollback snapshot first.

4. Catalog Health
   Paginated read-only product audit showing core content completeness, variation health, duplicate variation combinations, missing variation price/SKU/image and separate WoodMart vs WCBoost renderer/swatch status plus detected overlaps.

What is intentionally NOT included
-----------------------------------
- No WoodMart -> WCBoost migration engine.
- No migration undo/repair flow.
- No translation-source image bridge.
- No CSV importer/exporter or CSV mapping.
- No independent Product Options/Variation replacement system.
- No image optimization/WebP/resizing tools.

AI Translation
--------------
Supported generated fields:
- Product title
- Short description
- Full description
- URL slug
- SEO title
- SEO description
- Focus keywords

Translation rules are designed to:
- preserve useful HTML and placeholders;
- preserve brand names, SKUs, measurements and technical values;
- rebuild the target-language copy as native e-commerce content rather than literal word-for-word translation;
- avoid copying the reference/source wording and structure;
- use commercially relevant SEO language without keyword stuffing;
- respect the site's glossary;
- reuse exact source+target+glossary matches from Translation Memory before another API request;
- detect target fields that are still blank, source-identical or written in the source language.

Bulk translation
----------------
The Translation Center processes only the remaining products that still need translation. Smart bulk mode always consumes the first remaining candidates, preventing page-offset skipping as translated products leave the queue.

Safety
------
Every AI write creates a snapshot of the target product's relevant content before changes. Snapshots can be restored from AI Tools & Logs.
Preview never writes product content.

Gemini
------
The plugin stores the Gemini API key in the WordPress site's own option and never ships a shared key.
The plugin supports Gemini API (AI Studio) and Google Cloud Vertex AI Express. Auto mode can try Vertex Express first, then AI Studio Free/Paid keys. The plugin queries the models available to the site's key and tries compatible candidates when the configured model is unavailable.
The integration uses Google's Generate Content API with structured JSON responses and the site's own API key.

Multilingual compatibility
--------------------------
- Polylang: linked product IDs and active language codes are used for source/target scanning and translation.
- WPML: linked product IDs and language codes are used for source/target scanning and translation.
- The plugin does not create missing target-language pages. Your multilingual plugin remains responsible for creating/connecting those pages.

Recommended workflow
--------------------
1. Import the German source catalog with WP All Import.
2. Create/connect target-language product pages with Polylang or WPML.
3. Open Missing Languages and run a Rescan.
4. Open AI Translation Center, choose source and target, preview, then bulk-translate the remaining target fields.
5. Use Catalog Health to review product completeness, variation data and WoodMart/WCBoost renderer state.
6. Keep Variation Conflicts as a separate safety workflow.

Installation
------------
1. Install the plugin ZIP in WordPress.
2. Activate WooCommerce and, for multilingual workflows, Polylang or WPML.
3. Open WCBoost Manager -> Settings and enter the site's Gemini API key.

5.7.0 AI billing/key routing
- AI usage mode: Auto, Free project only, or Paid project only.
- Auto mode can keep separate Free-tier and Paid-tier Gemini API keys. It tries the Free project first and falls back to the Paid project when the Free project returns retryable access/quota/model errors.
- The plugin does not attempt to enable billing. Gemini usage tier is inherited from the Google Cloud project behind each API key.
- Test Gemini connection reports which configured project/key tier actually succeeded.

Google Cloud Vertex AI Express
- Optional separate backend using an Express Mode API key and the official aiplatform.googleapis.com endpoint.
- Current Google documentation describes a free Express Mode period for new Google Cloud users (up to 90 days within quota), with paid usage available after billing is enabled.

Version 6.1.0: Google AI Studio Free is the default/first provider. Auto order is AI Studio Free -> AI Studio Paid -> optional Cloud/Vertex fallback.


Version 6.0.0 API changes:
- Google AI Studio generation uses the current structured-output format documented by Google.
- AI Studio API version Auto mode tries v1 stable first, then v1beta.
- Authentication Auto mode tries the official x-goog-api-key header and query-key form.
- Generation no longer depends on models.list succeeding; this matters because Google can allow model listing while denying generateContent at project/account level.
- A Google 403 project-denied response is surfaced as a hard project/account restriction and is not hidden by model rotation.

Version 6.1.0: Fixed Gemini GenerateContent structured JSON request. The plugin now uses the documented responseMimeType/responseSchema fields and prefers the documented v1beta GenerateContent endpoint; if a project/model rejects structured output, it retries once with plain JSON text and parses the result.
